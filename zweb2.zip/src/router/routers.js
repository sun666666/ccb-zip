import Main from '@/components/main'
// 二级路由需要--mfg
// import parentView from '@/components/parent-view'

/**
 * meta: {
 *  title: { String|Number|Function }
 *         显示在侧边栏、面包屑和标签栏的文字
 *         使用'{{ 多语言字段 }}'形式结合多语言使用，例子看多语言的路由配置;
 *         可以传入一个回调函数，参数是当前路由对象，例子看动态路由和带参路由
 *  hideInBread: (false) 设为true后此级路由将不会出现在面包屑中，示例看QQ群路由配置
 *  hideInMenu: (false) 设为true后在左侧菜单不会显示该页面选项
 *  notCache: (false) 设为true后页面在切换标签后不会缓存，如果需要缓存，无需设置这个字段，而且需要设置页面组件name属性和路由配置的name一致
 *  access: (null) 可访问该页面的权限数组，当前路由设置的权限会影响子路由
 *  //icon: (-) 该页面在左侧菜单、面包屑和标签导航处显示的图标，如果是自定义图标，需要在图标名称前加下划线'_'
 *  beforeCloseName: (-) 设置该字段，则在关闭当前tab页时会去'@/router/before-close.js'里寻找该字段名对应的方法，作为关闭前的钩子函数
 * }
 */
/** ※※【重要说明】※※
 * path:唯一路径
 * name:唯一名称
 * meta:{
 *   title:'xxx'      标题
 *   hideInMenu:tree 不在菜单栏显示的路由
 *   noaccess: true  无需设置权限就可以访问，比如：登录login,报错error_404，公共组件：文件上传file_upload
 *   access:[]   建议设置为与路由名称或父级路由名称相同，
 *              【注意】access与管理端：角色机构管理->菜单管理->菜单权限  相应菜单的访问权限列表permission 匹配，
 *                     新增菜单必须在菜单管理里配置对应权限，页面内跳转可以沿用父级权限而无需在菜单管理配置。
 * }
 * 路由权限控制规则：
 * 用户登录成功后，会得到角色对应的全量权限列表permission（gsp/gld01013登录成功后返回）
 *   如果没有配置meta，路由权限默认为路由名称name,
 *   否则，{
 *      如果配置了access，路由权限为access配置的集合
 *      否则，{
 *         如果配置了noaccess，直接放行
 *         否则，即没有配置access和noaccess，路由名称name为路由权限
 *      }
 *   }
 * 判断：如果路由权限与全量权限列表permission有交集，路由权限校验通过放行，否则跳转至error_401
 *
 */
export default [
  {
    path: '/login',
    name: 'login',
    meta: {
      title: 'Login - 登录',
      hideInMenu: true,
      noaccess: true // 无需设置访问权限
    },
    component: () =>
      import('@/view/login/login.vue')
  },
  {
    path: '/',
    name: '_home',
    redirect: '/home',
    component: Main,
    meta: {
      hideInMenu: true,
      notCache: true,
      noaccess: true
    },
    children: [{
      path: '/home',
      name: 'home',
      meta: {
        hideInMenu: true,
        title: '首页',
        notCache: true,
        noaccess: true
      },
      component: () =>
        import('@/view/single-page/home/empty-home')
    }]
  },
  {
    path: '/charts',
    name: 'charts',
    meta: {
      title: 'echarts'
    },
    component: Main,
    children: [
      {
        path: 'charts_page',
        name: 'charts_page',
        meta: {
          icon: 'ios-navigate',
          title: 'echarts'
        },
        component: () => import('@/view/demo/charts/index.vue')
      }
    ]
  },
  {
    path: '/lodash',
    name: 'lodash',
    meta: {
      title: 'lodash'
    },
    component: Main,
    children: [
      {
        path: 'lodash_page',
        name: 'lodash_page',
        meta: {
          icon: 'ios-navigate',
          title: '函数式编程'
        },
        component: () => import('@/view/demo/lodash/index.vue')
      }
    ]
  },
  {
    path: '/pass-value',
    name: 'pass-value',
    meta: {
      icon: 'ios-stats',
      title: '组件通信'
    },
    component: Main,
    children: [
      {
        path: 'pass-value1',
        name: 'pass-value1',
        meta: {
          icon: 'md-add',
          title: '组件通信'
        },
        component: () => import('@/view/demo/pass-value/pass-value1.vue')
      }
    ]
  },
  {
    path: '/table',
    name: 'ccbtable',
    meta: {
      icon: 'ios-navigate',
      title: 'table组件'
    },
    component: Main,
    children: [
      {
        path: 'table1',
        name: 'ccbtable1',
        meta: {
          icon: 'md-navigate',
          title: '服务端分页及自定义序号'
        },
        component: () => import('@/view/demo/table/table1.vue')
      },
      {
        path: 'table2',
        name: 'ccbtable2',
        meta: {
          icon: 'md-navigate',
          title: '服务端分页并排序、过滤'
        },
        component: () => import('@/view/demo/table/table2.vue')
      },
      {
        path: 'table3',
        name: 'ccbtable3',
        meta: {
          icon: 'md-navigate',
          title: '前端分页并排序、过滤'
        },
        component: () => import('@/view/demo/table/table3.vue')
      }
    ]
  },
  {
    path: '/system_role_mgt',
    name: 'system_role_mgt',
    meta: {
      title: '机构角色管理'
    },
    component: Main,
    children: [
      {
        path: 'regional_mgt',
        name: 'regional_mgt',
        meta: {
          title: '区域管理',
          access: ['regional_mgt'] // 设置access与name名称相同
        },
        component: () =>
        import('@/view/demo/org-role-manager/region-manager')
      },
      {
        path: 'organization_mgt',
        name: 'organization_mgt',
        meta: {
          title: '组织机构管理',
          access: ['organization_mgt']
        },
        component: () =>
        import('@/view/demo/org-role-manager/organization-manager/organization-manager.vue')
      },
      {
        path: 'role_mgt',
        name: 'role_mgt',
        meta: {
          title: '角色管理',
          access: ['role_mgt']
        },
        component: () =>
        import('@/view/demo/org-role-manager/role-manager/role-manager.vue')
      },
      {
        path: 'add_role',
        name: 'add_role',
        meta: {
          title: '添加角色',
          access: ['add_role']
        },
        component: () =>
        import('@/view/demo/org-role-manager/role-manager/add-role.vue')
      },
      {
        path: 'edit_role',
        name: 'edit_role',
        meta: {
          title: '编辑角色',
          access: ['edit_role']
        },
        component: () =>
        import('@/view/demo/org-role-manager/role-manager/edit-role.vue')
      },
      {
        path: 'role_user_list',
        name: 'role_user_list',
        meta: {
          title: '已授权用户清单',
          access: ['role_user_list']
        },
        component: () =>
        import('@/view/demo/org-role-manager/role-manager/role-user-list.vue')
      },
      {
        path: 'role_menu_permission',
        name: 'role_menu_permission',
        meta: {
          title: '角色授权菜单管理',
          access: ['role_menu_permission']
        },
        component: () =>
        import('@/view/demo/org-role-manager/role-manager/role-menu-permission.vue')
      },
      {
        path: 'role_user_permission',
        name: 'role_user_permission',
        meta: {
          title: '角色授权用户管理',
          access: ['role_user_permission']
        },
        component: () =>
        import('@/view/demo/org-role-manager/role-manager/role-user-permission.vue')
      },
      {
        path: 'user_mgt',
        name: 'user_mgt',
        meta: {
          title: '用户管理',
          access: ['user_mgt']
        },
        component: () =>
        import('@/view/demo/org-role-manager/user-manager/user-manager.vue')
      },
      {
        path: 'role_list',
        name: 'role_list',
        meta: {
          title: '角色清单',
          access: ['role_list']
        },
        component: () =>
        import('@/view/demo/org-role-manager/user-manager/role-list.vue')
      },
      {
        path: 'user_permission',
        name: 'user_permission',
        meta: {
          title: '用户授权',
          access: ['user_permission']
        },
        component: () =>
        import('@/view/demo/org-role-manager/user-manager/user-permission.vue')
      },
      {
        path: 'user_add',
        name: 'user_add',
        meta: {
          title: '用户新增',
          access: ['user_add']
        },
        component: () =>
        import('@/view/demo/org-role-manager/user-manager/user-add.vue')
      },
      {
        path: 'menu_mgt',
        name: 'menu_mgt',
        meta: {
          title: '菜单管理',
          access: ['menu_mgt']
        },
        component: () =>
        import('@/view/demo/org-role-manager/menu-manager/menu-manager.vue')
      }
    ]
  },
  {
    path: '/system_mgt',
    name: 'system_mgt',
    meta: {
      title: '系统管理'
    },
    component: Main,
    children: [
      {
        path: 'system_log',
        name: 'system_log',
        meta: {
          title: '日志管理',
          access: ['system_log']
        },
        component: () => import('@/view/demo/sys-management/log-management')
      }
    ]
  },
  //* **********monitor_manage  end***********//
  {
    path: '/argu',
    name: 'argu',
    meta: {
      hideInMenu: true
    },
    component: Main,
    children: [
      {
        path: 'params/:id',
        name: 'params',
        meta: {
          // icon: 'md-flower',
          title: route => `{{ params }}-${route.params.id}`,
          notCache: true,
          beforeCloseName: 'before_close_normal'
        },
        component: () => import('@/view/demo/argu-page/params.vue')
      },
      {
        path: 'query',
        name: 'query',
        meta: {
          // icon: 'md-flower',
          title: route => `{{ query }}-${route.query.id}`,
          notCache: true
        },
        component: () => import('@/view/demo/argu-page/query.vue')
      }
    ]
  },
  {
    path: '/401',
    name: 'error_401',
    meta: {
      hideInMenu: true,
      noaccess: true
    },
    component: () => import('@/view/error-page/401.vue')
  },
  {
    path: '/500',
    name: 'error_500',
    meta: {
      hideInMenu: true,
      noaccess: true
    },
    component: () => import('@/view/error-page/500.vue')
  },
  {
    path: '*',
    name: 'error_404',
    meta: {
      hideInMenu: true,
      noaccess: true
    },
    component: () => import('@/view/error-page/404.vue')
  }
]
