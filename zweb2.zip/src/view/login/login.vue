<style lang="less">
  @import './login.less';
</style>

<template>
  <div class="login">
    <div class="login-con">
      <Card icon="log-in" title="欢迎登录" :bordered="false">
        <div class="form-con">
          <login-form @on-success-valid="handleSubmit"></login-form>
          <Spin fix v-show="show">
            <Icon type='ios-loading' size='18' class='spin-icon-load'></Icon>
            <div>正在登录</div>
          </Spin>
          <p class="login-tip" :class="{errorColor}">{{loginTip}}</p>
        </div>
      </Card>
    </div>
  </div>
</template>

<script>
import LoginForm from '_c/login-form'
import { mapActions, mapMutations } from 'vuex'
import { getMenuByRspData, localSave, sessionRead, sessionSave } from '@/libs/util'
import { getTempToken } from '@/api/routers'
import config from '@/config'
export default {
  data () {
    return {
      loginTip: '',
      errorColor: false,
      show: false
    }
  },
  components: {
    LoginForm
  },
  methods: {
    ...mapActions([
      'handleLogin',
      'getUserInfo'
    ]),
    ...mapMutations([
      'setHistoryRouter'
    ]),
    handleSubmit ({ userName, password }) {
      this.loginTip = ''
      this.errorColor = false
      this.show = true
      this.handleLogin({ userName, password }).then(res => {
        this.getUserInfo().then(res => {
          const menuList = getMenuByRspData(res.menuTree)
          this.$store.getters.menuList.splice(0)
          menuList.forEach(item => {
            this.$store.getters.menuList.push(item)
          })
          // 判断url上是否拼接了backUrl
          const backUrl = sessionRead('originUrl').split(',')[1]
          if (backUrl) {
            getTempToken().then((res) => {
              window.location = decodeURIComponent(backUrl) + '?token=' + res
            })
          } else {
            const historyRouter = sessionRead('originUrl').split(',')[0]
            if (historyRouter) {
              this.$router.push({
                name: historyRouter
              })
            } else {
              this.$router.push({
                name: this.$config.homeName
              })
            }
          }
          sessionSave('originUrl', '')
          this.show = false
        }, error => {
          this.show = false
          this.loginTip = typeof error === 'object' ? config.loginError : error
          this.errorColor = true
        })
      }, error => {
        this.show = false
        this.loginTip = typeof error === 'object' ? config.loginError : error
        this.errorColor = true
      })
    }
  }
}
</script>

<style scoped>
 .errorColor {
    color: #f00
 }
 .spin-icon-load {
    animation: ani-spin 1s linear infinite
 }
 @keyframes ani-spin {
  from { transform: rotate(0deg);}
  50% { transform: rotate(180deg);}
  to { transform: rotate(360deg);}
 }
</style>
