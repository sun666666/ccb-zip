<template>
  <div>
    <p>传递的参数为：{{value}}</p>
  </div>
</template>

<script>
export default {
  name: 'pass-value2',
  data () {
    return {
      value: 0
    }
  },
  methods: {
  },
  created () {
    this.$subscribe('eventName', (val) => {
      this.value = val
    })
  }
}
</script>

<style>
</style>
