<template>
  <div>
    <Button @click="passValue(1)">传值1</Button>
    <Button @click="passValue(2)">传值2</Button>
    <passvalue2></passvalue2>
  </div>
</template>

<script>
import passvalue2 from './pass-value2'
export default {
  name: 'pass-value1',
  data () {
    return {
    }
  },
  components: {
    passvalue2
  },
  methods: {
    passValue (value) {
      this.$publish('eventName', value)
    }
  }
}
</script>

<style>
</style>
