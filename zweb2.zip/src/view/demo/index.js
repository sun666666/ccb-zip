import View from './view'

export default View
