import { dateFormat } from '@/libs/util'
export default {
  data () {
    let self = this
    return {
      tabName: '1001',
      hideGrid: true,
      tableArr: [],
      table: {
        editMode: 'row', // 行编辑模式
        nowrap: true,
        actionColumn: 'Action',
        indexCol: true,
        checkCol: true,
        multiSelect: true,
        indexColTitle: '序号',
        indexColWidth: 60,
        static: false,
        pagination: true,
        total: 10,
        theme: 'simple',
        buttons: [
          [{
            label: '下载日志管理',
            name: 'downloadLog',
            type: 'primary',
            size: 'large',
            onClick: function (target, store) {
              let temList = []
              for (let i in store.states.selectedRows) {
                temList.push(store.states.selectedRows[i].logid)
              }
              this.btns.downloadLog.loading = true
              self.logDown(temList).then((res) => this.btns.downloadLog.loading = false)
            }
          }],
          [{
            label: '日志备份并清除',
            type: 'primary',
            size: 'large',
            onClick: function (target, store) {
              let temList = []
              for (let i in store.states.selectedRows) {
                temList.push(store.states.selectedRows[i].logid)
              }

              self.logDleAndUp(temList)
            }
          }]
        ],

        query: {
          fields: [{
            name: 'datepickerrange',
            type: 'datepickerrange',
            label: '时间',
            options: {
              type: 'date',
              style: 'width:260px;',
              placeholderBegin: '开始时间',
              placeholderEnd: '结束时间'
            },
            style: {
              width: '260px'
            }
          },
          {
            name: 'keyWord',
            type: 'string',
            label: '关键词',
            placeholder: '请输入关键词'
          }

          ],
          firstLineLayout: [{
            name: 'datepickerrange',
            style: {
              width: '180px'
            }
          }, {
            name: 'keyWord',
            style: {
              width: '180px'
            }
          }],
          layout: [
            ['datepickerrange', 'keyWord']
          ],

          buttons: {
            align: 'center', // 按钮左中右 start center end 默认 end
            submit: {
              label: '搜索'
            },
            clear: {
              label: '点此清除'
            }

          },
          choices: {}
        },
        columns: [{
          name: 'createtime',
          title: '操作时间',
          render: (h, param) => {
            return h('span', {}, param.row.createtime ? dateFormat(param.row.createtime, 'yyyy-MM-dd HH:mm:ss') : '')
          }
        },
        {
          name: 'logContent',
          title: '日志内容'
        }
        ],
        data: [],
        onSaveRow: function (row, callback) {
          console.log(row)
          self.$Message.info('save')
          callback('ok', row)
        },
        onDeleteRow: function (row, callback) {
          self.$Message.info('delete')
          callback('ok', row)
        },
        onRowEditRender: function (h, row) {
          /* if (row.id === 3) {
					  return h("div", "本行不可编辑");
					} */
        },
        onLoadData: function (url, param, callback) {
          if (param.datepickerrange && param.datepickerrange.length === 2 && new Date(param.datepickerrange[0]) > new Date(param.datepickerrange[1])) {
            self.$Message.error('结束时间不得早于开始时间')
            return false
          }
          param.logType = self.tabName
          self.getLogDate(param, function (res) {
            callback(res.data.list ? res.data.list : [], {
              total: res.data.txnCommCom && res.data.txnCommCom.totalRec ? res.data.txnCommCom.totalRec : 0
            })
          })
        }
      }
    }
  },
  methods: {
    tabClick (item) {
      this.tabName = item
      this.$refs['grid' + item].loadData()
    }
  },
  created () {
    for (let i = 0; i < 3; i++) {
      this.tableArr.push(this.table)
    }
  }
}
