<template>
  <Row class="auto-height">
    <i-col span="24">
      <orgTree ref="orgTree"></orgTree>
    </i-col>
  </Row>
</template>

<script>
import orgTree from '_bc/org-tree.vue'
export default {
  components: { orgTree },
  props: ['parent'],
  data () {
    return {}
  },
  methods: {},
  mounted () {},
  watch: {}
}
</script>

<style>
.auto-height, .auto-height .ivu-row, .auto-height .ivu-col, .auto-height .ivu-card{
  height: 100%;
}
.auto-height .ivu-card-body {
  height: calc(100% - 51px);
}
.auto-height .ivu-card-body .ivu-tree{
  height: calc(100% - 32px);
}
</style>
