<template>
  <Grid ref="grid" :data="config" :choices="choices" style="margin:0 20px;">
  </Grid>
</template>
<script>
import { queryRegionByTree, queryRegionByRegionName } from '@/api/org-role-manager'

export default {
  name: 'RegionList',
  props: ['parent'],
  data () {
    let self = this
    let table = {
      nowrap: true,
      draggable: true,
      indexCol: true,
      indexColTitle: '序号',
      checkCol: false,
      multiSelect: false,
      theme: 'simple',
      static: false,
      pagination: true,
      total: 6,
      columns: [
        { name: 'REGIONCODE', title: '区域编码', width: 200 },
        { name: 'REGIONNAME', title: '区域' }

      ],
      onLoadData: function (url, param, callback) {
        // 根据区域名称查询区域
        let paging = {
          tRecInPage: param.pageSize,
          tPageJump: param.page
        }
        queryRegionByRegionName(self.parent, param.regionName, paging).then(res => {
          if (res.data.list) { callback(res.data.list, { total: res.data.txnCommCom.totalRec }) } else { callback([]) }
        })
      },
      query: {
        fields: [
          { name: 'regionName', type: 'str', label: '区域名称' }
        ],
        layout: [
          ['regionName']
        ]
      }
    }
    return { config: table,
      choices: {
        select: []
      } }
  },
  watch: {
    parent (v) {
      this.$refs.grid.loadData()
    }
  }
}
</script>
