<template>
  <Row>
    <i-col span="4">
      <RegionTree ref="regionTree" @on-select-change="handleSelected"></RegionTree>
    </i-col>
    <u-col span="20">
      <Card dis-hover>
        <RegionList ref="regionList" :parent="current"></RegionList>
      </Card>
    </u-col>
  </Row>
</template>

<script>
import RegionList from './region-list.vue'
// import Uploader from '_bc/upload-input.vue'

export default {
  components: { RegionList },
  data () {
    return { current: null }
  },
  methods: {
    handleSelected (v) {
      console.log(v)
      this.current = v.id
    }
  }
}
</script>
