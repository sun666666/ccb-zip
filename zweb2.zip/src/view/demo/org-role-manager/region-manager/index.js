import View from './view.vue'

export default View
