<template>
  <div>
    <Card dis-hover>
      <Grid ref="grid" :data="table"></Grid>
    </Card>
    <modal v-model="userDetail" :title="modelTitle" ref="modal" :closable="false" :mask-closable="false">
      <build ref="build" :data="userData" :value="value" :errors="errors" :rules="rules" v-if="userDetail"></build>
      <div slot="footer">
        <Button type="default" @click="userModel">取消</Button>
        <Button type="primary" @click="saveUserAdd">确定</Button>
      </div>
    </modal>

    <modal v-model="resetPassWord" title="重置密码" ref="modal1" :closable="false" :mask-closable="false">
      <build :data="passWordData" :value="value" :rules="rules"></build>
      <div slot="footer">
        <Button type="default" @click="cancelReset">取消</Button>
        <Button type="primary" @click="savePassWord">确定</Button>
      </div>
    </modal>

    <modal v-model="linkMember" title="关联会员" ref="modal3">
      <build :data="linkData" :value="linkValue"></build>
      <div slot="footer">
        <Button type="default" @click="cancelLink">取消</Button>
        <Button type="primary" @click="saveMember">关联</Button>
      </div>
    </modal>
  </div>
</template>

<script>
import orgTree from '_bc/org-tree.vue'
import Bus from '@/libs/bus'
import { password } from '@/libs/password.js'
import {
  searchUserList,
  operateUser,
  resetPassWord
  ,
  userAdd,
  userEdit,
  findAssociateMemberByStaffId,
  doGovStaffAssociateMember,
  queryStaffByRegnAndOrgImport
} from '@/api/org-role-manager'

import {
  certIDTest,
  mobileNoTest,
  realName,
  passWordTest,
  passWordTest2,
  userNameTest
} from '@/libs/rules'
import { getRoleListData } from '@/api/data'
import { exportExcelFile } from '@/libs/util'

export default {
  components: { orgTree },
  data () {
    let self = this
    let certList = [
      {
        value: '1',
        label: '身份证'
      },
      {
        value: '2',
        label: '驾驶证'
      }
    ]
    var passWordData = [
      {
        name: 'basic',
        title: '',
        labelWidth: 150,
        staticSuffix: '_static',
        boxComponent: '',
        fields: [
          {
            name: 'firPassword',
            label: '请输入密码',
            placeholder: '请输入密码',
            required: true,
            static: false,
            options: {
              type: 'password',
              confirm: false,
              size: 'default'
            },
            onChange: function (value, data) {
              self.value.firPassword = value
            }
          },
          {
            name: 'secPassword',
            label: '请再次输入密码',
            placeholder: '请再次输入密码',
            required: true,
            static: false,
            options: {
              type: 'password',
              confirm: false,
              size: 'default'
            }
          }
        ],
        layout: [['firPassword'], ['secPassword']]
      }
    ]

    var linkData = [
      {
        name: 'basic',
        title: '',
        labelWidth: 150,
        staticSuffix: '_static',
        boxComponent: '',
        fields: [
          {
            name: 'loginAccountId',
            label: '会员ID',
            static: true
          },
          {
            name: 'loginNo',
            label: '会员账号',
            static: true
          },
          {
            name: 'nickName',
            label: '用户昵称',
            static: true
          },
          {
            name: 'userName',
            label: '真实姓名',
            static: true
          },
          {
            name: 'contactMobile',
            label: '手机号码',
            static: true
          },
          {
            name: 'certType',
            label: '证件类型',
            static: true
          },
          {
            name: 'certNo',
            label: '证件号码',
            static: true
          }
        ],
        layout: [
          ['loginAccountId'],
          ['loginNo'],
          ['nickName'],
          ['userName'],
          ['contactMobile'],
          ['certType'],
          ['certNo']
        ]
      }
    ]
    var userData = [
      {
        name: 'basic',
        title: '',
        labelWidth: 150,
        staticSuffix: '_static',
        boxComponent: '',
        fields: [
          {
            name: 'loginNo',
            label: '登录账户',
            placeholder: '请输入账户名称',
            rule: { max: 20 },
            static: false,
            required: true,
            options: {
            	autocomplete: 'off'
            }
          },
          {
            name: 'staffpassword',
            label: '用户密码',
            placeholder: '请输入密码',
            required: true,
            static: false,
            options: {
              type: 'password',
              confirm: false,
              size: 'default',
              autocomplete: 'off'
            }
          },
          {
            name: 'secPassword',
            label: '用户密码',
            placeholder: '请再次输入密码',
            required: true,
            static: false,
            options: {
              type: 'password',
              confirm: false,
              size: 'default'
            }
          },
          {
            name: 'staffName',
            label: '真实姓名',
            placeholder: '请输入真实姓名',
            static: false,
            required: true
          },
          {
            name: 'staffMobile',
            label: '手机号码',
            placeholder: '请输入手机号码',
            static: false,
            required: true
          },
          {
            name: 'certType',
            type: 'select',
            label: '证件类型',
            required: true,
            static: false,
            placeholder: '请选择证件类型',
            options: {
              choices: certList
            }
          },
          {
            name: 'certNo',
            label: '证件号码',
            static: false,
            placeholder: '请输入证件号码',
            required: true
          }
        ],
        layout: [
          ['loginNo'],
          ['staffpassword'],
          ['secPassword'],
          ['staffName'],
          ['staffMobile'],
          ['certType'],
          ['certNo']
        ]
      }
    ]

    let table = {
      nowrap: true,
      draggable: true,
      indexCol: true,
      indexColTitle: '序号',
      checkCol: false,
      multiSelect: false,
      theme: 'simple',
      pagination: true,
      total: 6,
      data: [],
      userDetail: {},
      buttons: [
        [
          {
            label: '新增用户',
            type: 'primary',
            onClick: function (target, data) {
              self.isAddorEdit = '0'
              self.modelTitle = '新增用户信息'
              // if (self.orgId == undefined || self.orgId == '') {
              //   this.$Message.info('请选择新增用户的区域和机构！')
              // } else {
              // 清空输入框
              self.value.loginNo = ''
              self.value.orgId = ''
              self.value.staffpassword = ''
              self.value.secPassword = ''
              self.value.staffName = ''
              self.value.staffMobile = ''
              self.value.certType = ''
              self.value.staffId = ''
              self.value.certNo = ''
              self.value.firPassword = ''
              self.value.secPassword = ''

              self.userData[0].fields[0].static = false
              self.userData[0].fields[1].static = false
              self.userData[0].fields[2].static = false
              self.userData[0].fields[3].static = false
              self.userData[0].fields[4].static = false
              self.userData[0].fields[5].static = false
              self.userData[0].fields[6].static = false
              self.userDetail = true
              // }
            }
          }
        ],
        [
        	{
        		label: '导出用户',
            type: 'primary',
            onClick: function (target, store) {
            	// 请求后台用户导出交易
            	var data = {
            		'txnBodyCom': {
            			staffId: self.$store.state.user.userId,
            			regionCode: store.grid.$refs.query.value.regionCode ? store.grid.$refs.query.value.regionCode : '',
            			orgCode: store.grid.$refs.query.value.regionCode ? store.grid.$refs.query.value.orgCode : '',
            			loginNo: store.grid.$refs.query.value.regionCode ? store.grid.$refs.query.value.loginNo : '',
            			staffName: store.grid.$refs.query.value.regionCode ? store.grid.$refs.query.value.staffName : ''
            		}
            	}
            	queryStaffByRegnAndOrgImport(data)
            	.then(res => {
            		exportExcelFile(res.data.filePath)
            		self.$Message.success('导出用户成功！')
            	})
            	.catch(error => {
            		self.$Message.error('导出用户失败，报错信息：' + error)
            	})
            }
        	}
        ]
      ],
      columns: [
        { name: 'loginNo', title: '登录账号' },
        { name: 'staffName', title: '用户姓名' },
        { name: 'staffMobile', title: '手机号码' },
        // { name: 'regionName', title: '所属区域' },
        { name: 'orgName', title: '所属机构' },
        {
          name: 'isEnable',
          title: '状态',
          width: 100,
          format: function (value, column, row) {
            let status_text = ''
            if (value == '0') {
              status_text = '已禁用'
            } else if (value == '1') {
              status_text = '已启用'
            }
            return '<span>' + status_text + '</span>'
          }
        },

        {
          title: '操作',
          name: 'action',
          width: 400,
          align: 'center',
          render: (h, param) => {
            var forbid_text
            forbid_text = param.row.isEnable == '0' ? '启用' : '禁用'
            var buttons = []
            // buttons.unshift(
            //   h(
            //     'Button',
            //     {
            //       props: {
            //         type: 'info',
            //         size: 'small'
            //       },
            //       style: {
            //         margin: '0 5px'
            //       },
            //       on: {
            //         click: function() {
            //           findAssociateMemberByStaffId(param.row.staffid).then(
            //             res => {
            //               if (res.data == null) {
            //                 self.$Message.error('会员信息不存在!')
            //               } else {
            //                 self.linkMember = true
            //                 self.linkValue.loginAccountId =
            //                   res.data.loginAccountId
            //                 self.linkValue.loginNo = res.data.loginNo
            //                 self.linkValue.nickName = res.data.nickName
            //                 self.linkValue.userName = res.data.userName
            //                 self.linkValue.contactMobile =
            //                   res.data.contactMobile
            //                 self.linkValue.certType = res.data.certType
            //                 self.linkValue.certNo = res.data.certNo
            //                 self.linkValue.staffid = param.row.staffid
            //               }
            //             }
            //           )
            //         }
            //       }
            //     },
            //     '关联会员'
            //   )
            // )
            buttons.unshift(
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    margin: '0 5px'
                  },
                  on: {
                    click: function () {
                      self.staffid = param.row.staffid
                      self.resetPassWord = true
                    }
                  }
                },
                '重置密码'
              )
            )
            // buttons.unshift(
            //   h(
            //     'Button',
            //     {
            //       props: {
            //         type: 'warning',
            //         size: 'small'
            //       },
            //       style: {
            //         margin: '0 5px'
            //       },
            //       on: {
            //         click: function() {
            //           self.$router.push({
            //             name: 'role_list',
            //             query: {
            //               staffId: param.row.staffid,
            //               staffName: param.row.staffName
            //             }
            //           })
            //         }
            //       }
            //     },
            //     '角色清单'
            //   )
            // )
            buttons.unshift(param.grid.defaultDeleteRender(h, param.row))
            buttons.unshift(
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    margin: '0 5px'
                  },
                  on: {
                    click: function () {
                      self.isAddorEdit = '1'
                      self.modelTitle = '编辑用户信息'
                      self.userDetail = true
                      self.userDetail = true
                      self.userData[0].fields[0].static = true
                      self.userData[0].fields[1].static = true
                      self.userData[0].fields[2].static = true
                      // self.userData[0].fields[3].static = true;
                      self.userData[0].fields[4].static = true
                      self.userData[0].fields[5].static = true

                      self.value.staffId = param.row.staffid
                      self.value.loginNo = param.row.loginNo
                      self.value.staffpassword = '**********'
                      self.value.secPassword = '**********'
                      self.value.staffName = param.row.staffName
                      self.value.staffMobile = param.row.staffMobile
                      self.value.certType = param.row.certType
                      self.value.certNo = param.row.certNo
                    }
                  }
                },
                '编辑'
              )
            )
            buttons.unshift(
              h(
                'Button',
                {
                  props: {
                    type: param.row.isEnable == '0' ? 'success' : 'default',
                    size: 'small'
                  },
                  style: {
                    margin: '0 5px'
                  },
                  on: {
                    click: function () {
                      // console.log(param.row.isEnable);
                      var operate_type = param.row.isEnable == '0' ? '1' : '0'
                      var operate_res =
                        param.row.isEnable == '0' ? '启用' : '禁用'
                      operateUser(param.row.staffid, operate_type).then(res => {
                        self.$Message.success(`${operate_res}成功`)
                        self.$refs.grid.loadData()
                      })
                    }
                  }
                },
                forbid_text
              )
            )

            return h('div', {}, buttons)
          }
        }
      ],
      onLoadData: function (url, param, callback) {
        // 根据机构查询用户信息;
        let paging = {
          tRecInPage: param.pageSize,
          tPageJump: param.page
        }
        searchUserList(
          param.regionCode,
          param.orgCode,
          param.loginNo,
          self.$store.state.user.userId,
          param.staffName,
          paging
        )
          .then(res => {
            // mock数据
            callback(res.data)
            // 正式数据
            // if (res.data.list)
            //   callback(res.data.list, {
            //     total: res.data.txnCommCom.totalRec
            //   })
            // else callback([])
          })
          .catch(err => {
            this.$Message.error(err)
          })
      },
      onDeleteRow: function (row, callback) {
        operateUser(row.staffid, '').then(res => {
          self.$Message.success('删除成功!')
          self.$refs.grid.loadData()
        })
      },

      query: {
        fields: [
          // {
          //   name: 'regionCode',
          //   label: '所属区域',
          //   type: 'RegionTreeSelect',
          //   onChange: function(v, all) {
          //     if (v == '') {
          //       self.orgId = ''
          //     }
          //     Bus.$emit('regionChange', v)
          //   }
          // },
          // {
          //   name: 'orgCode',
          //   label: '所属机构',
          //   type: 'OrgTreeSelect',
          //   onChange: function(v, all) {
          //     self.orgId = v
          //   }
          //   // options: { idField: "orgId" }//加上可以获取orgId,去去掉此行可以获取orgCode
          // },
          { name: 'loginNo', type: 'str', label: '登录账号' },
          { name: 'staffName', type: 'str', label: '用户姓名' }
        ],
        // layout: [['regionCode', 'orgCode', 'loginNo', 'staffName']]
        layout: [['loginNo', 'staffName']]
      }
    }
    return {
      chooseRegionCode: '',
      modelTitle: '',
      table: table,
      resetPassWord: false,
      linkMember: false,
      firPassword: '',
      secPassword: '',
      isAddorEdit: '0', // 0新增 1 编辑
      staffid: '',
      userDetail: false,
      userAdd: false,
      loginNo: '',
      orgId: '',
      staffpassword: '',
      secPassword: '',
      staffName: '',
      staffMobile: '',
      certType: '',
      certNo: '',
      userData: userData,
      linkData: linkData,
      passWordData: passWordData,
      linkValue: {
        staffid: '',
        loginAccountId: '',
        loginNo: '',
        nickName: '',
        userName: '',
        contactMobile: '',
        certType: '',
        certNo: ''
      },
      value: {
        loginNo: '',
        orgId: '',
        staffpassword: '',
        staffName: '',
        staffMobile: '',
        certType: '',
        staffId: '',
        certNo: '',
        firPassword: '',
        secPassword: ''
      },
      rules: {
        loginNo: function (rule, value, callback, source, options) {
          if (value.length > 19) {
            callback(new Error('请输入正确的账户名!'))
          } else {
            callback()
          }
        },
        staffMobile: function (rule, value, callback, source, options) {
          if (mobileNoTest(value) == false) {
            callback(new Error('请输入正确的手机号码!'))
          } else {
            callback()
          }
        },
        certNo: function (rule, value, callback, source, options) {
          if (certIDTest(value) == false) {
            callback(new Error('请输入正确的证件号码!'))
          } else {
            callback()
          }
        },
        staffName: function (rule, value, callback, source, options) {
          if (realName(value) == false) {
            callback(new Error('请输入正确的真实姓名!'))
          } else {
            callback()
          }
        },
        staffpassword: function (rule, value, callback, source, options) {
          if (passWordTest2(value) == false) {
            callback(
              new Error('密码必须包含大小写字母数字和特殊字符,8-20个字符!')
            )
          } else {
            callback()
          }
        },
        firPassword: function (rule, value, callback, source, options) {
          if (passWordTest2(value) == false) {
            callback(
              new Error('密码必须包含大小写字母数字和特殊字符,8-20个字符!')
            )
          } else {
            callback()
          }
        },
        secPassword: function (rule, value, callback, source, options) {
          if (passWordTest2(value) == false) {
            callback(
              new Error('密码必须包含大小写字母数字和特殊字符,8-20个字符!')
            )
          } else {
            callback()
          }
        }
      },
      errors: {}
    }
  },
  methods: {
    userModel () {
      this.userDetail = false
    },
    saveUserAdd () {
      let paging = {
        tRecInPage: '',
        tPageJump: ''
      }
      if (this.isAddorEdit == '0') {
        if (this.value.loginNo == '') {
          this.$Message.warning('登录账号账号不能为空!')
        } else if (this.value.loginNo.length > 19) {
          this.$Message.warning('请输入正确的账户名!')
        } else if (this.value.staffpassword == '') {
          this.$Message.warning('密码不能为空!')
        } else if (passWordTest2(this.value.staffpassword) == false) {
          this.$Message.warning(
            '密码必须包含大小写字母数字和特殊字符,8-20个字符!'
          )
        } else if (this.value.staffpassword !== this.value.secPassword) {
          this.$Message.warning('两次输入的用户密码必须一致!')
        } else if (this.value.staffName == '') {
          this.$Message.warning('用户姓名不能为空!')
        } else if (realName(this.value.staffName) == false) {
          this.$Message.warning('请输入正确的真实姓名!')
        } else if (this.value.staffMobile == '') {
          this.$Message.warning('手机号码不能为空!')
        } else if (mobileNoTest(this.value.staffMobile) == false) {
          this.$Message.warning('请输入正确的手机号码!')
        } else if (this.value.certType == '') {
          this.$Message.warning('请选择证件类型!')
        } else if (this.value.certNo == '') {
          this.$Message.warning('证件号码不能为空!')
        } else if (certIDTest(this.value.certNo) == false) {
          this.$Message.warning('请输入正确的证件号码!')
        } else {
          userAdd(
            this.value.loginNo,
            this.orgId,
            password(this.value.staffpassword),
            this.value.staffName,
            this.value.staffMobile,
            this.value.certType,
            this.value.certNo,
            paging
          )
            .then(res => {
              this.$Message.success('新增用户成功!')
              this.$refs.grid.loadData()
              this.userDetail = false
            })
            .catch(err => {
              this.$Message.error(err)
            })
        }
      } else {
        if (this.value.staffName == '') {
          this.$Message.warning('用户姓名不能为空!')
        } else if (realName(this.value.staffName) == false) {
          this.$Message.warning('请输入正确的真实姓名!')
        } else if (this.value.staffMobile == '') {
          this.$Message.warning('手机号码不能为空!')
        } else if (mobileNoTest(this.value.staffMobile) == false) {
          this.$Message.warning('请输入正确的手机号码!')
        } else {
          userEdit(
            this.value.staffId,
            this.value.staffName,
            this.value.staffMobile,
            paging
          )
            .then(res => {
              // console.log(res);
              this.$Message.success('编辑用户成功!')
              this.$refs.grid.loadData()
              this.userDetail = false
            })
            .catch(err => {
              this.$Message.error(err)
            })
        }
      }
    },
    cancelReset () {
      this.resetPassWord = false
    },
    savePassWord (e) {
      if (this.value.firPassword == '' || this.value.secPassword == '') {
        this.$Message.warning('密码不能为空!')
      } else if (
        passWordTest2(this.value.firPassword) == false ||
        passWordTest2(this.value.secPassword) == false
      ) {
        this.$Message.warning(
          '密码必须包含大小写字母数字和特殊字符,8-20个字符!'
        )
      } else {
        resetPassWord(
          this.staffid,
          password(this.value.firPassword),
          password(this.value.secPassword)
        )
          .then(res => {
            this.resetPassWord = false
            this.$Message.success('重置密码成功!')
          })
          .catch(err => {
            this.$Message.error(err)
          })
      }
    },
    cancelLink () {
      this.linkMember = false
    },
    saveMember () {
      // console.log(this.linkValue.staffid);
      doGovStaffAssociateMember(
        this.linkValue.staffid,
        this.linkValue.loginAccountId
      ).then(res => {
        this.linkMember = false
        this.$Message.success('关联会员成功!')
      })
    }
  }
  // mounted() {
  //   console.log(this.$store.state.user);
  // }
  // watch: {}
}
</script>
<style>
.ivu-select-dropdown-transfer {
  z-index: 999999;
}
.colHeight {
  height: 30px;
  line-height: 30px;
  font-size: 16px;
  text-indent: 40px;
}
</style>
