<template>
  <div>
    <p class="role_name">
      当前操作的用户名称：
      <b>{{$route.query.staffName}}</b>
    </p>
    <Card dis-hover>
      <grid :data="table" ref="grid"></grid>
    </Card>
  </div>
</template>
<script>
import { getRoleListData } from '@/api/data'
import {
  insertStaffRoleRelation,
  getRoleListByStaffId,
  delPermittedUser
} from '@/api/org-role-manager'

export default {
  data () {
    let self = this
    var table = {
      indexCol: true,
      indexColTitle: '序号',
      indexColWidth: 60,
      theme: 'simple',
      pagination: false,
      buttons: [
        [
          {
            label: '新增授权角色',
            type: 'primary',
            onClick: function (target, store) {
              self.$router.push({
                name: 'user_permission',
                query: {
                  staffId: self.staffId
                }
              })
            }
          },
          {
            label: '返回用户管理',
            type: 'default',
            onClick: function (target, store) {
              self.$router.push({
                name: 'user_mgt'
              })
            }
          }
        ]
      ],
      columns: [
        { name: 'roleName', title: '角色名称' },
        { name: 'roleCode', title: '角色编码' },
        { name: 'roleMemo', title: '角色描述' },
        {
          title: '操作',
          name: 'Action',
          width: 80,
          render: function (h, param) {
            var buttons = [param.grid.defaultDeleteRender(h, param.row)]
            return h('div', {}, buttons)
          }
        }
      ],
      data: [],
      onCheckable: function (row) {
        var r = !row._isParent
        return r
      },
      onLoadData: function (url, param, callback) {
        // 查询角色已经授予的权限的id
        let paging = {
          tRecInPage: '',
          tPageJump: ''
        }
        getRoleListByStaffId(self.staffId, paging).then(res => {
          // for (let i = 0; i < res.data.length; i++) {
          //   self.selectedRoles.push(res.data[i].roleId);
          // }
          // console.log(self.selectedRoles);
          callback(res.data ? res.data : [])
        })
        // 查询角色所有的权限
        // var postdata = {
        //   txnBodyCom: {
        //     staffId: self.staffId,
        //     isEnable: "1",
        //     roleLvl: param.roleLvl ? param.roleLvl : "",
        //     roleCode: param.roleCode ? param.roleCode : "",
        //     roleName: param.roleName ? param.roleName : ""
        //   }
        // };
        // getRoleListData(postdata, {
        //   tRecInPage: "",
        //   tPageJump: ""
        // }).then(res => {
        //   console.log(res);
        //   // console.log(res.data.voList[i].roleStatus);
        //   let myList = [];
        //   for (let i = 0; i < res.data.voList.length; i++) {
        //     if (res.data.voList[i].roleStatus == 1) {
        //       self.selectedRoles.push(res.data.voList[i].roleId);
        //       myList.push(res.data.voList[i]);
        //     }
        //   }
        //   callback(myList ? myList : [], {
        //     total: res.data.txnCommCom ? res.data.txnCommCom.totalRec : 0
        //   });
        // });
      },
      onDeleteRow: function (row, callback) {
        var postdata = {
          txnBodyCom: {
            staffId: self.staffId,
            roleId: row.roleId
          }
        }
        delPermittedUser(postdata)
          .then(res => {
            self.$Message.success('移除成功')
            self.$refs.grid.loadData()
          })
          .catch(err => {
            self.$Message.error(err)
          })
        // let paging = {
        //   tRecInPage: "",
        //   tPageJump: ""
        // };
        // if (self.selectedRoles.indexOf(row.roleId) > -1) {
        //   self.selectedRoles.splice(self.selectedRoles.indexOf(row.roleId), 1);
        // }
        // console.log(self.selectedRoles);
        // let selectedRolesId = self.selectedRoles.join(",");
        // insertStaffRoleRelation(self.staffId, selectedRolesId, paging)
        //   .then(res => {
        //     self.$Message.success("移除成功");
        //     self.$refs.grid.loadData();
        //   })
        //   .catch(err => {
        //     self.$Message.error(err);
        //   });
      }
    }

    return {
      table: table,
      selectedRolesId: '',
      selectedRoles: [], // 选中的角色
      staffId: this.$route.query.staffId // 用户id
    }
  }
}
</script>
<style scoped>
.role_name {
  margin-bottom: 10px;
  font-size: 14px;
}
</style>
