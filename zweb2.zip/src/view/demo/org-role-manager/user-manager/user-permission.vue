<template>
  <div>
    <Row>
      <i-col span="12">
        <Card dis-hover>
          <grid
            :data="table"
            ref="grid"
            @on-selected-all="handleSelectedAll"
            @on-deselected-all="handleDeselectedAll"
            @on-selected="handleSelected"
            @on-deselected="handleDeselected"
          ></grid>
        </Card>
      </i-col>
      <u-col span="12">
        <Card dis-hover>
          <p>待授权角色列表</p>
          <Grid ref="grid1" :data="selected_table" :value="value1"></Grid>
        </Card>
      </u-col>
    </Row>
  </div>
</template>
<script>
import { getRoleListData } from '@/api/data'
import { insertStaffRoleRelation } from '@/api/org-role-manager'

export default {
  data () {
    let self = this
    let value1 = []
    var table = {
      editMode: 'row',
      nowrap: true,
      theme: 'simple',
      checkCol: true,
      checkColWidth: 200,
      checkColTitle: '权限选择',
      multiSelect: true,
      pagination: true,
      columns: [
        { name: 'roleName', title: '角色名称' },
        { name: 'roleCode', title: '角色编码' },
        { name: 'roleMemo', title: '角色描述' },
        { name: 'id', title: '角色ID', hidden: true }
      ],
      data: [],
      onCheckable: function (row) {
        if (row.roleStatus == null) {
          return true
        } else {
          return false
        }
      },
      // onLoadData: function(url, param, callback) {
      //   //查询角色所有的权限
      //   var postdata = {
      //     txnBodyCom: {
      //       staffId: self.staffId,
      //       isEnable: "1",
      //       roleCode: param.roleCode ? param.roleCode : "",
      //       roleName: param.roleName ? param.roleName : ""
      //     }
      //   };
      //   getRoleListData(postdata, {
      //     tRecInPage: param.pageSize,
      //     tPageJump: param.page
      //   }).then(res => {
      //     for (let i = 0; i < res.data.voList.length; i++) {
      //       res.data.voList[i].id = res.data.voList[i].roleId;
      //     }
      //     callback(res.data.voList ? res.data.voList : [], {
      //       total: res.data.txnCommCom ? res.data.txnCommCom.totalRec : 0
      //     });

      //     // 设置已经选中角色打钩
      //     self.$refs.grid.setSelection(self.selectedRoles);
      //   });
      // },

      onLoadData: function (url, param, callback) {
        // 查询角色所有的权限
        var postdata = {
          txnBodyCom: {
            staffId: self.staffId,
            isEnable: '1',
            roleCode: param.roleCode ? param.roleCode : '',
            roleName: param.roleName ? param.roleName : ''
          }
        }
        getRoleListData(postdata, {
          tRecInPage: param.pageSize,
          tPageJump: param.page
        }).then(res => {
          let myList = []
          for (let i = 0; i < res.data.voList.length; i++) {
            res.data.voList[i].id = res.data.voList[i].roleId
            if (res.data.voList[i].roleStatus == null) {
              myList.push(res.data.voList[i])
            } else if (res.data.voList[i].roleStatus === 1) {
              self.selectedRoles.push(res.data.voList[i].roleId)
              myList.unshift(res.data.voList[i])
            }
          }
          callback(myList || [], {
            total: res.data.txnCommCom ? res.data.txnCommCom.totalRec : 0
          })
          // 设置已经选中角色打钩
          self.$refs.grid.setSelection(self.selectedRoles)
        })
      },
      query: {
        fields: [
          {
            name: 'roleName',
            label: '角色名称'
          },
          {
            name: 'roleCode',
            label: '角色编码'
          }
        ],
        layout: [['roleName', 'roleCode']]
      }
    }

    let selected_table = {
      nowrap: true,
      theme: 'simple',
      pagination: false,
      data: [],
      columns: [
        { name: 'roleName', title: '角色名称' },
        { name: 'roleCode', title: '角色编码' },
        { name: 'roleMemo', title: '角色描述' }
      ],
      rightButtons: [
        [
          {
            label: '确认授权',
            type: 'primary',
            onClick: function (target, store) {
              if (self.value1.length > 0) {
                let paging = {
                  tRecInPage: '',
                  tPageJump: ''
                }
                let selectedRolesId = []
                self.value1.forEach((item, index) => {
                  selectedRolesId.push(item.roleId)
                })
                selectedRolesId = selectedRolesId.concat(self.selectedRoles)

                insertStaffRoleRelation(
                  self.staffId,
                  selectedRolesId.join(','),
                  paging
                )
                  .then(res => {
                    self.$Message.success('授权成功')
                    self.$router.push({
                      name: 'role_list',
                      query: {
                        staffId: self.staffId
                      }
                    })
                  })
                  .catch(err => {
                    self.$Message.error(err)
                  })
              } else {
                self.$Message.error('请选择要授权的角色')
              }
            }
          },
          {
            label: '返回',
            type: 'default',
            onClick: function (target, store) {
              self.$router.push({
                name: 'role_list',
                query: {
                  staffId: self.staffId
                }
              })
            }
          }
        ]
      ],
      onLoadData: function (url, param, callback) {
        callback()
      }
    }

    return {
      table: table,
      selectedRolesId: '',
      selectedRoles: [], // 选中的角色
      selected_table: selected_table, // 已经选择的角色列表
      value1: value1,
      selected: [],
      staffId: this.$route.query.staffId // 用户id
    }
  },

  methods: {
    handleSelectedAll (row) {
      this.selected = this.$refs.grid.getSelectedRows()
      for (let i = 0; i < this.selected.length; i++) {
        for (let j = 0; j < this.selectedRoles.length; j++) {
          if (this.selected[j].roleId === this.selectedRoles[i]) {
            this.selected.splice(j, 1)
            j--
          }
        }
      }
      this.value1 = this.selected
      this.$refs.grid1.loadData()
    },
    handleDeselectedAll () {
      this.value1 = []
      // 设置已经选中角色打钩
      this.$refs.grid.setSelection(this.selectedRoles)
      this.$refs.grid1.loadData()
    },
    handleSelected (row) {
      this.value1.push(row)
      this.$refs.grid1.loadData()
    },
    handleDeselected (row) {
      let restArr = []
      this.value1.forEach((item, index) => {
        if (item.roleId !== row.roleId) {
          restArr.push(item)
        }
      })
      this.value1 = restArr
      this.$refs.grid1.loadData()
    }
  }
}
</script>
<style>
