<template>
  <div>
    <Modal v-model="show_route" width="900" title="选择路由" @on-ok="onOk" @on-cancel="onCancel">
      <Grid ref="grid" :data="table" :value="routeList" @on-selected="handleSelected" @on-deselected="handleDeselected"
            @on-selected-all="handleSelectedAll" @on-deselected-all="handleDeselectedAll"></Grid>
    </Modal>
  </div>
</template>

<script>
import LocalRouters from '@/router/routers'

export default {
  name: 'route-permission',
  props: {
    modal: {
      type: Boolean,
      default: true
    },
    permission: {
      type: String,
      default: ''
    }
  },
  computed: {
    show_route: {
      get: function () {
        return this.modal
      },
      set: function (newValue) {
      }
    }
  },
  data: function () {
    let table = {
      nowrap: true,
      actionColumn: 'Action',
      indexCol: false,
      checkCol: true,
      multiSelect: true,
      static: false,
      tree: true,
      pagination: false,
      total: 6,
      theme: 'simple',
      treeField: 'name',
      idField: 'name',
      width: 800,
      columns: [
        {
          name: 'name',
          title: '路由名称',
          align: 'left'
        },
        {
          name: 'title',
          title: '路由标题',
          align: 'left'
        },
        {
          name: 'path',
          title: '路由路径',
          align: 'left'
        }
      ],

      data: []
      // onLoadData: function (url, param, callback) {
      //   callback([])
      // }
    }
    return {
      table: table,
      selected_rows: [], // 已选中的记录
      routeList: []
    }
  },
  methods: {
    freshRouteList (permission) {
      this.$refs.grid.deselectAll(true)// 全部取消选择
      this.selected_rows = []
      let list = permission.split(',')
      console.log('分割后的值：', list)
      this.selected_rows = list
      this.$refs.grid.setSelection(this.selected_rows)
    },
    onCancel () {

    },
    onOk () {
      console.log('点击确定')
      this.$emit('selected_rows', this.selected_rows)
    },
    /* handleSelect (data) {
         let self = this;
         self.roleLvl = data[0].roleLvl;
         self.$refs.grid.loadData();
       }, */
    handleSelected () {
      this.get_selected_data()
    },
    handleDeselected () {
      this.get_selected_data()
    },
    handleSelectedAll () {
      this.get_selected_data()
    },
    handleDeselectedAll () {
      this.get_selected_data()
    },
    get_selected_data () {
      let selected_rtname = []
      /* let selected_routes = [] */
      let selected_row = this.$refs.grid.getSelectedRows()
      selected_row.forEach(item => {
        if (selected_rtname.indexOf(item.name) < 0) {
          selected_rtname.push(item.name)
          /* selected_routes.push(item); */
        }
      })
      /* this.selected_roles = selected_rtname; */
      this.selected_rows = selected_rtname
    }
  },
  mounted () {
    const getRouterTree = list => {
      let ret = []
      list.forEach(item => {
        let obj = {
          id: item.name,
          path: item.path,
          name: item.name,
          title: '',
          meta: {
            title: '',
            access: []
          }
        }
        if (item.children && item.children.length) {
          obj.children = getRouterTree(item.children)
        }
        if (item.meta) {
          if (item.meta.title) {
            obj.meta.title = item.meta.title
            obj.title = item.meta.title
          }
        }
        if (item.meta && item.meta.hideInMenu && item.meta.hideInMenu == true) {
          console.log('过滤不展示的路由；', item.name)
        } else {
          ret.push(obj)
        }
      })
      return ret
    }
    let routerList = getRouterTree(LocalRouters)
    this.$refs['grid'].store.states.data = this.$refs['grid'].store.makeRows(routerList)
  },
  watch: {
    permission (v) {
      this.freshRouteList(v)
    }
  }
}
</script>

<style scoped>

</style>
