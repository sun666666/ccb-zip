<template>
  <div>
  <Card dis-hover>
    <grid :data="table" ref="grid"></grid>
  </Card>
  <RoutePermission :modal="selectRP" :permission="permission" @selected_rows="set_menu_permission"></RoutePermission>
  </div>
</template>

<script>
import {
  addEditMenuInfo,
  queryAllMenus,
  delMenuInfo
} from '@/api/org-role-manager'
import { isEmpty } from '@/libs/util'
import RoutePermission from './route-permission'

export default {
  name: 'menu-manager',
  components: {
    RoutePermission
  },
  data () {
    let self = this
    let table = {
      nowrap: true,
      indexCol: true,
      indexColTitle: '序号',
      checkCol: true,
      // rowHeight: 40,
      theme: 'default',
      editMode: 'row',
      actionColumn: 'action',
      tree: true,
      treeField: 'menuName',
      idField: 'menuId',
      columns: [
        { name: 'menuId', title: '菜单Id', hidden: true },
        { name: 'menuName', title: '菜单名称', align: 'left', editor: {} },
        { name: 'icon',
          title: '菜单图标',
          editor: {},
          render (h, param) {
            return h('div', {}, [
              h('Icon', {
                props: { type: param.value }
              }),
              h('span', {}, param.value)
            ])
          } },
        { name: 'permission',
          title: '菜单路由权限',
          render: (h, params) => {
            var buttons = [
              h('Button', {
                props: {
                  /* type: 'link', */
                  size: 'small'
                },
                style: { margin: '0 5px' },
                on: {
                  click: () => {
                    self.menuId = params.row.menuId
                    self.permission = params.row.permission
                    self.edit_row = params.row
                    self.selectRP = !self.selectRP
                  }
                }
              }, params.row.permission ? params.row.permission : '...')
            ]
            return h('div', {}, buttons)
          } },
        { name: 'menuPath', title: '菜单路由', editor: {} },
        { name: 'sortCode', title: '序号', editor: {}, width: 60 },
        {
          name: 'isEnable',
          title: '状态',
          width: 60,
          editor: {
            type: 'select',
            static: true,
            options: {
              choices: [['1', '已启用'], ['0', '已禁用']]
            }
          }
        },
        {
          name: 'action',
          title: '操作',
          fixed: 'right',
          render (h, param) {
            let buttons = [
              param.grid.defaultEditRender(h, param.row),
              param.grid.defaultDeleteRender(h, param.row)
            ]
            if (!param.row._editting) {
              let buttonText = param.row.isEnable === '1' ? '禁用' : '启用'
              buttons.push(
                h(
                  'Button',
                  {
                    props: { type: 'primary', size: 'small', loading: param.row._loading },
                    style: { margin: '0 5px' },
                    on: {
                      click () {
                        self.$set(param.row, '_loading', true)
                        // console.log(param);
                        let reqParams = {
                          txnBodyCom: {
                            menuId: param.row.menuId,
                            operateType: param.row.isEnable === '1' ? '4' : '3'
                          }
                        }
                        delMenuInfo(reqParams).then(
                          res => {
                            self.$Message.info('操作成功')
                            self.$refs.grid.loadData()
                          },
                          error => {
                            self.$Message.error(error)
                            self.$set(param.row, '_loading', false)
                          }
                        )
                      }
                    }
                  },
                  buttonText
                )
              )
            }
            return h('div', {}, buttons)
          }
        }
      ],
      data: [],
      buttons: [
        // [{
        //     label: '增加第一子菜单', type: 'primary', onClick: function (target, store) {
        //         let rows = store.getSelectedRows()
        //         if (rows.length === 0) {
        //           self.$Message.info('请先选择')
        //         } else {
        //           store.addEditChildRow({}, rows[0], 'before')
        //           self.parentId = rows[0].menuId
        //         }
        //     }
        // }],
        [
          {
            label: '新增子菜单',
            type: 'primary',
            onClick: function (target, store) {
              let rows = store.getSelectedRows()
              if (rows.length === 0) {
                self.$Message.info('请先选择')
              } else {
                store.addEditChildRow({}, rows[0], 'after')
                self.parentId = rows[0].menuId
              }
            }
          }
        ],
        [
          {
            label: '向后新增菜单',
            type: 'primary',
            onClick: function (target, store) {
              let rows = store.getSelectedRows()
              if (rows.length === 0) {
                self.$Message.info('请先选择')
              } else {
                store.addEditRow({}, rows[0], 'after')
                self.parentId = rows[0].parentCode
              }
            }
          }
        ],
        [
          {
            label: '向前新增菜单',
            type: 'primary',
            onClick: function (target, store) {
              let rows = store.getSelectedRows()
              if (rows.length === 0) {
                self.$Message.info('请先选择')
              } else {
                store.addEditRow({}, rows[0], 'before')
                self.parentId = rows[0].parentCode
              }
            }
          }
        ]
      ],
      onSaveRow: function (row, callback, oldrow) {
        let {
          menuName,
          icon,
          menuPath,
          menuId,
          parentCode,
          sortCode
        } = row
        let reqParams = {
          txnBodyCom: {
            menuName,
            icon,
            menuPath,
            menuId,
            parentCode,
            sortCode:
              typeof sortCode === 'number' ? sortCode.toString() : sortCode,
            permission: oldrow.permission,
            menuType: '0',
            parentId: self.parentId ? self.parentId : parentCode
          }
        }
        let errorObj = {}
        if (!menuName) errorObj.menuName = '必输'
        if (!icon) errorObj.icon = '必输'
        if (!menuPath && (!row.children || row.children.length === 0)) errorObj.menuPath = '必输'
        if (!sortCode) errorObj.sortCode = '必输'

        if (isEmpty(errorObj)) {
          addEditMenuInfo(reqParams).then(
            res => {
              self.$Message.info('保存成功')
              callback('ok', row)
              self.$refs.grid.loadData()
            },
            error => {
              self.$Message.error(error)
              callback('error', {})
            }
          )
        } else {
          callback('error', errorObj)
        }
      },
      onDeleteRow: function (row, callback) {
        let { menuId } = row
        let reqParams = {
          txnBodyCom: {
            menuId,
            operateType: '2'
          }
        }
        delMenuInfo(reqParams).then(
          res => {
            self.$Message.info('删除成功')
            self.$refs.grid.loadData()
          },
          error => {
            self.$Message.error(error)
          }
        )
      },
      onLoadData: function (url, param, callback) {
        let reqParams = {
          txnBodyCom: {}
        }
        queryAllMenus(reqParams).then(res => {
          // console.log(res);
          const getMenuTree = list => {
            let res = []
            list.forEach(item => {
              let obj = {
                menuName: item.name,
                icon: item.icon,
                menuPath: item.href,
                menuId: item.childCode,
                parentCode: item.parentCode,
                sortCode: item.sortCode || '',
                permission: item.permission || '',
                isEnable: item.isEnable
              }
              if (item.children && item.children.length) {
                obj.children = getMenuTree(item.children)
              }
              res.push(obj)
            })
            return res
          }
          let menuList = getMenuTree(res.data[0].children)
          callback(menuList)
        })
      }
    }
    return {
      table,
      parentId: '',
      selectRP: false,
      menuId: '',
      editFlag: false,
      permission: '',
      edit_row: {}

    }
  },
  methods: {
    set_menu_permission (routes) {
      console.log('设置的路由权限为：', routes)
      console.log('设置的路由权限2为：', this.edit_row)
      this.$set(this.edit_row, 'permission', routes.toString())
    }
  },
  mounted () {}
}
</script>

<style scoped>
</style>
