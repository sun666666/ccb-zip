<template>
    <div class="role_permission">
        <p class="role_name">当前操作的角色名称：<b>{{$route.query.rolename}}</b></p>
        <Card dis-hover>
            <grid :data="table" ref="grid" @on-selected="handleSelected" @on-deselected="handleDeselected" @on-selected-all="handleSelectedAll" @on-deselected-all="handleDeselectedAll"></grid>
        </Card>

        <div style="margin-top:20px">
            <Button type="primary" @click="save_permission" style="margin-right:20px">确定</Button>
            <Button type="default" @click="goto_list">返回</Button>
        </div>
    </div>
</template>
<script>
import { authorizeRole, getMenuListByRole } from '@/api/org-role-manager'
export default {
  data () {
    let self = this
    let selected = []
    var table = {
      editMode: 'row',
      nowrap: true,
      theme: 'simple',
      checkCol: true,
      checkColWidth: 200,
      checkColTitle: '权限选择',
      multiSelect: true,
      tree: true,
      treeField: 'menu_name',
      columns: [
        { name: 'menu_name', title: '菜单名称', align: 'left' }
        // {name:'name5', title:'权限选择', width:200, render: function(h, param) {
        //     console.log(param.row._isParent)
        //     if(!param.row._isParent){
        //         var self = this
        //         return h('Checkbox', {
        //             props: {
        //                 value: param.value
        //             },
        //             on: {
        //                 input: function(value) {
        //                     alert(self.value)
        //                 }
        //             }
        //         })
        //     }
        // }},
      ],
      data: [],
      onCheckable: function (row) {
        var r = !row.children
        return r
      },
      onLoadData: function (url, param, callback) {
        var postdata = {
          'txnBodyCom': {
            'roleid': this.$route.query.roleid
          }
        }
        getMenuListByRole(postdata).then(res => {
          console.log(res)
          const getMenuTree = (list) => {
            let menu_arr = []
            list.forEach((item, index) => {
              let expand_tag, per_data
              let relation_tag = !!(item.isRelation && item.isRelation == '1')
              per_data = {
                menu_name: item.name,
                id: item.childCode,
                isRelation: item.isRelation,
                parentId: item.parentCode,
                // parentIdSet : item.parentIdSet.split(','),
                _expand: true
              }
              if (item.children && item.children.length) {
                per_data.children = getMenuTree(item.children)
              }
              menu_arr.push(per_data)
            })
            return menu_arr
          }

          // 表格数据填充
          let menulist = res.data[0].children
          let menutree = getMenuTree(menulist)
          console.log(menutree)
          callback(menutree)

          // 已经选中菜单标识
          self.queryAllPermission(menulist)
          self.$refs.grid.setSelection(self.init_selected)
          self.get_selected_data()
          console.log(self.selected, '已经选中的')
        }).catch(err => {
          self.$Message.error(err)
        })
      }
    }

    return {
      table: table,
      selected: selected,
      roleid: this.$route.query.roleid, // 角色id
      init_selected: [] // 能看到的选中的菜单
    }
  },
  methods: {
    queryAllPermission (lists) {
      let self = this
      let res_arr = []
      const getPermission = (data) => {
        data.forEach(item => {
          if (item.isRelation == '1' && item.children.length == 0) {
            res_arr.push(item.childCode)
          }
          if (item.children.length > 0) {
            getPermission(item.children)
          }
        })
        self.init_selected = res_arr
        return res_arr
      }
      getPermission(lists)
    },
    handleSelected () {
      console.log(this.$refs.grid.getSelectedRows(), '添加之后选中的getSelectedRows')
      this.get_selected_data()
      console.log(this.selected, '最终的id')
    },
    handleDeselected () {
      console.log(this.$refs.grid.getSelectedRows(), '减少之后选中的getSelectedRows')
      this.get_selected_data()
      console.log(this.selected, '最终的id')
    },
    handleSelectedAll () {
      console.log('全选')
      this.get_selected_data()
    },
    handleDeselectedAll () {
      console.log('取消全选')
      this.get_selected_data()
    },
    get_selected_data () {
      let selected_add = []
      let selected_row = this.$refs.grid.getSelectedRows()
      selected_row.forEach(item => {
        item.parentIdSet.forEach(subitem => {
          if (selected_add.indexOf(subitem) < 0) {
            selected_add.push(subitem)
          }
        })
      })
      this.selected = selected_add
    },
    goto_list () {
      this.$router.push({
        name: 'role_mgt'
      })
    },
    save_permission () {
      let self = this
      var postdata = {
        'txnBodyCom': {
          'menuId': this.selected.join(','),
          'roleId': this.roleid
        }
      }
      authorizeRole(postdata).then(res => {
        self.$Message.success(res.data.msg)
        setTimeout(function () {
          self.$router.push({
            name: 'role_mgt'
          })
        }, 1500)
      }).catch(err => {
        self.$Message.error(err)
      })
    }
  }
}
</script>
<style scoped>
/* .role_permission>>> thead .u-cell-checkbox{
    display: none
} */
.role_name{
    margin-bottom: 10px;
    font-size: 14px
}
</style>
