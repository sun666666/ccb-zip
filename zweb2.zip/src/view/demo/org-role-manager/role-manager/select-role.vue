<template>
  <div>
    <Modal v-model="add_newrole" width="900"  title="选择互斥角色" @on-ok="onOk" @on-cancel="onCancel">
      <Grid ref="grid" :data="table1" @on-selected="handleSelected" @on-deselected="handleDeselected"
            @on-selected-all="handleSelectedAll" @on-deselected-all="handleDeselectedAll"></Grid>
  </Modal>
  </div>
</template>
<script>
import { getRoleList } from '@/api/info.js'
import { getRoleListData, addRole, operateRole } from '@/api/org-role-manager'
import setChoices from '@/mixins/setChoices'
export default {
  props: {
    modal: {
      type: Boolean,
      default: false
    }
  },
  mixins: [setChoices],
  computed: {
    add_newrole: {
      get: function () {
        return this.modal
      },
      set: function (newValue) {
        /* this.$emit('toggleModal', 'permitUserModal', newValue) */
      }
    }
  },
  data () {
    let self = this
    var roleLevels = [
      {
        value: '0',
        label: '省级'
      },
      {
        value: '1',
        label: '市级'
      },
      {
        value: '2',
        label: '县级'
      },
      {
        value: '3',
        label: '乡级'
      },
      {
        value: '4',
        label: '村级'
      }
    ]
    let table1 = {
      nowrap: true,
      actionColumn: 'Action',
      indexCol: false,
      checkCol: true,
      multiSelect: true,
      static: false,
      pagination: true,
      total: 6,
      theme: 'simple',
      width: 800,
      columns: [
        { name: 'roleCode',
          title: '角色编码'
        },
        { name: 'roleName',
          title: '角色名称'
        },
        { name: 'roleLvl',
          title: '角色层级',
          width: 100,
          format: function (value, column, row) {
            let roleindex = roleLevels.findIndex(role => role.value == value)
            return '<span>' + roleLevels[roleindex].label + '</span>'
          }
        }
      ],
      query: {
        fields: [
          {
            name: 'roleId',
            title: '角色Id',
            hidden: true
          },
          {
            name: 'roleLvl',
            type: 'select',
            label: '角色层级',
            options: { choices: roleLevels }
          },
          {
            name: 'roleCode',
            label: '角色编码'
          },
          {
            name: 'roleName',
            label: '角色名称'
          }
        ],
        firstLineLayout: [{ name: 'roleLvl', style: { width: '100px' } }, { name: 'roleCode', style: { width: '150px' } }, { name: 'roleName', style: { width: '150px' } }],
        layout: [['roleLvl', 'roleCode', 'roleName']]
      },
      data: [],
      onLoadData: function (url, param, callback) {
        var postdata = {
          'txnBodyCom': {
            'roleLvl': param.roleLvl ? param.roleLvl : '',
            'roleCode': param.roleCode ? param.roleCode : '',
            'roleName': param.roleName ? param.roleName : '',
            'isEnable': '1',
            'staffId': self.$store.state.user.userId
          }
        }
        getRoleListData(postdata, {
          tRecInPage: param.pageSize,
          tPageJump: param.page
        }).then(res => {
          // 设置已选择的角色
          res.data.voList.forEach(item => {
            item.id = item.roleId
          })
          callback(res.data.voList ? res.data.voList : [],
            { total: res.data.txnCommCom ? res.data.txnCommCom.totalRec : 0 })
          self.$refs.grid.setSelection(self.selected_roles)
          self.get_selected_data()
        }).catch(err => {
          console.log('查询角色列表gsp/gld01014失败，报错信息：' + err)
          self.$Message.error('查询角色列表失败，报错信息：' + err)
        })
      }
    }
    return {
      data1: [
        {
          title: '省级',
          roleLvl: '0'
        },
        {
          title: '市级',
          roleLvl: '1'
        },
        {
          title: '县级',
          roleLvl: '2'
        },
        {
          title: '乡级',
          roleLvl: '3'
        },
        {
          title: '村级',
          roleLvl: '4'
        }
      ],
      table1: table1,
      roleLvl: '',
      selected_roles: [], // 已选中的角色Id
      selected_rows: [] // 已选中的角色信息
    }
  },
  mounted () {
    this.setChoices(this.$refs.grid, { role_description: { name: 'role_description' } })
  },
  methods: {
    onCancel () {

    },
    onOk () {
      console.log('点击确定')
      this.$emit('selected_rows', this.selected_rows)
    },
    handleSelect (data) {
      let self = this
      self.roleLvl = data[0].roleLvl
      self.$refs.grid.loadData()
    },
    handleSelected () {
      this.get_selected_data()
    },
    handleDeselected () {
      this.get_selected_data()
    },
    handleSelectedAll () {
      this.get_selected_data()
    },
    handleDeselectedAll () {
      this.get_selected_data()
    },
    get_selected_data () {
      let selected_roleId = []
      let selected_roles = []
      let selected_row = this.$refs.grid.getSelectedRows()
      selected_row.forEach(item => {
        if (selected_roleId.indexOf(item.roleId) < 0) {
          selected_roleId.push(item.roleId)
          selected_roles.push(item)
        }
      })
      this.selected_roles = selected_roleId
      this.selected_rows = selected_roles
    }
  }
}
</script>
<style lang="less">
  .eventTypeListModal{
    .ivu-modal-content{
      height: 100%;

      .ivu-modal-body{
        height: 90%;
        overflow-y: scroll;
      }
    }
  }

</style>
