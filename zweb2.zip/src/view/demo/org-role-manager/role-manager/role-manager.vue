<template>
  <div>
    <Card dis-hover>
      <Grid ref="grid" :data="config"></Grid>
    </Card>
  </div>
</template>

<script>
import { getRoleListData, operateRole, queryRoleListExport } from '@/api/org-role-manager'
import { exportExcelFile } from '@/libs/util'
import setChoices from '@/mixins/setChoices'

export default {
  name: 'role_manager',
  mixins: [setChoices],
  data () {
    let self = this
    var roleLevels = [
      {
        value: '0',
        label: '省级'
      },
      {
        value: '1',
        label: '市级'
      },
      {
        value: '2',
        label: '县级'
      },
      {
        value: '3',
        label: '乡级'
      },
      {
        value: '4',
        label: '村级'
      }
    ]
    let table = {
      nowrap: true,
      actionColumn: 'Action',
      indexCol: true,
      indexColTitle: '序号',
      indexColWidth: 60,
      theme: 'simple',
      pagination: true,
      columns: [
        { name: 'roleId',
          title: '角色Id',
          hidden: true
        },
        { name: 'roleLvl',
          title: '角色层级',
          format: function (value, column, row) {
            let roleindex = roleLevels.findIndex(role => role.value == value)
            return '<span>' + roleLevels[roleindex].label + '</span>'
          }
        },
        { name: 'roleCode',
          title: '角色编码'
        },
        { name: 'roleName',
          title: '角色名称'
        },
        { name: 'roleSeq',
          title: '角色排序'
        },
        { name: 'isEnable',
          title: '状态',
          format: function (value, column, row) {
            let status_text = ''
            if (value == '0') {
              status_text = '已禁用'
            } else if (value == '1') {
              status_text = '已启用'
            }
            return '<span>' + status_text + '</span>'
          }
        },
        { name: 'Action',
          title: '操作',
          width: 300,
          render: function (h, param) {
            var forbid_text
            forbid_text = param.row.isEnable == '0' ? '启用' : '禁用'
            var buttons = [
              param.grid.defaultDeleteRender(h, param.row)
            ]
            buttons.unshift(
              h('Button', {
                props: {
                  type: 'primary',
                  size: 'small'
                },
                style: {
                  margin: '0 5px'
                },
                on: {
                  click: function () {
                    if (param.row.isEnable == '0') {
                      self.$Message.info('已禁用角色不可编辑！')
                      return
                    }
                    self.$router.push({
                      name: 'edit_role',
                      query: {
                        roleId: param.row.roleId,
                        roleCode: param.row.roleCode,
                        roleName: param.row.roleName,
                        roleMemo: param.row.roleMemo,
                        roleSeq: param.row.roleSeq,
                        roleLvl: param.row.roleLvl
                      }
                    })
                  }
                }
              }, '编辑')
            )
            buttons.unshift(
              h('Button', {
                props: {
                  type: param.row.isEnable == '0' ? 'success' : 'default',
                  size: 'small'
                },
                style: {
                  margin: '0 5px'
                },
                on: {
                  click: function () {
                    var operate_type = param.row.isEnable == '0' ? '3' : '4'
                    var operate_res = param.row.isEnable == '0' ? '启用' : '禁用'
                    var postdata = {
                      'txnBodyCom': {
                        'roleId': param.row.roleId,
                        'operateType': operate_type
                      }
                    }
                    operateRole(postdata).then(res => {
                      self.$Message.success(`${operate_res}成功`)
                      self.$refs.grid.loadData()
                    }).catch(error => {
                      console.log(operate_res + 'gsp/gld01020失败，报错信息：' + error)
                      self.$Message.error(`${operate_res}失败`)
                    })
                  }
                }
              }, forbid_text)
            ),
            // buttons.push(
            //   h('Button',{
            //     props:{
            //       type:'info',
            //       size: 'small'
            //     },
            //     style : {
            //       margin : '0 5px'
            //     },
            //     on : {
            //       click : function(){
            //         self.$router.push({
            //           name:'role_user_list',
            //           query : {
            //             roleid : param.row.roleId,
            //             rolename : param.row.roleName
            //           }
            //         })
            //       }
            //     }
            //   },'用户清单')
            // ),
            buttons.push(
              h('Button', {
                props: {
                  type: 'warning',
                  size: 'small'
                },
                style: {
                  margin: '0 5px'
                },
                on: {
                  click: function () {
                    self.$router.push({
                      name: 'role_menu_permission',
                      query: {
                        roleid: param.row.roleId,
                        rolename: param.row.roleName
                      }
                    })
                  }
                }
              }, '授权菜单')
            )
            return h('div', {}, buttons)
          }
        }
      ],
      query: {
        fields: [
          {
            name: 'roleLvl',
            type: 'select',
            label: '角色层级',
            options: { choices: roleLevels }
          },
          {
            name: 'roleCode',
            label: '角色编码'
          },
          {
            name: 'roleName',
            label: '角色名称'
          },
          {
            name: 'isEnable',
            label: '是否启用',
            type: 'select',
            options: {
              choices: [
                {
                  label: '是',
                  value: '1'
                },
                {
                  label: '否',
                  value: '0'
                }
              ]
            }
          }
        ],
        firstLineLayout: [{ name: 'roleLvl', style: { width: '100px' } }, { name: 'roleCode', style: { width: '100px' } },
          { name: 'roleName', style: { width: '100px' } }, { name: 'isEnable', style: { width: '100px' } }],
        layout: [['roleLvl', 'roleCode', 'roleName', 'isEnable']]
      },
      buttons: [
        [
          { label: '新增角色',
            type: 'primary',
            onClick: function (target, store) {
              self.$router.push('add_role')
            }
          }],
        [ { label: '导出角色',
          type: 'primary',
          onClick: function (target, store) {
            var data = {
              'txnBodyCom': {
                'roleLvl': store.grid.$refs.query.value.roleLvl ? store.grid.$refs.query.value.roleLvl : '',
                'roleCode': store.grid.$refs.query.value.roleCode ? store.grid.$refs.query.value.roleCode : '',
                'roleName': store.grid.$refs.query.value.roleName ? store.grid.$refs.query.value.roleName : '',
                'isEnable': store.grid.$refs.query.value.isEnable ? store.grid.$refs.query.value.isEnable : '',
                'staffId': self.$store.state.user.userId
              }
            }

            queryRoleListExport(data).then(res => {
              exportExcelFile(res.data.filePath)
              self.$Message.success('导出角色成功！')
            }).catch(error => {
              console.log('角色Excle导出失败；' + error)
              self.$Message.error('角色Excle导出失败；' + error)
            })
          }
        }
        ]
      ],
      onDeleteRow: function (row, callback) {
        var postdata = {
          'txnBodyCom': {
            'roleId': row.roleId,
            'operateType': '2'
          }
        }
        operateRole(postdata).then(res => {
          self.$Message.success('删除成功')
          self.$refs.grid.loadData()
        })
      },
      onLoadData: function (url, param, callback) {
        var postdata = {
          'txnBodyCom': {
            'roleLvl': param.roleLvl ? param.roleLvl : '',
            'roleCode': param.roleCode ? param.roleCode : '',
            'roleName': param.roleName ? param.roleName : '',
            'isEnable': param.isEnable ? param.isEnable : '',
            'staffId': self.$store.state.user.userId
          }
        }
        getRoleListData(postdata, {
          tRecInPage: param.pageSize,
          tPageJump: param.page
        }).then(res => {
          console.log(res, 'res')
          // callback(res.data.voList?res.data.voList:[], { total: res.data.txnCommCom?res.data.txnCommCom.totalRec:0 });
          callback(res.data, { total: 6 })
        }).catch(err => {
          console.log('获取角色列表gsp/gld01014失败，报错信息：' + err)
          self.$Message.error('获取角色列表gsp/gld01014失败，报错信息：' + err)
        })
      }
    }
    let role_infor = [
      {
        name: 'basic',
        title: '',
        labelWidth: 150,
        staticSuffix: '_static',
        boxComponent: '',
        fields: [
          { name: 'roleCode', label: '角色编码', required: true, static: false },
          { name: 'roleName', label: '角色名称', required: true, static: false },
          { name: 'roleMemo', label: '角色描述' },
          { name: 'roleSeq', label: '角色排序', required: true },
          { name: 'roleLvl', label: '角色层级', type: 'select', required: true, options: { choices: roleLevels } }
        ],
        layout: [
          ['roleCode'],
          ['roleName'],
          ['roleMemo'],
          ['roleSeq'],
          ['roleLvl']
        ],
        boxOptions: { headerClass: 'primary' }
      }
    ]

    return {
      config: table,
      role_detail: {},
      role_infor: role_infor
    }
  },

  methods: {

  },
  mounted () {
    this.setChoices(this.$refs.grid, { role_description: { name: 'role_description' } })
  }
}
</script>
