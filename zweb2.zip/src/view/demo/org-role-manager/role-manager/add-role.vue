<template>
  <div>
    <Card :dis-hover="true">
      <Row>
        <build ref="build" :data="role_infor" :value="role_detail"></build>
      </Row>
      <Row>
        <Grid ref="grid" :data="config"></Grid>
      </Row>
      <Row>
        <i-col span="24" class="mt">
          <Button type="primary" @click="onOk" :loading="loading1">确定</Button>
          <Button type="default" @click="onClose">取消</Button>
        </i-col>
      </Row>
    </Card>
    <SelectRole :modal="roleModal" @selected_rows="addExclusiveRole"></SelectRole>
  </div>
</template>

<script>
import { addRole } from '@/api/org-role-manager'
import SelectRole from './select-role'

export default {
  name: 'add-role',
  components: {
    SelectRole
  },
  data () {
    let self = this
    let role_infor = [
      {
        name: 'basic',
        title: '',
        labelWidth: 150,
        staticSuffix: '_static',
        boxComponent: '',
        fields: [
          { name: 'roleCode', label: '角色编码', required: true, static: false },
          { name: 'roleName', label: '角色名称', required: true, static: false },
          { name: 'roleMemo', label: '角色描述' },
          { name: 'roleSeq', label: '角色排序', required: true },
          {
            name: 'roleLvl',
            label: '角色层级',
            type: 'select',
            required: true,
            options: {
              choices: [['0', '省级'], ['1', '市级'], ['2', '县级'], ['3', '乡级'], ['4', '村级']]
            }
          }
        ],
        layout: [
          ['roleCode'],
          ['roleName'],
          ['roleMemo'],
          ['roleSeq'],
          ['roleLvl']
        ],
        boxOptions: { headerClass: 'primary' }
      }
    ]
    let table = {
      editMode: 'row', // 行编辑模式
      nowrap: true,
      actionColumn: 'Action',
      checkCol: true,
      multiSelect: true,
      static: false,
      pagination: false,
      theme: 'simple',
      total: 10,
      columns: [
        {
          name: 'roleId',
          title: '角色编码',
          hidden: true
        },
        {
          name: 'roleCode',
          title: '角色编码'
        },
        {
          name: 'roleName',
          title: '角色名称'
        },
        {
          name: 'roleLvl',
          title: '角色层级',
          editor: {
            type: 'select',
            options: {
              filterable: true,
              remote: true,
              choices: [['0', '省级'], ['1', '市级'], ['2', '县级'], ['3', '乡级'], ['4', '村级']]
            }
          }
        }
      ],
      buttons: [
        [
          {
            label: '添加互斥角色',
            type: 'primary',
            onClick: function () {
              self.roleModal = !self.roleModal
            }
          }
        ],
        [
          {
            label: '删除互斥角色',
            type: 'primary',
            onClick: function (target, store) {
              let selected_row = self.$refs.grid.getSelectedRows()
              for (let v in selected_row) {
                store.removeRow(selected_row[v])
              }
            }
          }
        ]
      ],
      onLoadData: function (url, param, callback) {
        callback('')
      }
    }
    return {
      role_infor: role_infor,
      config: table,
      roleModal: false,
      selected_rows: [],
      role_detail: {},
      loading1: false
    }
  },
  methods: {
    addExclusiveRole (value) {
      this.$refs['grid'].store.states.data = value
    },
    onSelectRole: function () {
      console.log('选择的互斥角色列表：' + this.selected_rows)
    },
    onClose: function () {
      this.$router.push('role_mgt')
    },
    onOk: function () {
      let self = this
      // 请求后台addRole
      let new_detail = this.role_detail
      if (/^[0-9]+$/.test(new_detail.roleSeq) === false) {
        this.$Message.error('排序码必须为数字！')
        return
      }
      if (new_detail.roleCode && new_detail.roleName && new_detail.roleLvl) {
        var mutexIds = ''
        if (this.$refs['grid'].store.states.data.length > 0) {
          let rowdata = this.$refs['grid'].store.states.data
          for (let v in rowdata) {
            if (v == '0') {
              mutexIds = rowdata[v].roleId
            } else {
              mutexIds += ',' + rowdata[v].roleId
            }
          }
        }
        var postdata = {
          'txnBodyCom': {
            'roleCode': new_detail.roleCode,
            'roleName': new_detail.roleName,
            'roleMemo': new_detail.roleMemo,
            'roleSeq': String(new_detail.roleSeq),
            'roleLvl': new_detail.roleLvl,
            'roleId': new_detail.roleId,
            'mutexIds': mutexIds
          }
        }
        self.loading1 = true
        addRole(postdata).then(res => {
          this.$Message.success('保存成功')
          self.loading1 = false
          // this.$refs.grid.loadData();
          this.add_newrole = false
          this.$router.push('role_mgt')
        }).catch(err => {
          self.loading1 = false
          console.log('角色新增失败gsp/gld01005，报错信息：' + err)
          this.$Message.error('角色新增失败gsp/gld01005，报错信息：' + err)
        })
      } else {
        self.loading1 = false
        this.$Message.error('请完善信息后再提交')
      }
    }
  }
}
</script>

<style scoped>

</style>
