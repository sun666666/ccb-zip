<template>
  <div>
    <p class="role_name">
      当前操作的角色名称：
      <b>{{$route.query.rolename}}</b>
    </p>
    <Card dis-hover>
      <Grid ref="grid" :data="user_list"></Grid>
    </Card>
  </div>
</template>
<script>
import { getPermittedUser, delPermittedUser } from '@/api/org-role-manager'
export default {
  data () {
    let self = this
    let user_list = {
      nowrap: true,
      indexCol: true,
      indexColTitle: '序号',
      indexColWidth: 60,
      actionColumn: 'Action',
      theme: 'simple',
      pagination: true,
      buttons: [
        [
          {
            label: '新增授权用户',
            type: 'primary',
            onClick: function (target, store) {
              self.$router.push({
                name: 'role_user_permission',
                query: {
                  roleid: self.roleid,
                  rolename: self.rolename
                }
              })
            }
          },
          {
            label: '返回角色列表',
            type: 'default',
            onClick: function (target, store) {
              self.$router.push({
                name: 'role_mgt'
              })
            }
          }
        ]
      ],
      columns: [
        {
          title: '登录账号',
          name: 'loginNo',
          width: 150
        },
        {
          title: '用户姓名',
          name: 'staffName',
          width: 150
        },
        {
          title: '区域',
          name: 'regionName'
        },
        {
          title: '机构',
          name: 'orgName'
        },
        {
          title: '操作',
          name: 'Action',
          width: 80,
          render: function (h, param) {
            var buttons = [param.grid.defaultDeleteRender(h, param.row)]
            return h('div', {}, buttons)
          }
        }
      ],
      data: [],
      onLoadData: function (url, param, callback) {
        var postdata = {
          txnBodyCom: {
            roleId: self.roleid,
            type: '2'
          }
        }
        getPermittedUser(postdata, {
          tRecInPage: param.pageSize,
          tPageJump: param.page
        })
          .then(res => {
            console.log(res)
            callback(res.data.list ? res.data.list : [], {
              total: res.data.txnCommCom ? res.data.txnCommCom.totalRec : 0
            })
          })
          .catch(err => {
            self.$Message.error(err)
          })
      },
      onDeleteRow: function (row, callback) {
        var postdata = {
          txnBodyCom: {
            staffId: row.staffid,
            roleId: row.roleid
          }
        }
        delPermittedUser(postdata)
          .then(res => {
            self.$Message.success('移除成功')
            self.$refs.grid.loadData()
          })
          .catch(err => {
            self.$Message.error(err)
          })
      }
    }
    return {
      user_list: user_list,
      roleid: this.$route.query.roleid, // 角色id
      rolename: this.$route.query.rolename // 角色id
    }
  }
}
</script>
<style scoped>
.role_name {
  margin-bottom: 10px;
  font-size: 14px;
}
</style>
