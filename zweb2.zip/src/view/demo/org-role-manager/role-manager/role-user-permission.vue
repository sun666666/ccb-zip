<template>
  <div>
    <Row>
      <!-- <i-col span="12">
          <orgTree ref="orgTree" @on-select-change="orgSelected"></orgTree>
      </i-col>-->
      <!-- <u-col span="12"> -->
      <i-col span="12">
        <Card dis-hover>
          <Grid
            ref="grid"
            :data="table"
            @on-selected-all="userSelectedAll"
            @on-deselected-all="userDeselectedAll"
            @on-selected="userSelected"
            @on-deselected="userDeselected"
          ></Grid>
        </Card>
      </i-col>
      <u-col span="12">
        <Card dis-hover>
          <p>待授权用户列表</p>
          <Grid ref="grid1" :data="selected_table" :value="value1"></Grid>
        </Card>
      </u-col>
      <!-- </u-col> -->
    </Row>
  </div>
</template>
<script>
import orgTree from '_bc/org-tree.vue'
import Bus from '@/libs/bus'
import { setTimeout } from 'timers'
import {
  searchUserList,
  getPermittedUser,
  addPermittedUser
} from '@/api/org-role-manager'

export default {
  components: { orgTree },
  data () {
    let self = this
    let value1 = []
    let table = {
      nowrap: true,
      theme: 'simple',
      multiSelect: true,
      pagination: true,
      checkCol: true,
      checkColWidth: 30,
      autoLoad: false,
      data: [],
      columns: [
        { name: 'loginNo', title: '登录账号', width: 80 },
        { name: 'staffName', title: '用户姓名', width: 80 },
        { name: 'regionName', title: '区域名称' },
        { name: 'orgName', title: '机构名称' },
        { name: 'staffid', title: '用户id', hidden: true }
      ],
      onCheckable: function (row) {
        var r = !row.isPermittedTag
        return r
      },
      onLoadData: function (url, param, callback) {
        console.log(param, '获取参数')
        // 根据机构查询用户信息;
        self.orgId = param.orgId
        let paging = {
          tRecInPage: param.pageSize,
          tPageJump: param.page
        }
        searchUserList(
          param.regionCode,
          param.orgCode,
          param.loginNo,
          self.$store.state.user.userId,
          param.staffName,
          paging
        ).then(res => {
          // 设置已授权标识
          res.data.list.forEach(item => {
            item.id = item.staffid
            self.init_permitted.forEach(subitem => {
              if (item.id === subitem) {
                item.isPermittedTag = true
              }
            })
          })
          if (res.data.list) {
            callback(res.data.list, { total: res.data.txnCommCom.totalRec })
          }
          // console.log(self.init_permitted);
          self.$refs.grid.setSelection(self.init_permitted)
        }).catch(err => {
          self.$Message.error(err)
        })
      },
      query: {
        fields: [
          {
            name: 'regionCode',
            label: '所属区域',
            type: 'RegionTreeSelect',
            onChange: function (v, all) {
              localStorage.setItem('chooseRegionCode', v)
              Bus.$emit('regionChange', v)
            }
          },
          {
            name: 'orgId',
            label: '所属机构',
            type: 'OrgTreeSelect',
            onChange: function (v, all) {
              self.orgId = v
            },
            options: { idField: 'orgId' }
          },
          { name: 'loginNo', type: 'str', label: '登录账号' }
        ],
        layout: [['regionCode', 'orgId', 'loginNo']]
      }
    }
    let selected_table = {
      nowrap: true,
      theme: 'simple',
      pagination: false,
      data: [],
      columns: [
        { name: 'loginNo', title: '登录账号' },
        { name: 'staffName', title: '用户姓名' },
        { name: 'regionName', title: '区域' },
        { name: 'orgName', title: '机构' }
      ],
      rightButtons: [
        [
          {
            label: '确认授权',
            type: 'primary',
            onClick: function (target, store) {
              let staff_arr = []
              if (self.value1.length > 0) {
                self.value1.forEach(item => {
                  staff_arr.push(item.id)
                })
                staff_arr = staff_arr.concat(self.init_permitted)
                self.staffid = staff_arr.join(',')
                let postdata = {
                  txnBodyCom: {
                    staffId: self.staffid,
                    roleId: self.$route.query.roleid,
                    type: '1'
                  }
                }
                addPermittedUser(postdata).then(res => {
                  self.$Message.success('授权成功')
                  setTimeout(function () {
                    self.$router.push({
                      name: 'role_user_list',
                      query: {
                        roleid: self.roleid,
                        rolename: self.rolename
                      }
                    })
                  }, 2000)
                }).catch(err => {
                  self.$Message.error({ content: err, duration: 4 })
                  // self.$Modal.error({content:err,title:'error'});
                })
              } else {
                self.$Message.error('请选择要授权的用户')
              }
            }
          },
          {
            label: '返回',
            type: 'default',
            onClick: function (target, store) {
              self.$router.push({
                name: 'role_user_list',
                query: {
                  roleid: self.roleid,
                  rolename: self.rolename
                }
              })
            }
          }
        ]
      ],
      onLoadData: function (url, param, callback) {
        callback()
      }
    }
    return {
      table: table,
      selected_table: selected_table, // 已经选择的用户列表
      value1: value1,
      selectedUser: [],
      init_permitted: [], // 已经授权用户id
      roleid: this.$route.query.roleid, // 角色id
      rolename: this.$route.query.rolename, // 角色id
      orgId: '',
      is_error: false,
      error_text: ''
    }
  },
  mounted () {
    this.getAllPermittedUser()
  },
  methods: {
    orgSelected (e) {
      let self = this
      let paging = {
        tRecInPage: '',
        tPageJump: ''
      }
      localStorage.setItem('orgId', e.childCode)
      if (e !== undefined) {
        searchUserList(e.regionCode, e.orgId, '', paging).then(res => {
          this.$refs['grid'].store.states.data = res.data.list
          self.$refs.grid.loadData()
        }).catch(err => {
          self.$Message.error(err)
        })
      }
    },
    getAllPermittedUser () {
      let self = this
      self.init_permitted = []
      var postdata = {
        txnBodyCom: {
          roleId: self.roleid,
          type: '1'
        }
      }
      getPermittedUser(postdata)
        .then(res => {
          let allusers = res.data.list
          allusers.forEach(item => {
            self.init_permitted.push(item.staffid)
          })
          self.$refs.grid.loadData()
        })
        .catch(err => {
          self.$Message.error(err)
        })
    },
    userSelected (row) {
      // let is_new = true;
      // this.value1.forEach(item => {
      //   if(item.id == row.id){
      //     is_new  = false;
      //   }
      // })
      // if(is_new){
      this.value1.push(row)
      // }

      this.$refs.grid1.loadData()
    },
    userDeselected (row) {
      let res_arr = []
      this.value1.forEach((item, index) => {
        if (row.id !== item.id) {
          res_arr.push(item)
        }
      })
      this.value1 = res_arr
      this.$refs.grid1.loadData()
    },
    userSelectedAll () {
      let selected = this.$refs.grid.getSelectedRows()
      this.init_permitted.forEach(item => {
        selected.forEach((subitem, index) => {
          if (item === subitem.staffid) {
            selected.splice(index, 1)
          }
        })
      })
      // for (let i = 0; i < this.selected.length; i++) {
      //   for (let j = 0; j < this.selectedRoles.length; j++) {
      //     if (this.selected[j].roleId === this.selectedRoles[i]) {
      //       this.selected.splice(j, 1);
      //       j--;
      //     }
      //   }
      // }
      this.value1 = selected
      this.$refs.grid1.loadData()
    },
    userDeselectedAll (row) {
      let selected = this.$refs.grid.getSelectedRows()
      this.init_permitted.forEach(item => {
        selected.forEach((subitem, index) => {
          if (item === subitem.staffid) {
            selected.splice(index, 1)
          }
        })
      })
      this.value1 = selected
      this.$refs.grid.setSelection(this.init_permitted)
      this.$refs.grid1.loadData()
    }
  }
}
</script>
