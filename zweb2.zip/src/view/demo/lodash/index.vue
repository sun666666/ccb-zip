<template>
  <div>
    <p>Lodash是一个一致性、模块化、高性能的 JavaScript 实用工具库。</p>
    <pre>
      var array = [1, 2, 3, 1, 2, 3];
      _.pull(array, 2, 3);
      console.log(array);
      // => [1, 1]
    </pre>
  </div>
</template>

<script>
export default {
  name: 'lodash_page',
  data () { return {} },
  created () {
    var array = [1, 2, 3, 1, 2, 3]
    this.$lodash.pull(array, 2, 3)
    console.log(array)
  }
}
</script>

<style>
</style>
