<template>
  <Row>
    <i-col offset="1" span="22">
      <Build ref="build" :data="data" :value="value" :errors="errors" ></Build>
    </i-col>
  </Row>
</template>

<script>
import { fixDownloadURL } from '@/libs/util'
import setChoices from '@/mixins/setChoices'
import Bus from '@/libs/bus'
import { password } from '@/libs/password'

export default {
  mixins: [setChoices],
  data: function () {
    var self = this
    var data = [
      {
        name: 'basic',
        title: '基本信息',
        labelWidth: 150,
        staticSuffix: '_static',
        fields: [
          { name: 'select1',
            label: '选择1',
            type: 'select',
            required: true,
            is_choice: true,
            onChange: function (value, alldata) {
              self.$set(alldata, 'select2', value)
            }
          },
          { name: 'select2', label: '选择2', type: 'str', static: true },
          { name: 'uploader',
            label: '上传文件',
            type: 'UploaderInput',
            onChange: function (v, all) {
              self.$set(all, 'download', Object.assign({}, v))
              self.$set(all.download, 'filepath', fixDownloadURL(all.uploader.filepath))
            },
            options: {
              size: 50 * 1024,
              accept: 'image/*',
              stoptable: true,
              showProgress: true
            } },
          { name: 'download',
            label: '下载文件',
            type: 'str',
            static: true,
            format: (v) => {
              return `<img width="300px" src="${self.value.download.filepath}"></img>`
            } },
          { name: 'uploader1',
            label: '上传文件',
            type: 'UploaderButton',
            onChange: function (v, all) {
              self.$set(all, 'download1', Object.assign({}, v))
              self.$set(all.download1, 'filepath', fixDownloadURL(all.uploader1.filepath))
            },
            options: {
              private_bucket: false,
              title: '上传',
              'btn-style': 'ivu-btn ivu-btn-text'
            } },
          { name: 'download1',
            label: '下载文件',
            type: 'str',
            static: true,
            format: (v) => {
              return `<img width="300px" src="${self.value.download1.filepath}"></img>`
            } },
          { name: 'uploader2',
            label: '上传图片',
            type: 'UploaderImg',
            onChange: function (v, all) {
              self.$set(all, 'download2', Object.assign({}, v))
              self.$set(all.download2, 'filepath', fixDownloadURL(all.uploader2.filepath))
            } },
          { name: 'download2',
            label: '图片',
            type: 'str',
            static: true,
            format: (v) => {
              return `<img width="300px" src="${self.value.download2.filepath}"></img>`
            } },
          { name: 'region1',
            label: '区域1',
            type: 'RegionTreeSelect',
            required: true,
            rule: { type: 'object' },
            options: { labelInValue: true },
            onChange: function (v, all) {
              console.log('=======', v)
              Bus.$emit('regionChange', v)
            },
            on: { 'on-select-change': function (v) {
              console.log('on-select-change', v)
            } } },
          { name: 'org1',
            label: '机构1',
            type: 'OrgTreeSelect',
            multiple: true,
            required: true,
            options: { multiple: true, labelInValue: true },
            on: { 'on-select-change': function (v) {
              console.log('on-select-change', v)
            } }
          },
          { name: 'region2',
            label: '区域2',
            type: 'RegionTreeSelect',
            multiple: true,
            required: true,
            options: { labelInValue: true, multiple: true },
            onChange: function (v, all) {
              console.log('=======', v)
            },
            on: { 'on-select-change': function (v) {
              console.log('on-select-change', v)
            } } },
          { name: 'password',
            label: ' ',
            type: 'Input',
            options: { search: true, 'enter-button': '生成密码' },
            on: { 'on-search': function () {
              if (self.value.password) {
                self.$set(self.value, 'password_result', password(self.value.password))
              } else {
                self.$Message.error('密码不能为空')
              }
            } }
          },
          { name: 'password_result', label: '密码MD5结果', type: 'string', static: true },
          { name: 'editor', label: '编辑器', type: 'Editor', required: true }
        ],
        layout: [
          ['select1', 'select2'],
          ['uploader', 'download'],
          ['uploader1', 'download1'],
          ['uploader2', 'download2'],
          ['region1', 'org1'],
          [{ name: 'region2', colspan: 12 }],
          ['password', 'password_result'],
          ['editor']
        ],
        boxOptions: { widthBorder: false, headerClass: 'primary' },
        buttons: {
          items: [
            [{ label: '查看结果',
              type: 'primary',
              onClick: function (target, data) {
                console.log(data)
              }
            }]
          ]
        }
      }
    ]
    return {
      data: data,
      value: {
        select1: '',
        select2: '',
        editor: '<p>abcd</p>',
        region1: {}
      },
      errors: {}
    }
  },
  methods: {
    save: function (error) {
      if (error) {
        this.$Message.error(error)
      } else {
        this.$Message.info('saved')
      }
    }
  },
  mounted () {
    this.setChoices(this.$refs.build, { select1: { name: 'convenientlyType' } })
    this.value.region1 = { value: '2010001', label: '昆明市' }
    this.value.org1 = [{ label: '产品研发部', value: '2' }, { label: '销售部', value: '3' }]
    this.value.region2 = [{ value: '2010001', label: '昆明市' }]
  }
}
</script>
