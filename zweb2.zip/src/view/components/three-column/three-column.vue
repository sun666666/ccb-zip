<template>
  <div class="main-content">
    <Row :gutter="16" class-name="row">
      <i-col span="4" class-name="column">col-4</i-col>
      <i-col span="4" class-name="column">col-4</i-col>
      <i-col span="16" class-name="column">col-16</i-col>
    </Row>
  </div>
</template>

<script>
export default {
  name: 'three_column',
  data () {
    return {
    }
  },
  methods: {
  },
  mounted () {
  }
}
</script>

<style lang="less">
@baseColor: ~"#dc9387";
.main-content{
  height:100%
}
.row{
  height:100%
}
.column{
  &:not(:last-child){
    border-right: #ccc 1px solid;
  }

  height: 100%;
}
</style>
