import { getParams, getToken } from '@/libs/util'
import { getMenuData } from '@/api/data'
const USER_MAP = {
  super_admin: {
    govStaffSubOutVo: {
      loginNo: 'super_admin',
      staffid: '1',
      token: 'super_admin',
      avator: 'avator.png'
    },
    menuTree: [],
    permission: ['super_admin', 'admin', 'regional_mgt', 'organization_mgt', 'role_mgt', 'add_role', 'edit_role', 'role_user_list', 'role_menu_permission', 'role_user_permission', 'user_mgt', 'role_list', 'user_permission', 'user_add', 'menu_mgt', 'system_log', 'ccbtable1', 'ccbtable2', 'ccbtable3']
  },
  admin: {
    govStaffSubOutVo: {
      loginNo: 'admin',
      staffid: '2',
      token: 'admin',
      avator: 'avator.png'
    },
    menuTree: [],
    permission: ['admin']
  }
}

getMenuData().then(res => {
  USER_MAP['super_admin'].menuTree = res.data.menuList
})

export const login = req => {
  req = JSON.parse(req.body)
  let userInfo = USER_MAP[req.txnBodyCom.loginno]
  return { token: userInfo && userInfo.govStaffSubOutVo.token }
}

export const getUserInfo = req => {
  // const params = getParams(req.url)
  return USER_MAP[getToken()]
}

export const logout = req => {
  return {}
}
