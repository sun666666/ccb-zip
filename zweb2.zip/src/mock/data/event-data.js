export const eventData =
  [
    {
      id: 1,
      shortMatterName: '事项简称1（点击查看目录/区域/标签/修改记录）',
      matterName: '实施清单事项全称（外链则为“外部链接”）',
      object: '',
      enableFlag: '00'
    },
    {
      id: 2,
      shortMatterName: '事项简称1（点击查看目录/区域/标签/修改记录）',
      matterName: '实施清单事项全称（外链则为“外部链接”）',
      object: '',
      enableFlag: '00'
    },
    {
      id: 3,
      shortMatterName: '事项简称1（点击查看目录/区域/标签/修改记录）',
      matterName: '实施清单事项全称（外链则为“外部链接”）',
      object: '',
      enableFlag: '01'
    },
    {
      id: 4,
      shortMatterName: '事项简称1（点击查看目录/区域/标签/修改记录）',
      matterName: '实施清单事项全称（外链则为“外部链接”）',
      object: '',
      enableFlag: '01'
    }
  ]
export const eventConfigData =
  [
    {
      name: '云南省公安局001',
      fullName: '事项全称',
      date: '2016-10-03'
    },
    {
      name: '云南省公安局002',
      fullName: '事项全称',
      date: '2016-10-01'
    },
    {
      name: '云南省公安局003',
      fullName: '事项全称',
      date: '2016-10-02'
    }
  ]
/*  export const eventData =
  {
    "C-API-Status":"01",
    "C-Response-Desc":"AuthFilter occur Exception : dynamic password for user incorrect or expired"
  } */

export const eventInfo = {
  id: '123',
  matterType: '00',
  serviceObj: '2',
  matterId: '321',
  matterName: 'abc',
  shortMatterName: '缩写事项名称',
  categoryIds: [{ 'categoryId': '111', 'categoryName': '户籍' }, { 'categoryId': '222', 'categoryName': '办理类' }],
  matterIcon: '',
  handleWay: ['0', '2'],
  openHandleFlag: '00',
  visitHandleFlag: '01',
  loginHandleFlag: '01',
  faceHandleFlag: '00',
  inlineApply: '01'

}

export const eventTypeData = [
  {
    categoryCode: '0000',
    categoryName: '职业资格'
  },
  {
    categoryCode: '0001',
    categoryName: '户籍办理'
  },
  {
    categoryCode: '0002',
    categoryName: '年检年审'
  },
  {
    categoryCode: '0003',
    categoryName: '出境入境'
  },
  {
    categoryCode: '0004',
    categoryName: '证件办理'
  },
  {
    categoryCode: '0005',
    categoryName: '医疗卫生'
  },
  {
    categoryCode: '0000',
    categoryName: '职业资格'
  },
  {
    categoryCode: '0001',
    categoryName: '户籍办理'
  },
  {
    categoryCode: '0002',
    categoryName: '年检年审'
  },
  {
    categoryCode: '0003',
    categoryName: '出境入境'
  },
  {
    categoryCode: '0004',
    categoryName: '证件办理'
  },
  {
    categoryCode: '0005',
    categoryName: '医疗卫生'
  },
  {
    categoryCode: '0000',
    categoryName: '职业资格'
  },
  {
    categoryCode: '0001',
    categoryName: '户籍办理'
  },
  {
    categoryCode: '0002',
    categoryName: '年检年审'
  },
  {
    categoryCode: '0003',
    categoryName: '出境入境'
  },
  {
    categoryCode: '0004',
    categoryName: '证件办理'
  },
  {
    categoryCode: '0005',
    categoryName: '医疗卫生'
  }
]

export const matterCategory = [
  {
    parentName: '按主题',
    categoryName: '其他主题'
  },
  {
    parentName: '我要缴费',
    categoryName: '我要缴费'
  }
]
