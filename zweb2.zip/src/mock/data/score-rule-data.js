export const scoreRuleData = [
  { id: 1, integral_code: '7days_sign', app_status: 'OPEN', integral_rule_name: '连续签到7天', isBetween: '开启' },
  { id: 2, integral_code: '30days_sign', app_status: 'CLOSE', integral_rule_name: '连续签到30天', isBetween: '开启' },
  { id: 3, integral_code: '1month_sign', app_status: 'OPEN', integral_rule_name: '连续签到1个月', isBetween: '禁用' },
  { id: 4, integral_code: 'ccb_pay', app_status: 'CLOSE', integral_rule_name: '建行支付', isBetween: '开启' },
  { id: 5, integral_code: '1year_sign', app_status: 'OPEN', integral_rule_name: '连续签到1年', isBetween: '禁用' },
  { id: 6, integral_code: 'ccb_pay', app_status: 'OPEN', integral_rule_name: '建行支付', isBetween: '开启' },
  { id: 7, integral_code: 'other', app_status: 'OPEN', integral_rule_name: '其他', isBetween: '开启' },
  { id: 8, integral_code: 'ccb_pay', app_status: 'OPEN', integral_rule_name: '建行支付', isBetween: '开启' },
  { id: 9, integral_code: 'other', app_status: 'OPEN', integral_rule_name: '其他', isBetween: '开启' },
  { id: 10, integral_code: 'ccb_pay', app_status: 'OPEN', integral_rule_name: '建行支付', isBetween: '开启' }
]
