export const hotwordSearchData = [
  {
    KEYWORD: 'test111',
    KEYWORDSORT: '1',
    PUBLICFLAG: '01'
  },
  {
    KEYWORD: 'test111',
    KEYWORDSORT: '1',
    PUBLICFLAG: '01'
  },
  {
    KEYWORD: 'test111',
    KEYWORDSORT: '1',
    PUBLICFLAG: '01'
  },
  {
    KEYWORD: 'test111',
    KEYWORDSORT: '1',
    PUBLICFLAG: '01'
  },
  {
    KEYWORD: 'test111',
    KEYWORDSORT: '1',
    PUBLICFLAG: '01'
  },
  {
    KEYWORD: 'test111',
    KEYWORDSORT: '1',
    PUBLICFLAG: '01'
  }
]
