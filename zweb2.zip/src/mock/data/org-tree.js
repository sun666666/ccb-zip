export default [{
  childCode: '0',
  orgName: 'XXX科技有限公司',
  children: [{
    childCode: '2',
    orgName: '产品研发部',
    children: [{
      childCode: '5',
      orgName: '研发-前端'
    }, {
      childCode: '6',
      orgName: '研发-后端'
    }, {
      childCode: '9',
      orgName: 'UI设计'
    }, {
      childCode: '10',
      orgName: '产品经理'
    }]
  },
  {
    childCode: '3',
    orgName: '销售部',
    children: [{
      childCode: '7',
      orgName: '销售一部'
    }, {
      childCode: '8',
      orgName: '销售二部'
    }]
  },
  {
    childCode: '4',
    orgName: '财务部'
  }, {
    childCode: '11',
    orgName: 'HR人事'
  }
  ]
}]
