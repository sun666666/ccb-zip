export const serviceAgreementData = [
  {
    service_agreement_id: '111',
    AGREEMENT_NAME: '注册',
    service_agreement_detail: '服务协议11111'
  },
  {
    service_agreement_id: '222',
    AGREEMENT_NAME: '测试111',
    service_agreement_detail: '服务协议22222'
  },
  {
    service_agreement_id: '333',
    AGREEMENT_NAME: '测试222',
    service_agreement_detail: '服务协议3333'
  },
  {
    service_agreement_id: '444',
    AGREEMENT_NAME: 'testservice111',
    service_agreement_detail: '服务协议4444'
  },
  {
    service_agreement_id: '555',
    AGREEMENT_NAME: 'haha',
    service_agreement_detail: '服务协议5555'
  },
  {
    service_agreement_id: '666',
    AGREEMENT_NAME: 'testservice222',
    service_agreement_detail: '服务协议6666'
  },
  {
    service_agreement_id: '777',
    AGREEMENT_NAME: 'test333',
    service_agreement_detail: '服务协议7777'
  }
]
