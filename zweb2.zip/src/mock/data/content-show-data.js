export const contentShowData = [{
  title: '目录',
  expand: true,
  selected: true,
  children: [
    {
      title: 'APP',
      expand: false,
      children: [
        {
          title: '首页',
          disabled: true,
          postmail: 1111,
          role: '首页'
        },
        {
          title: '服务',
          postmail: 1234,
          role: '服务'
        },
        {
          title: '应用',
          postmail: 1222,
          role: '应用'
        },
        {
          title: '互动',
          postmail: 1333,
          role: '互动'
        },
        {
          title: '我的',
          postmail: 1444,
          role: '我的'
        }
      ]
    },
    {
      title: 'PC',
      expand: false,
      children: [
        {
          title: '首页',
          disabled: true,
          postmail: 1111,
          role: '首页'
        },
        {
          title: '服务',
          postmail: 1234,
          role: '服务'
        },
        {
          title: '应用',
          postmail: 1222,
          role: '应用'
        },
        {
          title: '互动',
          postmail: 1333,
          role: '互动'
        },
        {
          title: '我的',
          postmail: 1444,
          role: '我的'
        }
      ]
    },
    {
      title: 'STM',
      expand: false,
      children: [
        {
          title: '首页',
          disabled: true,
          postmail: 1111,
          role: '首页'
        },
        {
          title: '服务',
          postmail: 1234,
          role: '服务'
        },
        {
          title: '应用',
          postmail: 1222,
          role: '应用'
        },
        {
          title: '互动',
          postmail: 1333,
          role: '互动'
        },
        {
          title: '我的',
          postmail: 1444,
          role: '我的'
        }
      ]
    },
    {
      title: '裕农通',
      expand: false,
      children: [
        {
          title: '首页',
          disabled: true,
          postmail: 1111,
          role: '首页'
        },
        {
          title: '服务',
          postmail: 1234,
          role: '服务'
        },
        {
          title: '应用',
          postmail: 1222,
          role: '应用'
        },
        {
          title: '互动',
          postmail: 1333,
          role: '互动'
        },
        {
          title: '我的',
          postmail: 1444,
          role: '我的'
        }
      ]
    }
  ] }
]

export const contentShowListData = [
  { id: 1, integral_code: '首页', app_status: 'OPEN', make_time: '2018-03-14', isBetween: '开启' },
  { id: 2, integral_code: '服务', app_status: 'CLOSE', make_time: '2018-03-14', isBetween: '开启' },
  { id: 3, integral_code: '应用', app_status: 'OPEN', make_time: '2018-03-14', isBetween: '禁用' },
  { id: 4, integral_code: '互动', app_status: 'CLOSE', make_time: '2018-03-14', isBetween: '开启' },
  { id: 5, integral_code: '我的', app_status: 'OPEN', make_time: '2018-03-14', isBetween: '禁用' }
]
