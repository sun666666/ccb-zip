export const userData = [
  {
    certNo: '11',
    certType: '1',
    createTime: 156117436000,
    isEnable: '1',
    loginNo: 'yn1',
    orgCode: 'test',
    orgId: 'test',
    orgName: '山东',
    regionCode: '37',
    regionName: '潍坊',
    staffMobile: '18612481388',
    staffName: 'mfg',
    staffid: '1',
    staffpassword: '123456'
  }
]
