export const illegalFundRaisingList = [
  {
    id: '1',
    report_title: '测试1',
    report_user: '黄志超',
    telephone: '13456774565',
    report_date: '2019-03-15 22:00:00',
    check_status: '未审核'
  }, {
    id: '2',
    report_title: '测试2',
    report_user: '黄志超',
    telephone: '13456774565',
    report_date: '2019-03-15 22:00:00',
    check_status: '未审核'
  }, {
    id: '3',
    report_title: '测试test',
    report_user: '黄志超',
    telephone: '13456774565',
    report_date: '2019-03-15 22:00:00',
    check_status: '未审核'
  }, {
    id: '4',
    report_title: '测试test',
    report_user: '黄志超',
    telephone: '13456774565',
    report_date: '2019-03-15 22:00:00',
    check_status: '未审核'
  }, {
    id: '5',
    report_title: '测试',
    report_user: '黄志超',
    telephone: '13456774565',
    report_date: '2019-03-15 22:00:00',
    check_status: '未审核'
  }, {
    id: '6',
    report_title: '测试',
    report_user: '黄志超',
    telephone: '13456774565',
    report_date: '2019-03-15 22:00:00',
    check_status: '未审核'
  }
]

export const illegalFundRaisingDetail = {
  report_user: '黄志超',
  telephone: '13456774565',
  report_number: '20190808000100001',
  report_title: '举报企业涉嫌违法',
  report_reason: '高收益低门槛快回报 返租回购 高额回报',
  report_content: 'test',
  local_situation: [
    { id: '1' },
    { id: '2' }
  ],
  report_address: '大连',
  exam_result: '审核不通过',
  clue_opinion: '感谢您的参与，欢迎下次举报'
}
