export default {
  txnCommCom: {
    totalPage: 1,
    totalRec: 6
  },
  list: [
    { REGIONNAME: '昆明市1', REGIONCODE: '2010001', CITY: '昆明市' },
    { REGIONNAME: '昆明市2', REGIONCODE: '2010002', CITY: '昆明市' },
    { REGIONNAME: '昆明市3', REGIONCODE: '2010003', CITY: '昆明市' },
    { REGIONNAME: '昆明市4', REGIONCODE: '2010004', CITY: '昆明市' },
    { REGIONNAME: '昆明市5', REGIONCODE: '2010005', CITY: '昆明市' },
    { REGIONNAME: '昆明市6', REGIONCODE: '2010006', CITY: '昆明市' }
  ]
}
