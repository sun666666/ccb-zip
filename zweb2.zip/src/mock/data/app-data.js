export const appData = [
  {
    id: 1,
    app_name: 'APP-A1',
    app_status: 'OPEN',
    app_type: 'A',
    own_org: '招商局',
    serviceObj: 'Person',
    feeType: '00',
    name6: 'Select A'
  },
  {
    id: 2,
    app_name: 'APP-A2',
    app_status: 'CLOSE',
    app_type: 'B',
    own_org: '统计局',
    serviceObj: 'Person',
    feeType: '01',
    name6: 'Select B'
  },
  {
    id: 3,
    app_name: 'APP-A3',
    app_status: 'OPEN',
    app_type: 'C',
    own_org: '教育局',
    feeType: '00',
    serviceObj: 'Coroperation',
    name6: 'Select C'
  },
  {
    id: 4,
    app_name: 'APP-A4',
    app_status: 'CLOSE',
    app_type: 'D',
    own_org: '国土资源',
    serviceObj: 'Coroperation',
    feeType: '01',
    name6: 'Select D'
  },
  {
    id: 5,
    app_name: 'APP-A5',
    app_status: 'OPEN',
    app_type: 'A',
    own_org: '公安局',
    serviceObj: 'Person',
    feeType: '00',
    name6: 'Select E'
  },
  {
    id: 6,
    app_name: 'APP-A6',
    app_status: 'OPEN',
    app_type: 'C',
    own_org: '卫生局',
    serviceObj: 'Coroperation',
    feeType: '01',
    name6: 'Select F'
  }
]
