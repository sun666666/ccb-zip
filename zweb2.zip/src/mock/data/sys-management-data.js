const data = {
  logLIst: {
    list: [
      {
        createName: 'mfg',
        createstaff: 'mfg',
        CREATESTAFF: '06666',
        logid: '1',
        logtype: '1001',
        logContent: '日志',
        createTime: 1556503286000,
        operModuleType: '1013',
        operType: '1003',
        orgName: 'sd',
        province: 'sd',
        tennant: 'test',
        tms: 1561451359010,
        txnIttChnCgyCode: '1',
        txnIttChnId: '2'
      }
    ],
    txnCommCom: {
      totalRec: 55,
      tCurrTotalPage: 1,
      tCurrTotalRec: 20,
      totalPage: 3
    }

  },
  committeeList: {
    list: [{
      title: 'parent 1',
      expand: true,
      children: [{
        title: 'parent 1-1',
        expand: true,
        children: [{
          title: 'leaf 1-1-1'
        },
        {
          title: 'leaf 1-1-2'
        }
        ]
      },
      {
        title: 'parent 1-2',
        expand: true,
        children: [{
          title: 'leaf 1-2-1'
        },
        {
          title: 'leaf 1-2-1'
        }
        ]
      }
      ]
    }]
  },
  parameterConfigList: {
    data: [
      {
        code: '188',
        des: 18,
        name: 'York',
        number: '1',
        text: 'hello',
        imgUrl: '../../../assets/images/logo.jpg',
        url: '/'
      },
      {
        code: '188',
        des: 18,
        name: 'York',
        number: '1',
        text: 'hello',
        imgUrl: false,
        url: '/'
      },
      {
        code: '188',
        des: 18,
        name: 'York',
        number: '1',
        text: 'hello',
        imgUrl: '#',
        url: '/'
      }
    ]
  },
  getDictionaryList: [
    {
      id: '1',
      code: '123',
      des: 'faf',
      serial: 1,
      list: [{ text: '123', number: '55', serial: '1' }]
    },
    {
      id: '1',
      code: '456',
      des: 'fagsgf',
      serial: 2,
      list: [{ text: '123', number: '55', serial: '1' }, { text: '145553', number: 'ss55', serial: 'ss1' }]
    },
    {
      id: '1',
      code: '789',
      des: 'fhhh',
      serial: 3,
      list: [{ text: '123', number: '55', serial: '1' }]
    }
  ],
  findMatterCategoryList: {
    list: [{
      categoryId: '123',
      categoryCode: '23',
      categoryName: '部门',
      enableFlag: '00',
      sortcode: '1',
      showTree: '00'
    },
    {
      categoryId: '法法',
      categoryCode: '3',
      categoryName: '趋于',
      enableFlag: '01',
      sortcode: '2',
      showTree: '00'
    },
    {
      categoryId: '法法',
      categoryCode: '4',
      categoryName: '法法',
      enableFlag: '00',
      sortcode: '2',
      showTree: '01'
    }
    ],
    txnCommCom: {
      totalRec: '',
      tCurrTotalPage: '',
      tCurrTotalRec: '',
      totalPage: ''
    }
  },
  doSaveMatterCategory: {
    'C-API-Status': '00',
    'C-Response-Desc': 'success'
  },
  doOperateMatterCategory: {
    'C-API-Status': '00',
    'C-Response-Desc': 'success'
  },
  findMatterCategory: {
    categoryId: '法法',
    categoryCode: '4',
    categoryName: '法法',
    categoryIcon: '14',

    sortcode: '2',

    parentId: '123',
    parentName: 'fulei',
    areaId: '123',
    categoryId: '123'
  },
  getAppVersionData: {

  }
}
export default data
