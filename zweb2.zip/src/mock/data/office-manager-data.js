const data = {

  getSystematicNoticList:
    {
      list: [{
        notoceId: '1', //
        noticeTitle: '系统通知01',
        noticeContent: '这是一段内容',
        userId: '',
        userName: '小明',
        pubTime: '2018-01-01',
        effectTime: '',
        stopTime: '2019-01-01',
        creatTime: '',
        effectiveState: '',
        isDel: '0',
        isTop: '0',
        noticeType: '00',
        isEnable: '',
        noticeRange: '',
        tenant: ''
      }, {
        notoceId: '2', //
        noticeTitle: '系统通知02',
        noticeContent: '这是一段内容',
        userId: '',
        userName: '小明',
        pubTime: '2018-01-01',
        effectTime: '',
        stopTime: '2019-01-01',
        creatTime: '',
        effectiveState: '',
        isDel: '0',
        isTop: '1',
        noticeType: '',
        isEnable: '0',
        noticeRange: '',
        tenant: ''
      }, {
        notoceId: '3', //
        noticeTitle: '系统通知03',
        noticeContent: '这是一段内容',
        userId: '',
        userName: '小明',
        pubTime: '2018-01-01',
        effectTime: '',
        stopTime: '2019-01-01',
        creatTime: '',
        effectiveState: '',
        isDel: '0',
        isTop: '0',
        noticeType: '',
        isEnable: '',
        noticeRange: '',
        tenant: ''
      }],
      txnCommCom: {
        totalRec: '100',
        tCurrTotalPage: '',
        tCurrTotalRec: '10',
        totalPage: '10'
      }

    },
  deleteNotice: {},
  addNotice: {},

  getSearchPostData: {
    list: [
      {
        title: '在线预约陈公',
        imgSrc: '#',
        mouldId: '1',
        des: '涉及多方考虑时间快到了附件是'
      },
      {
        title: '电视剧福克斯的',
        imgSrc: '#',
        mouldId: '12',
        des: '涉及多方考虑时间快到了附件是'
      },
      {
        title: '斯蒂芬金老师的',
        imgSrc: '#',
        mouldId: '1232222',
        des: '涉及多方考虑时间快到了附件是'
      },
      {
        title: '死刑犯年代的',
        imgSrc: '#',
        mouldId: '12311',
        des: '涉及多方考虑时间快到了附件是'
      },
      {
        title: '十分激烈的健身房教练说的减上的放松的方式的方式发生的肥',
        imgSrc: '#',
        mouldId: '12333',
        des: '涉及多方考虑时间快到了附件是'
      },
      {
        title: '分iOS粉红色地方第三范式水电费',
        imgSrc: '#',
        mouldId: '12322',
        des: '涉及多方考虑slfkhlsdfjlskdfjlsdjfljsdflsdjlf'
      },
      {
        title: '分iOSsfsdfsdfsdfsdfs粉红色地方第三范式水电费',
        imgSrc: '#',
        mouldId: '1231',
        des: '涉及多方考虑时间快到了附件是JFK连锁酒店法使得飞机螺丝钉解放律上的解放螺丝钉解放螺丝钉的说法就是的理解佛山的金佛山多久哦'
      },
      {
        title: '十分激烈的健身房教练说的减上的放松的方式的方式发生的肥',
        imgSrc: '#',
        mouldId: '1234',
        des: '涉及多方考虑时间快到了附件是'
      },
      {
        title: '分iOS粉红色地方第三范式水电费',
        imgSrc: '#',
        mouldId: '1233',
        des: '涉及多方考虑时间快到了附件是'
      },
      {
        title: '分iOSsfsdfsdfsdfsdfs粉红色地方第三范式水电费',
        imgSrc: '#',
        mouldId: '1232',
        des: '涉及多方考虑时间快到了附件是'
      }
    ],
    txnCommCom: {
      totalRec: '21',
      totalPage: '3',
      tCurrTotalPage: '1',
      tCurrTotalRec: '10'
    }
  },
  treeData: {
    list: [
      {
        title: 'parent 1',
        catalogId: '1',
        parentId: '0',
        expand: true,
        selected: true,
        children: [
          {
            title: 'parent 1-1',
            catalogId: '2',
            parentId: '1',
            expand: true,
            children: [
              {
                title: 'parent 1-1',
                catalogId: '4',
                parentId: '2'
              },
              {
                title: 'parent 1-1',
                catalogId: '5',
                parentId: '2'
              }
            ]
          },
          {
            title: 'parent 1-2',
            catalogId: '3',
            parentId: '1',
            children: [
              {
                title: 'parent 1-1',
                catalogId: '6',
                parentId: '3'
              },
              {
                title: 'parent 1-1',
                catalogId: '7',
                parentId: '3'
              }
            ]
          }
        ]
      }
    ]
  },
  TemDetails: {
    title: '搭街坊拉萨',
    content: '封建时代浪费精力士大夫艰苦拉萨大家方式i虚假瓯绣哦促使冻豆腐',
    typeId: '0'
  }

}
export default data
