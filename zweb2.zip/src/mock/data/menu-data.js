export default {
  menuList: [
    // {
    //   href: 'doc',
    //   name: '外部链接',
    //   icon: 'md-menu',
    //   href: 'https://lison16.github.io/iview-admin-doc/#/'
    // },
    // {
    //   href: 'file_upload',
    //   name: '文件上传',
    //   icon: 'md-menu'
    // },
    {
      href: 'charts',
      name: 'echarts图',
      icon: 'md-menu',
      children: [
        {
          href: 'charts_page',
          name: 'echarts图',
          icon: 'md-menu'
        }
      ]
    },
    // {
    //   href: 'lodash',
    //   name: '函数式编程',
    //   icon: 'md-menu',
    //   children: [
    //     {
    //       href: 'lodash_page',
    //       name: '函数式编程',
    //       icon: 'md-menu',
    //     }
    //   ]
    // },
    // {
    //   href: 'pass-value',
    //   name: '组件间传值',
    //   icon: 'md-menu',
    //   children: [
    //     {
    //       href: 'pass-value1',
    //       name: '组件间传值',
    //       icon: 'md-menu',
    //     }
    //   ]
    // },
    {
      href: 'ccbtable',
      name: 'table组件',
      icon: 'md-menu',
      children: [
        {
          href: 'ccbtable1',
          name: '服务端分页及自定义序号',
          icon: 'md-menu'
        },
        {
          href: 'ccbtable2',
          name: '服务端分页并排序、过滤',
          icon: 'md-menu'
        },
        {
          href: 'ccbtable3',
          name: '前端分页并排序、过滤',
          icon: 'md-menu'
        }
      ]
    },
    {
      href: 'system_role_mgt',
      name: '角色管理',
      icon: 'md-menu',
      children: [
      // {
      //   href: 'regional_mgt',
      //   name: '区域管理',
      //   icon: 'md-menu'
      // },
      // {
      //   href: 'organization_mgt',
      //   name: '组织机构管理',
      //   icon: 'md-menu'
      // },
        {
          href: 'role_mgt',
          name: '角色管理',
          icon: 'md-menu'
        },
        {
          href: 'user_mgt',
          name: '用户管理',
          icon: 'md-menu'
        },
        {
          href: 'menu_mgt',
          name: '菜单管理',
          icon: 'md-menu'
        }
      ]
    },
    {
      href: 'system_mgt',
      name: '系统管理',
      icon: 'md-menu',
      children: [
        {
          href: 'system_log',
          name: '日志管理',
          icon: 'md-menu'
        }
      ]
    }
  ]
}
