export const appVersionData = [
  {
    id: '1',
    APPVERSION: '6.6',
    OPERATIONSYSTEM: '00',
    UPDATECONTENT: '测试内容1',
    MUSTUPDATEFLAG: '否',
    URL: 'ffffffffffffff'
  },
  {
    id: '2',
    APPVERSION: '6.0',
    OPERATIONSYSTEM: '00',
    UPDATECONTENT: '测试内容2',
    MUSTUPDATEFLAG: '00',
    URL: '22222222222'
  },
  {
    id: '3',
    APPVERSION: '3.0',
    OPERATIONSYSTEM: '01',
    UPDATECONTENT: '测试内容3',
    MUSTUPDATEFLAG: '01',
    URL: 'fffffffpppppp'
  },
  {
    id: '4',
    APPVERSION: '6.1',
    OPERATIONSYSTEM: '00',
    UPDATECONTENT: '测试内容4',
    MUSTUPDATEFLAG: '00',
    URL: 'ffffffffffffff'
  },
  {
    id: '5',
    APPVERSION: '5.5',
    OPERATIONSYSTEM: '01',
    UPDATECONTENT: '测试内容5',
    MUSTUPDATEFLAG: '00',
    URL: 'ffffffffffffff'
  },
  {
    id: '6',
    APPVERSION: '4.2',
    OPERATIONSYSTEM: '01',
    UPDATECONTENT: '测试内容6',
    MUSTUPDATEFLAG: '00',
    URL: 'ffffffffffffff'
  },
  {
    id: '7',
    APPVERSION: '8.3',
    OPERATIONSYSTEM: '01',
    UPDATECONTENT: '测试内容7',
    MUSTUPDATEFLAG: '01',
    URL: 'ffffffffffffff'
  },
  {
    id: '8',
    APPVERSION: '5.5',
    OPERATIONSYSTEM: '00',
    UPDATECONTENT: '测试内容8',
    MUSTUPDATEFLAG: '00',
    URL: 'ffffffffffffff'
  }
]
