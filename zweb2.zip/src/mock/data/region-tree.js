export default [
  {
    childCode: '2010001',
    regionName: '昆明市',
    regionLvl: 2,
    regionDesc: '昆明市',
    haschild: '1'
  },
  {
    childCode: '2010002',
    regionName: '西华市',
    regionLvl: 2,
    regionDesc: '西华市',
    haschild: '1'
  }
]
