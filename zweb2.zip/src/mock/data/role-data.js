export const roleListData = [
  { roleId: 1, roleLvl: '0', isEnable: '1', roleName: 'Select A', creatDate: 1558689821000, dataSoure: '0', roleCode: 'ceshi1', roleSeq: 1 },
  { roleId: 2, roleLvl: '1', isEnable: '0', roleName: 'Select B', creatDate: 1558689821000, dataSoure: '0', roleCode: 'ceshi1', roleSeq: 2 },
  { roleId: 3, roleLvl: '4', isEnable: '1', roleName: 'Select C', creatDate: 1558689821000, dataSoure: '0', roleCode: 'ceshi1', roleSeq: 3 },
  { roleId: 4, roleLvl: '1', isEnable: '0', roleName: 'Select D', creatDate: 1558689821000, dataSoure: '0', roleCode: 'ceshi1', roleSeq: 4 },
  { roleId: 5, roleLvl: '2', isEnable: '1', roleName: 'Select E', creatDate: 1558689821000, dataSoure: '0', roleCode: 'ceshi1', roleSeq: 5 },
  { roleId: 6, roleLvl: '3', isEnable: '1', roleName: 'Select F', creatDate: 1558689821000, dataSoure: '0', roleCode: 'ceshi1', roleSeq: 6 }
]
