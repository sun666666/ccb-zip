export const menuTreeData = [
  {
    childCode: '0',
    children: [
      {
        childCode: '11',
        children: [
          {
            childCode: '22',
            children: [],
            href: 'system_log',
            icon: 'md-menu',
            isEnable: '1',
            isRelation: '1',
            name: '测试4',
            parentCode: '088',
            parentidSet: '2,3,0',
            permission: 'system_log',
            sortCode: 1
          },
          {
            childCode: '33',
            children: [],
            href: 'system_log',
            icon: 'md-menu',
            isEnable: '1',
            isRelation: '1',
            name: '测试5',
            parentCode: '088',
            parentidSet: '2,3,0',
            permission: 'system_log',
            sortCode: 1
          }
        ],
        href: 'system_mgt',
        icon: 'md-cog',
        isEnable: '1',
        isRelation: '1',
        name: '测试2',
        parentCode: '0',
        parentidSet: '88,0,-1',
        permission: 'system_mgt',
        sortCode: 1
      }
    ],
    href: 'system_mgt',
    icon: 'md-menu',
    isEnable: '1',
    isRelation: '0',
    name: '测试1',
    parentCode: '-1',
    parentidSet: '0,-1',
    sortCode: 13
  }
]
