export const areaData = [{
  title: '云南省',
  expand: true,
  selected: true,
  children: [
    {
      title: '昆明市',
      expand: false,
      children: [
        {
          title: '五华区',
          disabled: true,
          postmail: 1111,
          role: '五华区'
        },
        {
          title: '盘龙区',
          postmail: 1234,
          role: '副部级以上'
        },
        {
          title: '官渡区',
          postmail: 1222,
          role: '官渡区'
        },
        {
          title: '西山区',
          postmail: 1333,
          role: '西山区'
        },
        {
          title: '东川区',
          postmail: 1444,
          role: '东川区'
        },
        {
          title: '晋宁区',
          postmail: 1555,
          role: '晋宁区'
        }
      ]
    },
    {
      title: '丽江市',
      expand: false,
      children: [
        {
          title: '古城区',
          checked: true
        },
        {
          title: '玉龙县'
        },
        {
          title: '永胜县'
        },
        {
          title: '玉龙县'
        },
        {
          title: '玉龙县'
        }
      ]
    },
    {
      title: '保山市',
      expand: false,
      children: [
        {
          title: '施甸县',
          checked: true
        },
        {
          title: '龙陵县'
        },
        {
          title: '腾冲县'
        },
        {
          title: '隆阳县'
        },
        {
          title: '昌宁县'
        }
      ]
    }
  ] }
]
