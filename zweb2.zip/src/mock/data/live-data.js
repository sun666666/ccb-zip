export const liveHotTopic = {
  state: '01',
  list2: [
    {
      id: 0,
      topicTitle: '测试0',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      status: '00',
      topicContent: '内容内容0',
      url: 'www.demo.com/demo.png',
      delFlag: '00',
      topFlag: '00'

    },
    {
      id: 0,
      topicTitle: '测试0',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      status: '01',
      topicContent: '内容内容0',
      url: 'www.demo.com/demo.png',
      delFlag: '01',
      topFlag: '01'
    },
    {
      id: 0,
      topicTitle: '测试0',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      status: '02',
      topicContent: '内容内容0',
      url: 'www.demo.com/demo.png',
      delFlag: '00',
      topFlag: '00'

    },
    {
      id: 0,
      topicTitle: '测试0',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      status: '00',
      topicContent: '内容内容0',
      url: 'www.demo.com/demo.png',
      delFlag: '01',
      topFlag: '01'
    }
  ],
  list: [
    {
      id: 0,
      topicTitle: '测试0',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      topicType: '0',
      topicContent: '内容内容0',
      url: 'www.demo.com/demo.png'
    }, {
      id: 1,
      topicTitle: '测试1',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      topicType: '1',
      topicContent: '内容内容1',
      url: 'www.demo.com/demo.png'
    }, {
      id: 2,
      topicTitle: '测试2',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      topicType: '0',
      topicContent: '内容内容2',
      url: 'www.demo.com/demo.png'
    }, {
      id: 3,
      topicTitle: '测试3',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      topicType: '0',
      topicContent: '内容内容3',
      url: 'www.demo.com/demo.png'
    }, {
      id: 4,
      topicTitle: '测试3',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      topicType: '0',
      topicContent: '内容内容3',
      url: 'www.demo.com/demo.png'
    }, {
      id: 5,
      topicTitle: '测试3',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      topicType: '0',
      topicContent: '内容内容3',
      url: 'www.demo.com/demo.png'
    }, {
      id: 6,
      topicTitle: '测试3',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      topicType: '0',
      topicContent: '内容内容3',
      url: 'www.demo.com/demo.png'
    }, {
      id: 7,
      topicTitle: '测试3',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      topicType: '0',
      topicContent: '内容内容3',
      url: 'www.demo.com/demo.png'
    }, {
      id: 8,
      topicTitle: '测试3',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      topicType: '0',
      topicContent: '内容内容3',
      url: 'www.demo.com/demo.png'
    }, {
      id: 9,
      topicTitle: '测试3',
      publishUserName: '派大星',
      publishTime: '2018-01-02',
      stopTitle: '2018-01-03',
      topicType: '0',
      topicContent: '内容内容3',
      url: 'www.demo.com/demo.png'
    }],
  realList: [{
    vipNum: 'A12345',
    Nickname: 'A2345',
    vipType: '0',
    viptel: '13188882828',
    registerTime: '2019-01-01'

  }, {
    vipNum: 'admin',
    Nickname: 'admin',
    vipType: '1',
    viptel: '13188882828',
    registerTime: '2019-01-01'

  }, {
    vipNum: 'ceshi1',
    Nickname: 'ceshi1',
    vipType: '0',
    viptel: '13188882828',
    registerTime: '2019-01-01'

  }, {
    vipNum: 'aaavv',
    Nickname: 'aaavv',
    vipType: '1',
    viptel: '13188882828',
    registerTime: '2019-01-01'

  }, {
    vipNum: 'A12345',
    Nickname: 'A2345',
    vipType: '0',
    viptel: '13188882828',
    registerTime: '2019-01-01'

  }, {
    vipNum: 'A12345',
    Nickname: 'A2345',
    vipType: '0',
    viptel: '13188882828',
    registerTime: '2019-01-01'

  }, {
    vipNum: 'A12345',
    Nickname: 'A2345',
    vipType: '0',
    viptel: '13188882828',
    registerTime: '2019-01-01'

  }],
  txnCommCom: {
    totalPage: '',
    totalRec: '',
    tCurrTotalPage: '',
    tCurrTotalRec: '',
    stsTraceId: ''
  }
}
