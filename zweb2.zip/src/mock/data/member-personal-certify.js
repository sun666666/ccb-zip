// 会员个人认证申诉管理
export const certificationAppealList = [
  {
    id: '00001',
    membername: 'UserA',
    appealTel: '10000000000',
    applyTime: '20190309 00:00:00',
    status: '0'
  },
  {
    id: '00002',
    membername: 'UserB',
    appealTel: '10000000001',
    applyTime: '20190309 00:00:00',
    status: '0'
  },
  {
    id: '00003',
    membername: 'UserC',
    appealTel: '10000000002',
    applyTime: '20190309 00:00:00',
    status: '1'
  },
  {
    id: '00004',
    membername: 'UserD',
    appealTel: '10000000003',
    applyTime: '20190309 00:00:00',
    status: '1'
  },
  {
    id: '00005',
    membername: 'UserE',
    appealTel: '10000000004',
    applyTime: '20190309 00:00:00',
    status: '-1'
  }
]

export const certificationAppealDetail = {
  memberid: '00001',
  membername: 'UserA',
  nickname: '',
  mobile: '15833113701',
  enterpriseName: '中国建设银行金融科技北京事业群',
  certificateCards: 'XXXXXXXXXXXXXXXXXXX',
  truename: '张三',
  idcard: '000000000000000000000000000000',
  applyMaterial: '[{"name":"legalPersonIdCardFront","url":"http://128.192.179.84:8087/image-service/downloadImage?bucketId=GSP_PRIVATE&C-App-Id=GSP_APP_001&ObjNm=微信图片_20190105195536.jpg&C-Dynamic-Password-Foruser=3f017ff1ae0b4d37b235e31a541d1b19"},{"name":"legalPersonIdCardBack","url":"http://128.192.179.84:8087/image-service/downloadImage?bucketId=GSP_PRIVATE&C-App-Id=GSP_APP_001&ObjNm=微信图片_20190105195532.jpg&C-Dynamic-Password-Foruser=3f017ff1ae0b4d37b235e31a541d1b19"},{"name":"creditCodeImg","url":"http://128.192.179.84:8087/image-service/downloadImage?bucketId=GSP_PRIVATE&C-App-Id=GSP_APP_001&ObjNm=微信图片_20190105195518.jpg&C-Dynamic-Password-Foruser=3f017ff1ae0b4d37b235e31a541d1b19"}]',
  appealTel: '13780965790',
  applyTime: '20190309 00:00:00',
  appealContent: 'AAAAAAAAAA',
  approveTime: '20190311 09:00:00',
  status: '1',
  notbyreason: '',
  certType: '1010'
}
