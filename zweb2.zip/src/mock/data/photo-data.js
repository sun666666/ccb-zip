export const photoManageData = [
  {
    id: '1',
    convenientlyType: '03',
    publishUserName: 'xxx',
    publishTime: 1552117970273,
    content: '',
    status: '02'
  },
  {
    id: '2',
    convenientlyType: '01',
    publishUserName: 'xxx',
    publishTime: '2019-01-02 20:38',
    content: '',
    status: '01'
  },
  {
    id: '3',
    convenientlyType: '02',
    publishUserName: 'xxx',
    publishTime: '2019-01-02 20:38',
    content: '',
    status: '03'
  }
]
