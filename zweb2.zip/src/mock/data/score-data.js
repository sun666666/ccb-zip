export const scoreData = [
  {
    usercode: '001',
    username: '张三',
    score: 6753
  },
  {
    usercode: '002',
    username: '李四',
    score: 23534
  },
  {
    usercode: '003',
    username: '王五',
    score: 673323
  },
  {
    usercode: '004',
    username: '赵六',
    score: 4555
  },
  {
    usercode: '005',
    username: '周七',
    score: 57642
  },
  {
    usercode: '006',
    username: '张八',
    score: 65542
  },
  {
    usercode: '007',
    username: '宋久',
    score: 126753
  },
  {
    usercode: '008',
    username: '张3',
    score: 66753
  }
]
