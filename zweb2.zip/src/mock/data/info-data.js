export const infoColumn = [
  {
    moduleId: '0',
    columnCatalog: '00',
    columnName: '通知公告',
    columnTypeCode: '列表',
    isEnable: '0',
    userName: '信息管理员A',
    columnCode: '00-column-01'
  },
  {
    moduleId: '1',
    columnCatalog: '00',
    columnName: '新闻管理',
    columnTypeCode: '文章',
    isEnable: '1',
    userName: '信息管理员B',
    columnCode: '00-column-02'
  },
  {
    moduleId: '2',
    columnCatalog: '00',
    columnName: '政务公开',
    columnTypeCode: '文章',
    isEnable: '1',
    userName: '信息管理员A',
    columnCode: '00-column-03'
  },
  {
    moduleId: '3',
    columnCatalog: '00',
    columnName: '测试栏目001',
    columnTypeCode: '列表',
    isEnable: '0',
    userName: '信息管理员B',
    columnCode: '00-column-04'
  },
  {
    moduleId: '4',
    columnCatalog: '00',
    columnName: '测试栏目002',
    columnTypeCode: '列表',
    isEnable: '0',
    userName: '信息管理员A',
    columnCode: '00-column-05'
  }
]

export const permitSet = [
  {
    permitid: 1,
    loginNo: 'kangzhijjjj',
    staffName: '云南信息员yn_admin',
    datapermit: '列表',
    permits: '添加,浏览,修改,删除'
  },
  {
    permitid: 2,
    loginNo: 'qinqinqin',
    staffName: '云南管理员',
    datapermit: '',
    permits: '浏览,修改,删除'
  },
  {
    permitid: 3,
    loginNo: 'pangpang',
    staffName: '云南信息员1',
    datapermit: '',
    permits: '添加,浏览,删除'
  }
]

export const checkSet = [
  {
    confirmStep: '第1步',
    checkerName: '云南管理员'
  },
  {
    confirmStep: '第2步',
    checkerName: '云南信息员yn_admin'
  },
  {
    confirmStep: '第3步',
    checkerName: '云南信息员1'
  }
]

export const infoExam = [
  {
    name: '待审核新闻标题01',
    state: '待审核',
    creater: '信息管理员A',
    time: '2019-01-21 11:11:11'
  },
  {
    name: '待审核新闻标题02',
    state: '待审核',
    creater: '信息管理员A',
    time: '2019-01-21 11:11:11'
  },
  {
    name: '待审核新闻标题03',
    state: '已审核',
    creater: '信息管理员B',
    time: '2019-01-21 11:11:11'
  }
]

export const checkInfoMgt = [
  {
    name: '待审核新闻标题01',
    state: '审核中',
    creater: '信息管理员A',
    time: '2019-01-21 11:11:11'
  },
  {
    name: '待审核新闻标题02',
    state: '发布未完成',
    creater: '信息管理员A',
    time: '2019-01-21 11:11:11'
  },
  {
    name: '待审核新闻标题03',
    state: '暂存',
    creater: '信息管理员B',
    time: '2019-01-21 11:11:11'
  }
]

export const checkedInfoMgt = [
  {
    name: '已审核新闻标题01',
    state: '已发布',
    creater: '信息管理员A',
    time: '2019-01-21 11:11:11'
  },
  {
    name: '已审核新闻标题02',
    state: '已发布',
    creater: '信息管理员A',
    time: '2019-01-21 11:11:11'
  },
  {
    name: '已审核新闻标题03',
    state: '审核未通过',
    creater: '信息管理员B',
    time: '2019-01-21 11:11:11'
  }
]
