import { eventData, eventConfigData } from './data/event-data'
export const getEventData = req => {
  return eventData
}
export const getEventConfigData = req => {
  return eventConfigData
}
