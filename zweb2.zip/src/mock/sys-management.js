import sysData from './data/sys-management-data'

const sysManager = {
  getLogList (req) {
    return sysData.logLIst
  },
  getLogTabel (req) {
    return { 'C-API-Status': '01', 'C-Response-Desc': '成功' }
  },
  logDleAndUp (req) {
    return { 'C-API-Status': '01', 'C-Response-Desc': '成功' }
  },
  getCommitteeList (req) {
  	     return sysData.committeeList
  },
  parameterConfigList (req) {
  	     return sysData.parameterConfigList
  },
  getDictionaryList () {
  		return sysData.getDictionaryList
  },
  changeDictionaryInfo () {
  	     return { data: 'success' }
  },
  findMatterCategoryList () {
  		return sysData.findMatterCategoryList
  },
  doSaveMatterCategory () {
  		return sysData.doSaveMatterCategory
  },
  doOperateMatterCategory () {
  		return sysData.doOperateMatterCategory
  },
  findMatterCategory () {
  		return sysData.findMatterCategory
  },
  getAppVersionData () {
    return sysData.getAppVersionData
  }
}
export default sysManager
