import Mock from 'mockjs'
import { doCustomTimes } from '@/libs/util'
import orgData from './data/org-data'
import orgTree from './data/org-tree'
import { treeData } from './data/tree-select'
import menuData from './data/menu-data'
import regionTree from './data/region-tree'
import regionList from './data/region-list'
import { areaData } from './data/area-data'
import { scoreData } from './data/score-data'
import { photoManageData } from './data/photo-data'
import { scoreRuleData } from './data/score-rule-data'
import { appData } from './data/app-data'
import { liveHotTopic } from './data/live-data'
import { roleListData } from './data/role-data'
import { menuTreeData } from './data/menu-tree'

import { infoColumn, permitSet, checkSet, infoExam, checkInfoMgt, checkedInfoMgt } from './data/info-data'

import { memberInfoData } from './data/member-info-data'
import { eventData, eventConfigData, eventTypeData, eventInfo, matterCategory } from './data/event-data'
import { certificationAppealList, certificationAppealList2, certificationAppealDetail } from './data/member-personal-certify'
import { workOrderData } from './data/work-order'

import { contentShowData, contentShowListData } from './data/content-show-data'

import { serviceAgreementData } from './data/service-agreement'
import { messageTemplateData } from './data/message-template'
import { hotwordSearchData } from './data/hotword-search'
import { illegalFundRaisingList, illegalFundRaisingDetail } from './data/illegal-fund-raising-data'

import { appVersionData } from './data/app-version-data'
import { userData } from './data/user-data'

const Random = Mock.Random

export const getTableData = req => {
  let tableData = []
  doCustomTimes(5, () => {
    tableData.push(Mock.mock({
      name: '@name',
      email: '@email',
      createTime: '@date'
    }))
  })
  return tableData
}

export const getDragList = req => {
  let dragList = []
  doCustomTimes(5, () => {
    dragList.push(Mock.mock({
      name: Random.csentence(10, 13),
      id: Random.increment(10)
    }))
  })
  return dragList
}

export const uploadImage = req => {
  return Promise.resolve()
}

export const getOrgData = req => {
  return orgData
}

export const getOrgTree = req => {
  return orgTree
}

export const getTreeSelectData = req => {
  return treeData
}

export const getMenuData = req => {
  return menuData
}

export const getAreaTree = req => {
  return regionTree
}

export const getAreaList = req => {
  return regionList
}
export const getAreaData = req => {
  return areaData
}

export const getScoreData = req => {
  return scoreData
}
export const getPhotoManageData = req => {
  return photoManageData
}

export const getScoreRuleData = req => {
  return scoreRuleData
}

export const getAppListByAreaData = req => {
  return appData
}

export const getLiveHotTopic = req => {
  return liveHotTopic
}

export const getRoleListData = req => {
  return roleListData
}
export const getMenuTreeData = req => {
  return menuTreeData
}

// 资讯
export const getInfoColumn = req => {
  return infoColumn
}
export const getPermitSet = req => {
  return permitSet
}
export const getCheckSet = req => {
  return checkSet
}
export const getInfoExam = req => {
  return infoExam
}
export const getCheckInfoMgt = req => {
  return checkInfoMgt
}
export const getCheckedInfoMgt = req => {
  return checkedInfoMgt
}

export const getMemberInfoData = req => {
  return memberInfoData
}
// 事项
export const getEventData = req => {
  return eventData
}
export const getEventConfigData = req => {
  return eventConfigData
}

export const getEvent = req => {
  return eventInfo
}

export const getEventTypeList = req => {
  return eventTypeData
}

export const queryCertificationAppealList = req => {
  return certificationAppealList
}
export const queryCertificationAppealDetail = req => {
  return certificationAppealDetail
}
export const certificationAppealReview = req => {
  return {}
}

export const getMatterCategory = req => {
  return matterCategory
}
export const getWorkOrderData = req => {
  return workOrderData
}
export const getContentShowData = req => {
  return contentShowData
}
export const getContentShowListData = req => {
  return contentShowListData
}

// 系统管理
export const getServiceAgreementData = req => {
  return serviceAgreementData
}
export const getMessageTemplateData = req => {
  return messageTemplateData
}
// 热词搜索
export const getHotwordSearchData = req => {
  return hotwordSearchData
}
// APP版本管理
export const getAppVersionData = req => {
  return appVersionData
}

// 非法集资管理--列表
export const getIllegalFundRaisingList = req => {
  return illegalFundRaisingList
}
// 非法集资管理--详情
export const getIllegalFundRaisingDetail = req => {
  return illegalFundRaisingDetail
}
// 获取用户信息
export const getUserList = req => {
  return userData
}
