import officeData from './data/office-manager-data'

const officeManager = {
  getSystematicNoticList (req) {
    return officeData.getSystematicNoticList
  },
  deleteNotice (req) {
  	  return officeData.deleteNotice
  },
  addNotice (req) {
  	  return officeData.addNotice
  },
  getSearchPost (req) {
    console.log()
    return officeData.getSearchPostData
  },
  getTreeData (req) {
    console.log()
    return officeData.treeData
  },
  delTreeMenu (req) {
    console.log()
    return { 'C-API-Status': '01', 'C-Response-Desc': '删除成功' }
  },
  editTreeMenu (req) {
    console.log()
    return { 'C-API-Status': '01', 'C-Response-Desc': '编辑成功' }
  },
  delTemMultFn (req) {
    console.log()
    return { 'C-API-Status': '01', 'C-Response-Desc': '批量删除成功' }
  },
  getTemDetails (req) {
    console.log()
    return officeData.TemDetails
  },
  saveTem (req) {
    console.log()
    return { 'C-API-Status': '01', 'C-Response-Desc': '保存成功' }
  },
  moveTemMultFn (req) {
    console.log()
    return { 'C-API-Status': '01', 'C-Response-Desc': '批量移动成功' }
  }
}
export default officeManager
