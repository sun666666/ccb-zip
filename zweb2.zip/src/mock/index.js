import Mock from 'mockjs'
import { login, logout, getUserInfo } from './login'
import { getAreaTree, getAreaList, queryCertificationAppealList, queryCertificationAppealDetail, certificationAppealReview, getTableData, getDragList, uploadImage, getOrgData, getOrgTree, getTreeSelectData, getMenuData,
  getAreaData, getScoreData, getPhotoManageData, getLiveHotTopic, getScoreRuleData,
  getAppListByAreaData, getRoleListData, getInfoColumn, getPermitSet, getCheckSet, getInfoExam, getCheckInfoMgt,
  getCheckedInfoMgt, getMemberInfoData, getEventData, getEventConfigData, getEvent,
  getEventTypeList, getMatterCategory, getWorkOrderData, getContentShowData,
  getContentShowListData, getServiceAgreementData, getMessageTemplateData, getHotwordSearchData, getIllegalFundRaisingList, getIllegalFundRaisingDetail,
  getAppVersionData, getMenuTreeData, getUserList } from './data'

import { getMessageInit, getContentByMsgId, hasRead, removeReaded, restoreTrash, messageCount } from './user'

import officeManager from './office-manager'
import sysManager from './sys-management'

// 配置Ajax请求延时，可用来测试网络延迟大时项目中一些效果
Mock.setup({
  timeout: 1000
})

// 登录相关和获取用户信息
Mock.mock(/\/gsp\/gld01011/, login)
Mock.mock(/\/gsp\/gld01013/, getUserInfo)
Mock.mock(/\/gsp\/gld01012/, logout)
Mock.mock(/\/get_table_data/, getTableData)
Mock.mock(/\/get_drag_list/, getDragList)
Mock.mock(/\/save_error_logger/, 'success')
Mock.mock(/\/image\/upload/, uploadImage)
Mock.mock(/\/message\/init/, getMessageInit)
Mock.mock(/\/message\/content/, getContentByMsgId)
Mock.mock(/\/message\/has_read/, hasRead)
Mock.mock(/\/message\/remove_readed/, removeReaded)
Mock.mock(/\/message\/restore/, restoreTrash)
Mock.mock(/\/message\/count/, messageCount)
Mock.mock(/\/get_org_data/, getOrgData)
Mock.mock(/\/get_tree_select_data/, getTreeSelectData)
Mock.mock(/\/get_menu_data/, getMenuData)

// 区域管理
Mock.mock(/\/gsp\/gld01000/, getAreaTree)
Mock.mock(/\/gsp\/gld01001/, getAreaList)
Mock.mock(/\/gsp\/gld01002/, getOrgTree)
Mock.mock(/\/get_area_data/, getAreaData)

// Mock.mock(/\/get_score_data/, getScoreData)

Mock.mock(/\/get_live_Hot_Topic/, getLiveHotTopic)

/* Mock.mock(/\/gsp\/gld02005/, getScoreData)
Mock.mock(/\/gsp\/gld02003/, getScoreRuleData) */

Mock.mock(/\/gsp\/fsxs11t66666/, getAreaData)
Mock.mock(/\/gsp\/fsxs11t66667/, getAppListByAreaData)

// 办公管理start

// Mock.mock(/\/gsp\/gld104020/, officeManager.getSystematicNoticList)
// Mock.mock(/\/gsp\/gld104022/, officeManager.deleteNotice)
// Mock.mock(/\/gsp\/gld104021/, officeManager.addNotice)
//
// Mock.mock(/\/gsp\/gld104001/, officeManager.getSearchPost)
// Mock.mock(/\/gsp\/gld104008/, officeManager.getTreeData)
// Mock.mock(/\/gsp\/gld104007/, officeManager.delTreeMenu)
// Mock.mock(/\/gsp\/gld104006/, officeManager.editTreeMenu)
// Mock.mock(/\/gsp\/gld104005/, officeManager.delTemMultFn)
// Mock.mock(/\/gsp\/gld104002/, officeManager.getTemDetails)
// Mock.mock(/\/gsp\/gld104003/, officeManager.saveTem)

// 办公管理end
// 查询角色列表
// Mock.mock(/\/gsp\/fsxs11t66668/, getRoleListData)
// 查询角色列表
Mock.mock(/\/gsp\/gld01014/, getRoleListData)
Mock.mock(/\/gsp\/gld01016/, getMenuTreeData)
Mock.mock(/\/gsp\/gld01015/, getUserList)
Mock.mock(/\/gsp\/gld01009/, getMenuTreeData)

// 资讯管理
Mock.mock(/\/info_column_manage/, getInfoColumn)
Mock.mock(/\/gsp\/gld05024/, getPermitSet)
Mock.mock(/\/gsp\/gld05027/, getCheckSet)
Mock.mock(/\/info_exam_manage/, getInfoExam)
Mock.mock(/\/check_info_mgt/, getCheckInfoMgt)
Mock.mock(/\/checked_info_mgt/, getCheckedInfoMgt)
// 会员信息查询
/* Mock.mock(/\/gsp\/gld09001/, getMemberInfoData) */

// 事项管理
Mock.mock(/\/get_event/, getEvent)
Mock.mock(/\/save_event/, getEvent)
Mock.mock(/\/get-eventType-list/, getEventTypeList)
Mock.mock(/\/oparate_event/, '')
Mock.mock(/\/get-event-list/, getEventData)
Mock.mock(/\/get-event-config-data/, getEventConfigData)
Mock.mock(/\/get-matter-category/, getMatterCategory)

// 随手拍管理
Mock.mock(/\/get_photo_manager_data/, getPhotoManageData)
Mock.mock(/\/edit_photo_manager_data/, getPhotoManageData)
Mock.mock(/\/audit-photo/, '')

// 会员个人认证申诉管理

// Mock.mock(/gsp\/gld09021/, queryCertificationAppealList)
// Mock.mock(/gsp\/gld09022/, queryCertificationAppealDetail)
// Mock.mock(/\/gsp\/gld09023/, certificationAppealReview)

// 日志管理
// Mock.mock(/\/gsp\/fsxs11t110004/, sysManager.getLogList)
// Mock.mock(/\/gsp\/fsxs11t110005/, sysManager.getLogTabel)
// Mock.mock(/\/gsp\/fsxs11t110006/, sysManager.logDleAndUp)
Mock.mock(/\/gsp\/gld10004/, sysManager.getLogList)
//
Mock.mock(/\/getWorkOrderData/, getWorkOrderData)

// 页面通用参数配置
Mock.mock(/\/gsp\/ff/, sysManager.getCommitteeList)
Mock.mock(/\/gsp\/cc/, sysManager.parameterConfigList)
// 字典管理
// Mock.mock(/\/gsp\/gdl/, sysManager.getDictionaryList)
// Mock.mock(/\/gsp\/cd/, sysManager.changeDictionaryInfo)
// 服务事项分类
// Mock.mock(/\/gsp\/gld03001/, sysManager.findMatterCategoryList)
// Mock.mock(/\/gsp\/gld03002/, sysManager.doSaveMatterCategory)
// Mock.mock(/\/gsp\/gld03003/, sysManager.doOperateMatterCategory)
// Mock.mock(/\/gsp\/gld03004/, sysManager.findMatterCategory)

// 内容展示部分
// Mock.mock(/\/gsp\/fsxs11t76869/, getContentShowData)
// Mock.mock(/\/gsp\/fsxs11t76868/, getContentShowListData)

// 系统管理
// Mock.mock(/\/getServiceAgreementData/, getServiceAgreementData) //服务协议管理
Mock.mock(/\/getMessageTemplateData/, getMessageTemplateData) // 消息模板

// 热词搜索
// Mock.mock(/\/getHotwordSearchData/,getHotwordSearchData)

// 非法集资管理--列表
// Mock.mock(/\/getIllegalFundRaisingList/,getIllegalFundRaisingList)
// 非法集资管理--详情
// Mock.mock(/\/getIllegalFundRaisingDetail/,getIllegalFundRaisingDetail)

// App版本管理
Mock.mock(/\/gsp\/gld06103/, getAppVersionData)
export default Mock
