<template>
  <Card dis-hover>
    <p slot="title">
      区域选择
    </p>
    <Tree :data="data" :load-data="loadData" @on-select-change="handleSelectChange" style="overflow: auto;"></Tree>
  </Card>
</template>

<script>
import { queryRegionByTree } from '@/api/org-role-manager'
import { convertTree } from '@/libs/util'

export default {
  name: 'RegionTree',
  props: {
    parent: {
      type: Object,
      default () {
        if (this.$store.state.user) {
          return { id: this.$store.state.user.regionCode,
            title: this.$store.state.user.regionName,
            children: [],
            loading: false }
        }
      }
    } // 根结点 {title:, id} 用 regionName和regionCode进行转换
  },
  data () {
    let d = []
    if (this.parent && this.parent.id) {
      d.push(this.parent)
    }
    return {
      data: d
    }
  },
  methods: {
    handleSelectChange (selected) {
      this.$emit('on-select-change', selected[0])
    },
    queryData (parent, callback) {
      queryRegionByTree(parent).then(res => {
        const data = res.data
        let result = convertTree(data, { childCode: 'id', regionName: 'title', _hasChild: v => v.haschild === '1' })
        callback(result)
      })
    },
    loadData (item, callback) {
      this.queryData(item.id, callback)
    }
  },
  mounted () {
    // this.queryData(null, res => this.data = res)
  }
}
</script>
