<template>
  <div>
    <Button v-if="file && file.name && clearable" slot="append" @click="clear">{{clearText}}</Button>
	  <uploader-file
	    custom-class="ivu-btn ivu-btn-primary"
	    :post-action="action"
	    :input-file="InputFile"
	    @input="handleFiles"
	    :headers="headers"
	    :on-success="onSuccess"
	    :on-start="onStart"
	    :on-upload="onUpload"
	    :on-delete="onDelete"
	    :on-error="onError"
	    :on-progress="onProgress"
	    name="file"
	    :multiple="false"
	    slot="append"
	    :auto-upload="autoUpload"
	    ref="uploader"
      :size="size"
      :accept="accept"
      :disabled="loading"
	    >
      <template v-if="loading"><Icon type="ios-loading" class="spin-icon-load"></Icon> {{loadingText}}</template>
      <template v-else>{{title}}</template>
	  </uploader-file>
  </div>

</template>

<script>
import config from '@/config'
import uploadMixin from './upload-mixin'

export default {
  mixins: [uploadMixin],
  props: {
    accept: {
      type: String,
      default: 'image/*'
    },
    title: {
      default: '图片上传'
    }
  }
}
</script>
