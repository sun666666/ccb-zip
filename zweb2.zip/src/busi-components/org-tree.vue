<template>
  <Row>
    <u-col span="12">
      <RegionTree ref="orgTree" @on-select-change="regionSelect"></RegionTree>
    </u-col>
    <u-col span="12">
      <Card dis-hover>
        <p slot="title">机构选择</p>
        <Input placeholder="查找" @on-change="search($event)" v-model="searchText" icon="ios-search"></Input>
        <Tree
          ref="tree"
          transfer
          checkStrictly
          :data="nodeList"
          @on-select-change="orgSelected"
          style="overflow:auto"
        ></Tree>
      </Card>
    </u-col>
  </Row>
</template>

<script>
import { queryOrgByTree } from '@/api/org-role-manager'
import Bus from '@/libs/bus'
import { convertTree } from '@/libs/util'

export default {
  data () {
    return {
      nodeList: [],
      visible: false,
      nodeList: [],
      searchList: [],
      searchText: '',
      value: ''
    }
  },
  methods: {
    regionSelect (e) {
      console.log(e)
      if (e != undefined) {
        console.log(e)
        queryOrgByTree(e.childCode, '').then(res => {
          console.log(res)
          const data = res.data
          let result = convertTree(data, {
            childCode: 'id',
            orgName: 'title',
            _childrenField: 'children'
          })
          this.nodeList = result
          localStorage.setItem('newList', JSON.stringify(result))
          // console.log(this.nodeList);
        })
      }
    },
    orgSelected (e) {
      this.$emit('on-select-change', e[0])
    },
    searchEach (node, value) {
      let depth = this.getTreeDepth(node)
      let self = this
      for (let i = 0; i < depth - 1; i++) {
        this.traverseTree(node, n => {
          if (self.isHasChildren(n)) {
            let children = n.children
            let length = children.length
            for (let j = 0; j < length; j++) {
              let cutLeafIndex = children.findIndex((e3, i3, a3) => {
                if (!self.isHasChildren(e3) && e3.title.indexOf(value) <= -1) {
                  return true
                }
                return false
              })
              if (cutLeafIndex > -1) {
                children.splice(cutLeafIndex, 1)
              }
            }
          }
        })
      }
    },

    // 搜索框回车事件响应
    search (e) {
      let self = this
      // 把树形结构还原成搜索以前的,否则删除时不能查询到原来的
      self.nodeList = JSON.parse(localStorage.getItem('newList'))

      if (self.nodeList && self.nodeList.length > 0) {
        self.nodeList.forEach((n, i, a) => {
          self.searchEach(n, e.target.value)
        })

        // 没有叶子节点的根节点也要清理掉
        let length = self.nodeList.length
        for (let i = 0; i < length; i++) {
          let index = self.nodeList.findIndex((e2, i2, a2) => {
            return (
              !self.isHasChildren(e2) && e2.title.indexOf(e.target.value) <= -1
            )
          })
          if (index > -1) {
            self.nodeList.splice(index, 1)
          }
        }
      }
    },

    // 判断树形结构中的一个节点是否具有孩子节点
    isHasChildren (node) {
      let flag = false
      if (node.children && node.children.length > 0) {
        flag = true
      }
      return flag
    },

    //  数组 arr 中都是数字。获得数组中最大的数字。
    maxNum (arr) {
      let max = null
      arr.forEach((e, i, a) => {
        if (i == 0) {
          max = e
        } else {
          if (e > max) {
            max = e
          }
        }
      })
      return max
    },

    // 利用递归计算树的深度
    calDepth (node, depth) {
      if (!this.isHasChildren(node)) {
        return depth
      } else {
        let length = node.children.length
        // 递归方法获得各个子树的深度。childrenResults数组用来
        // 存储各个子树的深度。
        let childrenResults = []
        for (let i = 0; i < length; i++) {
          childrenResults.push(this.calDepth(node.children[i], depth + 1))
        } // end for
        // 返回子树中，最大的深度。
        return this.maxNum(childrenResults)
      }
    },

    // 通过传入根节点获得树的深度，是 calDepth 的调用者。
    getTreeDepth (node) {
      if (undefined == node || node == null) {
        return 0
      }
      return this.calDepth(node, 1)
    },

    traverseTree (node, callback) {
      if (!node) {
        return
      }
      var stack = []
      stack.push(node)
      var tmpNode
      while (stack.length > 0) {
        tmpNode = stack.pop()
        callback(tmpNode)
        if (tmpNode.children && tmpNode.children.length > 0) {
          for (let i = tmpNode.children.length - 1; i >= 0; i--) {
            stack.push(tmpNode.children[i])
          }
        }
      }
    }
  },
  created () {
    Bus.$on('regionChange', code => {
      this.regionCode = code
      if (this.$refs.tree) {
        this.$refs.tree.currentData = []
      }
    })
  }
}
</script>
