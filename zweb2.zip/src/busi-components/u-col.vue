<template>
  <i-col class="ivu-col-margin" v-bind="$attrs">
    <slot></slot>
  </i-col>
</template>

<script>
export default {
}
</script>
