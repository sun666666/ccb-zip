<template>
  <Input
    class="fileinput"
    :readonly="readonly"
    :value="file && file.name"
  >
    <Button v-if="file && file.name && clearable && !loading" slot="append" @click="clear">{{clearText}}</Button>
    <Button v-if="file && file.name && stoptable && loading" slot="append" @click="stop">{{stopText}}</Button>
    <uploader-file
      v-show="!file"
      custom-class="ivu-btn ivu-primary"
      :post-action="action"
      :input-file="InputFile"
      @input="handleFiles"
      :headers="headers"
      :on-success="onSuccess"
      :on-start="onStart"
      :on-upload="onUpload"
      :on-delete="onDelete"
      :on-error="onError"
      :on-progress="onProgress"
      name="file"
      :multiple="false"
      slot="append"
      :auto-upload="autoUpload"
      ref="uploader"
      :size="size"
      :accept="accept"
      >
      {{title}}
    </uploader-file>
  </Input>
</template>

<script>
import config from '@/config'
import uploadMixin from './upload-mixin'

export default {
  mixins: [uploadMixin],
  props: {
    clearable: {
      type: Boolean,
      default: true
    },
    showProgress: {
      type: Boolean,
      default: false
    }
  },
  watch: {
    progress () {
      let e = this.$el.querySelector('input')
      if (e) e.style.backgroundSize = `${this.progress}% 100%`
    }
  }
}
</script>

<style>
.fileinput .ivu-input {
  background: -webkit-linear-gradient(left,#00ff2b63, #19be6b) no-repeat;
  background-size: 0% 100%;
}
</style>
