<template>
  <TreeSelect remote transfer :multiple="multiple" clearable
    :remote-load-data="remoteLoadData"
    :value="value"
    :onlyLeaf="false"
    @input="handleInput"
    :checkStrictly="multiple"
    :label-in-value="labelInValue"
    ref="tree"></TreeSelect>
</template>

<script>
import Vue from 'vue'
import { queryRegionByTree } from '@/api/org-role-manager'
import { convertTree } from '@/libs/util'

export default {
  props: {
    value: {},
    multiple: {
      type: Boolean,
      default: false
    },
    parent: {
      type: Object,
      default () {
        if (this.$store.state.user) {
          return { id: this.$store.state.user.regionCode,
            title: this.$store.state.user.regionName,
            children: [],
            loading: false }
        }
      }
    },
    labelInValue: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    remoteLoadData (item, callback) {
      let parent
      if (!item) {
        callback([this.parent])
      } else {
        parent = item.id
        queryRegionByTree(parent).then(res => {
          const data = res.data
          let result = convertTree(data, { childCode: 'id', regionName: 'title', _hasChild: v => v.haschild === '1' })
          callback(result)
        })
      }
    },
    handleInput (v) {
      let result = this.getValue(v)
      this.$emit('input', v)
      // debugger
      this.$emit('on-select-change', result)
    },
    getValue (v) {
      let result
      if (this.multiple) {
        result = this.$refs.tree.selectedMultiple.slice()
      } else {
        if (this.labelInValue) {
          result = v
        } else {
          result = { value: v, label: this.$refs.tree.selectedSingle }
        }
      }
      return result
    }
  },
  mounted () {
    if (this.value) {
      let result = this.getValue(this.value)
      this.$emit('input', this.value)
      this.$emit('on-select-change', result)
    }
  }
}
</script>
