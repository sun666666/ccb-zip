<template>
  <TreeSelect
    ref="tree"
    remote
    transfer
    :multiple="multiple"
    :remote-load-data="remoteLoadData"
    :value="value"
    :onlyLeaf="false"
    checkStrictly
    :label-in-value="labelInValue"
    @input="handleInput"
  ></TreeSelect>
</template>

<script>
import Vue from 'vue'
import { queryOrgByTree } from '@/api/org-role-manager'
import Bus from '@/libs/bus'
import { convertTree } from '@/libs/util'

export default {
  props: {
    value: {},
    multiple: {
      type: Boolean,
      default: false
    },
    idField: {
      type: String,
      default: 'childCode'
    },
    labelInValue: {
      type: Boolean,
      default: false
    },
    eventName: {
      type: String,
      default: 'regionChange'
    }
  },
  data () {
    return { regionCode: '' }
  },
  methods: {
    remoteLoadData (item, callback) {
      if (!this.regionCode) {
        this.$Message.info('请先选择区域')
        return
      }
      let parent
      if (!item) parent = ''
      else parent = item.id
      queryOrgByTree(this.regionCode, parent).then(res => {
        const data = res.data
        let result = convertTree(data, {
          [this.idField]: 'id',
          orgName: 'title',
          _childrenField: 'children'
        })
        callback(result)
      })
    },
    handleInput (v) {
      let result
      if (this.multiple) {
        result = this.$refs.tree.selectedMultiple.slice()
      } else {
        if (this.labelInValue) {
          result = v
        } else {
          result = { value: v, label: this.$refs.tree.selectedSingle }
        }
      }
      this.$emit('input', v)
      this.$emit('on-select-change', result)
    }
  },
  created () {
    Bus.$on(this.eventName, code => {
      if (code instanceof Object) {
        this.regionCode = code.value
      } else {
        this.regionCode = code
      }
      if (this.$refs.tree) {
        this.$refs.tree.currentData = []
        this.$refs.tree.selectedSingle = ''
        this.$refs.tree.selectedMultiple = []
        this.handleInput(this.$refs.tree.model)
      }
    })
  }
}
</script>
