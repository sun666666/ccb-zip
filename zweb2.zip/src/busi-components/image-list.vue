<template>
  <div>
    <Row :gutter="20" style="margin-top: 10px;">
      <i-col :md="24" style="margin-bottom: 20px;">
        <Row class="middle">
          <i-col span="6" v-for="(image,index) in value" :key="index">
            <img :src="image.url ? image.url : image" @click="showimg(index)">
            <p>{{image.name?image.name:''}}</p>
          </i-col>
        </Row>
      </i-col>
    </Row>
    <Modal v-model="showbig" width="970" ref="dialog" :footer-hide="true">
      <Carousel v-if="showbig" :value="index" :trigger="'click'" loop class="member-mng-chkimg">
        <CarouselItem v-for="(image,index) in value" :key="index">
          <div>
            <img :src="image.url ? image.url: image" class="show-member-pic">
          </div>
        </CarouselItem>
      </Carousel>
    </Modal>
  </div>
</template>

<script>

export default {
  name: 'image-list',
  props: {
    value: {
      type: Array
    }
  },
  data () {
    return {
      showbig: false,
      index: 0
    }
  },
  methods: {
    showimg (index) {
      this.showbig = true
      this.index = index
    }
  }
}
</script>
<style >
.member-mng-chkimg .ivu-carousel-list {
  width: 967px;
}
</style>
<style scoped>
.middle {
  text-align: center;
}
.show-member-pic {
  max-width: 970px;
  max-height: 440px;
  margin: auto;
  display: block;
}
.middle img {
  display: block;
  width: 100%;
  box-sizing: border-box;
  padding: 5px;
  height: 150px;
}
.middle p {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  padding-top: 8px;
}
</style>
