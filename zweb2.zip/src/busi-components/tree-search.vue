<template>
  <Card dis-hover>
    <Input placeholder="查找" @on-change="search($event)" icon="ios-search"></Input>
    <Tree ref="tree" :data="dataList" style="overflow:auto" @on-select-change="orgSelected"></Tree>
  </Card>
</template>
<script>
export default {
  name: 'treeSearch',
  props: {
    // 默认日期
    nodeList: {
      type: Array,
      default: false
    }
  },
  data () {
    return {
      dataList: JSON.parse(localStorage.getItem('dataList'))
    }
  },
  methods: {
    searchEach (node, value) {
      let depth = this.getTreeDepth(node)
      let self = this
      for (let i = 0; i < depth - 1; i++) {
        this.traverseTree(node, n => {
          if (self.isHasChildren(n)) {
            let children = n.children
            let length = children.length
            for (let j = 0; j < length; j++) {
              let cutLeafIndex = children.findIndex((e3, i3, a3) => {
                if (!self.isHasChildren(e3) && e3.title.indexOf(value) <= -1) {
                  return true
                }
                return false
              })
              if (cutLeafIndex > -1) {
                children.splice(cutLeafIndex, 1)
              }
            }
          }
        })
      }
    },

    // 搜索框回车事件响应
    search (e) {
      let self = this
      // 把树形结构还原成搜索以前的,否则删除时不能查询到原来的
      self.dataList = JSON.parse(localStorage.getItem('dataList'))
      if (self.dataList && self.dataList.length > 0) {
        self.dataList.forEach((n, i, a) => {
          self.searchEach(n, e.target.value)
        })

        // 没有叶子节点的根节点也要清理掉
        let length = self.dataList.length
        for (let i = 0; i < length; i++) {
          let index = this.dataList.findIndex((e2, i2, a2) => {
            return (
              !self.isHasChildren(e2) && e2.title.indexOf(e.target.value) <= -1
            )
          })
          if (index > -1) {
            self.dataList.splice(index, 1)
          }
        }
      }
    },

    // 判断树形结构中的一个节点是否具有孩子节点
    isHasChildren (node) {
      let flag = false
      if (node.children && node.children.length > 0) {
        flag = true
      }
      return flag
    },
    //  数组 arr 中都是数字。获得数组中最大的数字。
    maxNum (arr) {
      let max = null
      arr.forEach((e, i, a) => {
        if (i == 0) {
          max = e
        } else {
          if (e > max) {
            max = e
          }
        }
      })
      return max
    },
    // 利用递归计算树的深度
    calDepth (node, depth) {
      if (!this.isHasChildren(node)) {
        return depth
      } else {
        let length = node.children.length
        // 递归方法获得各个子树的深度。childrenResults数组用来
        // 存储各个子树的深度。
        let childrenResults = []
        for (let i = 0; i < length; i++) {
          childrenResults.push(this.calDepth(node.children[i], depth + 1))
        } // end for
        // 返回子树中，最大的深度。
        return this.maxNum(childrenResults)
      }
    },
    // 通过传入根节点获得树的深度，是 calDepth 的调用者。
    getTreeDepth (node) {
      if (undefined == node || node == null) {
        return 0
      }
      return this.calDepth(node, 1)
    },
    traverseTree (node, callback) {
      if (!node) {
        return
      }
      var stack = []
      stack.push(node)
      var tmpNode
      while (stack.length > 0) {
        tmpNode = stack.pop()
        callback(tmpNode)
        if (tmpNode.children && tmpNode.children.length > 0) {
          for (let i = tmpNode.children.length - 1; i >= 0; i--) {
            stack.push(tmpNode.children[i])
          }
        }
      }
    },
    orgSelected (e) {
      this.$emit('on-select-change', e[0])
    }
  },
  mounted () {
    localStorage.setItem('dataList', JSON.stringify(this.nodeList))
  }
}
</script>
