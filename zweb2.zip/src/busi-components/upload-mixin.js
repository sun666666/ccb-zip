import Bus from '@/libs/bus'
import getHeaders from '@/libs/getHeaders'
import { getUploadURL, getConfig, fixDownloadURL, getAppId } from '@/libs/util'

export default {
  data () {
    return {
      action: '',
      file: null,
      headers: {},
      loading: false,
      progress: 0
    }
  },

  props: {
    value: {
      type: Object,
      default () {
        return { filename: '', filepath: '', filenm: '', size: 0 }
      }
    },
    readonly: {
      type: Boolean,
      default: true
    },
    clearable: {
      type: Boolean,
      default: false
    },
    stoptable: {
      type: Boolean,
      default: false
    },
    autoUpload: {
      type: Boolean,
      default: true
    },
    size: {
      type: Number,
      default: 5 * 1024 * 1024
    },
    title: {
      type: String,
      default: '文件上传'
    },
    accept: {},
    private_bucket: {
      type: Boolean,
      default: false
    },
    clearText: {
      default: '清除文件'
    },
    stopText: {
      default: '停止上传'
    },
    loadingText: {
      default: '处理中...'
    }
  },

  methods: {
    clear () {
      this.file = null
      this.progress = 0
      this.$refs.uploader.$refs.upload.clear()
      this.$emit('input', { filename: '', filepath: '', filenm: '', size: 0 })
      this.$emit('on-clear-error', '')
    },

    handleFiles (v) {
      if (v.length === 0) {
        this.clear()
      } else {
        this.file = v[0]
        this.action = getUploadURL(this.file.name, this.private_bucket)
        // this.headers = getHeaders(getAppId(this.private_bucket))
        console.log('action', this.action)
      }
    },
    InputFile (newFile, oldFile) {
      if (newFile && !oldFile) {
        // 添加文件
        this.onUpload && this.onUpload(newFile)
        this.loading = true
      }

      if (newFile && oldFile) {
        // 更新文件

        // 开始上传
        if (newFile.active !== oldFile.active) {
          console.log('start', newFile.active, newFile)
          this.onStart && this.onStart(newFile)
        }

        // 上传进度
        if (newFile.progress !== oldFile.progress) {
          console.log('progress', newFile.progress, newFile)
          this.onProgress && this.onProgress(newFile.progress, newFile)
        }

        // 上传错误
        if (newFile.error !== oldFile.error) {
          console.log('error', newFile.error, newFile)
          this.onError && this.onError(newFile.error, newFile)
        }

        // 上传成功
        if (newFile.success !== oldFile.success) {
          console.log('success', newFile.success, newFile)
          try {
            let res = JSON.parse(newFile.response)
            console.log(res)
            let apiStatus = res['C-API-Status']
            // 正常返回，可能没有apiStatus
            if (!apiStatus) {
              newFile.response = res
              // newFile = this.$refs.uploader.$refs.upload.update(newFile, {response: res})
              this.onSuccess && this.onSuccess(newFile.success, newFile)
            } else {
              if (apiStatus == '00') {
                let content = JSON.parse(res['C-Response-Body'])
                newfile.response = content
                // newFile = this.$refs.uploader.$refs.upload.update(newFile, {response: content})
                this.onSuccess && this.onSuccess(newFile.success, newFile)
              } else if (apiStatus == '01') {
                let errorInfo = res['C-Response-Desc']
                if (errorInfo == 'AuthFilter occur Exception : dynamic password for user incorrect or expired') {
                  // token过期
                  newFile.error = errorInfo
                  newFile.success = false
                  // newFile = this.$refs.uploader.$refs.upload.update(newFile, {error: errorInfo, success: false})
                  this.onError && this.onError(newFile.error, newFile)
                  this.$route.push('login')
                } else {
                  newFile.error = errorInfo
                  newFile.success = false
                  // newFile = this.$refs.uploader.$refs.upload.update(newFile, {error: errorInfo, success: false})
                  this.onError && this.onError(newFile.error, newFile)
                }
              }
            }
          } catch (e) {
            // newFile = this.$refs.uploader.$refs.upload.update(newFile, {error: e, success: false})
            this.onError && this.onError(newFile.error, newFile)
          }
        }
      }

      if (!newFile && oldFile) {
        // 删除文件
        this.onDelete && this.onDelete(newFile)
      }

      // 自动上传
      if (this.autoUpload && (Boolean(newFile) !== Boolean(oldFile) || oldFile.error !== newFile.error)) {
        if (!this.$refs.uploader.$refs.upload.active) {
          this.$refs.uploader.$refs.upload.active = true
        }
      }
    },

    stop () {
      this.$refs.uploader.$refs.upload.active = false
      this.clear()
    },

    onStart (newFile) {
      console.log('start', newFile)
    },
    onSuccess (success, newFile) {
      let file = { filename: newFile.name,
        filenm: newFile.response.ObjNm,
        filepath: fixDownloadURL(newFile.response.ObjNm, this.private_bucket, true),
        size: newFile.response.ObjSz }
      console.log(file)
      this.$emit('input', file)
      this.loading = false
    },
    onError (error, newFile) {
      console.log('error', error, newFile)
      if (error === 'size') {
        this.$emit('on-error', `上传失败: 大小不能超过${this.size}字节`)
      } else {
        this.$emit('on-error', '上传失败: ' + error)
      }
      this.loading = false
    },
    onDelete (newFile) {
      console.log('delete', newFile)
    },
    onUpload (newFile) {
      console.log('upload', newFile)
    },
    onProgress (progress, newFile) {
      this.progress = progress
      console.log('progress', progress, newFile)
    }

  },
  created () {
    Bus.$on(
      'fileClear', fileClear => {
        this.$refs.uploader.$refs.upload.clear()
      }
    )
  }
}
