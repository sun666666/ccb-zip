import OrgTree from './org-tree'
import OrgTreeSelect from './org-treeselect'
import RegionTree from './region-tree'
import RegionTreeSelect from './region-treeselect'
import UploaderInput from './upload-input'
import UploaderButton from './upload-button'
import UploaderImg from './upload-img'
import uCol from './u-col'
import Editor from './editor'

const Components = {
  OrgTree,
  OrgTreeSelect,
  RegionTree,
  RegionTreeSelect,
  UploaderInput,
  UploaderButton,
  UploaderImg,
  uCol,
  Editor
}

const install = function (Vue) {
  if (install.installed) return
  Object.keys(Components).forEach((name) => {
    Vue.component(name, Components[name])
  })
  // Vue.prototype.$list = List
  // Vue.prototype.$findParent = findParent
}

export default {
  install,
  ...Components
}
