export default {
  app_type: [
    { label: '便民服务类', value: 'A' },
    { label: '行业应用类', value: 'B' },
    { label: '便民查询类', value: 'C' },
    { label: '政民互动类', value: 'D' },
    { label: '悦享生活类', value: 'E' }
  ],
  feeType: [
    { label: '云缴费', value: '00' },
    { label: '小程序', value: '01' }
  ]
}
