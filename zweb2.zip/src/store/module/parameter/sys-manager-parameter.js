export default {
  messageType: [
    { value: '00', label: '办事' },
    { value: '01', label: '互动' },
    { value: '02', label: '账户' },
    { value: '03', label: '缴费' },
    { value: '04', label: '注册' },
    { value: '05', label: '办件待办' },
    { value: '06', label: '信件待回复' }
  ],
  venueType: [
    { value: '1', label: '办事' },
    { value: '2', label: '互动' },
    { value: '3', label: '账户' },
    { value: '4', label: '缴费' },
    { value: '5', label: '注册' },
    { value: '6', label: '办件待办' },
    { value: '7', label: '信件待回复' }
  ],
  venueTypeTwo: [
    {
      value: '00',
      label: '便民服务中心'
    }, {
      value: '01',
      label: '博物馆'
    }, {
      value: '02',
      label: '纪念馆'
    }, {
      value: '03',
      label: '体育场馆'
    }, {
      value: '04',
      label: '图书馆'
    }, {
      value: '05',
      label: '文化馆'
    }, {
      value: '06',
      label: '文化馆'
    }, {
      value: '07',
      label: '劳动者港湾'
    }, {
      value: '08',
      label: '医疗机构'
    }, {
      value: '09',
      label: '非遗产保护中心'
    }
  ],
  regionCode: [
    {
      id: 'fruits',
      title: 'Fruits',
      children: [ {
        id: 'apple',
        title: 'Apple'
      }, {
        id: 'grapes',
        title: 'Grapes'
      }, {
        id: 'pear',
        title: 'Pear'
      }, {
        id: 'strawberry',
        title: 'Strawberry'
      }, {
        id: 'watermelon',
        title: 'Watermelon'
      } ]
    }, {
      id: 'vegetables',
      title: 'Vegetables',
      children: [ {
        id: 'corn',
        title: 'Corn'
      }, {
        id: 'carrot',
        title: 'Carrot'
      }, {
        id: 'eggplant',
        title: 'Eggplant'
      }, {
        id: 'tomato',
        title: 'Tomato'
      } ]
    } ]
}
