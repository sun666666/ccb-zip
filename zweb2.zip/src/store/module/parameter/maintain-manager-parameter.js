export default {
  businesstype: [
    { label: '故障处理', value: '01' },
    { label: '重保', value: '02' },
    { label: '接入开通', value: '03' },
    { label: '系统维护', value: '04' },
    { label: '信息上报', value: '05' },
    { label: '咨询投诉', value: '06' },
    { label: '其他', value: '99' }
  ],
  imslevel: [
    { label: '紧急', value: '01' },
    { label: '重要', value: '02' },
    { label: '一般', value: '03' }
  ],
  processstatus: [
    { label: '已办结', value: '01' }
    /* {label: "未办结", value: "2"}, */
  ],
  starrating: [
    { label: '很不满意', value: '1' },
    { label: '不满意', value: '2' },
    { label: '基本满意', value: '3' },
    { label: '满意', value: '4' },
    { label: '很满意', value: '5' }
  ]
}
