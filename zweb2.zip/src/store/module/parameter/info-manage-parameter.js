export default {
  columnCatalog: [
    { label: '栏目', value: '00' },
    { label: '目录', value: '01' }
  ],
  isEnable: [
    { label: '已使用', value: '0' },
    { label: '未使用', value: '1' }
  ],
  OPERATIONSYSTEM: [
    { label: '安卓', value: '00' },
    { label: '苹果', value: '01' }
  ],
  status: [
    { label: '未审核', value: '0' },
    { label: '审核通过', value: '1' },
    { label: '审核不通过', value: '-1' }
  ]
}
