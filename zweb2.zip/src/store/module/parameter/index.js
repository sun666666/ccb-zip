import convAppManagerParameter from './conv-app-manager-parameter'
import orgRoleManagerParameter from './org-role-manager-parameter'
import interactionManagerParameter from './interaction-manager-parameter'
import infoManageParameter from './info-manage-parameter'
import maintainManagerParameter from './maintain-manager-parameter'
import sysManagerParameter from './sys-manager-parameter'
import eleControlParameter from './ele-control-parameter'

export default {
  state: {
    ...convAppManagerParameter,
    ...orgRoleManagerParameter,
    ...interactionManagerParameter,
    ...infoManageParameter,
    ...maintainManagerParameter,
    ...sysManagerParameter,
    ...eleControlParameter
  }
}
