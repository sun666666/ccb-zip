export default {
  convenientlyType: [
    { label: '美好生活', value: '00' },
    { label: '寻人寻物', value: '01' },
    { label: '失物招领', value: '02' },
    { label: '非法集资', value: '03' }
  ],
  photostatus: [
    { label: '全部', value: '' },
    { label: '待审核', value: '00' },
    { label: '通过', value: '01' },
    { label: '不通过', value: '02' },
    { label: '撤回发布', value: '03' }
  ],
  // reportReasonList : [
  //   { label: '高收益低门槛快回报', value: '01' },
  //   { label: '返租回购', value: '02' },
  //   { label: '高额回报', value: '03' },
  //   { label: '政府扶持养老机构', value: '04' },
  //   { label: '消费返利', value: '05' },
  //   { label: '投资理财', value: '06' },
  //   { label: '互联网金融理财', value: '07' },
  //   { label: '金融互助理财', value: '08' },
  //   { label: '财富管理', value: '09' },
  //   { label: '虚假夸大宣传', value: '10' },
  //   { label: '机构合法性存疑', value: '11' },
  //   { label: '其他', value: '00' },
  // ],
  reportCheckStatus: [
    { label: '未审核', value: '00' },
    { label: '审核通过', value: '01' },
    { label: '审核不通过', value: '02' },
    { label: '审核中', value: '04' }
  ],
  topicType: [
    { label: '往期话题', value: '01' },
    { label: '最新话题', value: '00' }
  ]
}
