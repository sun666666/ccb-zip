export default {
  keyword_type: [
    { value: '00', label: '办事' },
    { value: '01', label: '指南' },
    { value: '02', label: '政策' },
    { value: '03', label: '应用' },
    { value: '04', label: '资讯' }
  ]
}
