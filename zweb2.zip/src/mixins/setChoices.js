// 用于查找Grid中设置有is_choice的字段，查找store.state.parameter中是否有缓存的参数值，
// 然后异步填充到字段的 options: {choices} 上
// 可以在mounted中调用
// 使用说明：
// 1. 引入 mixnin
//
//    import setChoices from '@/mixins/setChoices'
//
// 2. 设置 mixins
//
//    mixins: [setChoices]
//
// 3. 在 mounted 中调用
//
//    mounted () {
//      this.setChoices(this.$refs.grid, map)
//    }
//
// 其中, 第一个参数是 Grid或Build组件
//    第二个参数是一个映射，如： {column_name: {name: 'parameter_name'}}
//    有可能参数名与字段的name不一致，因此可以通过map映射为其它值
//    当参数名与字段名相同时，可以忽略
//
// Author: liyinghui
// Date:   2019/03/09
//

import { getDictionaryInfo } from '@/api/sys-management'

const setColumnChoice = function (c, value) {
  // if (!c.editor) {
  //   this.$set(c, 'editor', {options: {type: 'select', choices: value}})
  // } else
  if (!c.editor.options) {
    this.$set(c.editor, 'options', { choices: value, type: 'select' })
  } else {
    this.$set(c.editor.options, 'choices', value)
  }
}

const setQueryChoice = function (c, value) {
  if (!c.options) {
    this.$set(c, 'options', { choices: value, type: 'select' })
  } else {
    this.$set(c.options, 'choices', value)
  }
}

// 检查store中是否有参数值
// c 为字段，可以是Grid.columns或Query.fields, Build中的字段
// map 为字段名和参数名的映射，如果map为空，则默认字段.name为参数名
// fields 用于保存，当store的parameter中无对应参数时，保存字段信息，用于异步获取参数
// setFunc 用于设置参数值到对应的字段的函数
const checkStoreParameter = function (c, map, fields, setFunc) {
  // 判断store中是否存在
  let parm = map[c.name]
  let parm_name
  if (!parm) parm_name = c.name
  else parm_name = parm.name || c.name // 获得参数名
  let parm_value = this.$store.state.parameter[parm_name]
  // 如果store中没有配置参数或参数为空，则从后端读取参数
  if (!parm_value || parm_value.length === 0) {
    let self = this
    getDictionaryInfo({
      txnBodyCom: {
        key: parm_name
      }
    }).then(res => {
      let parm_list = []
      res.data.selectVenue.forEach(item => {
        parm_list.push({ label: item.name, value: item.value })
      })
      self.$set(self.$store.state.parameter, parm_name, parm_list)
      setFunc.bind(this)(c, parm_list)
    })
    // let self = this
    // setTimeout(function (){
    //   let value = [{label: '测试A', value: 'OPEN'}, {label: '测试B', value: 'CLOSE'}]
    //   self.$set(self.$store.state.parameter, parm_name, value)
    //   setGridChoice(c, value)
    // }, 10)
    fields.push(c)
    // throw new Error(`Parameter ${parm_name} 未在store中定义`)
  } else {
    if (parm_value) {
      setFunc.bind(this)(c, parm_value)
    }
  }
}

export default {
  methods: {
    // 设置choices选项
    // el 是目标的Grid组件或build组件
    // map 是一个映射
    // {key: {name: param_key}}
    setChoices (el, map) {
      map = map || {}
      let grid_fields = []
      let query_fields = []
      let build_fields = []
      if (el.$options.name === 'Grid') {
        // 处理columns
        for (let c of el.store.states.columns) {
          if (c.is_choice) {
            checkStoreParameter.bind(this)(c, map, grid_fields, setColumnChoice)
          }
        }
        // 处理query
        if (!el.$refs.query) return
        for (let c of el.$refs.query.fields) {
          if (c.is_choice) {
            checkStoreParameter.bind(this)(c, map, query_fields, setQueryChoice)
          }
        }
      } else if (el.$options.name === 'Build') {
        for (let row of el.data) {
          for (let c of (row.fields || [])) {
            if (c.is_choice) {
              checkStoreParameter.bind(this)(c, map, build_fields, setQueryChoice)
            }
          }
        }
      }
    }
  }
}
