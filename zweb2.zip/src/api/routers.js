import ajaxRequest from '@/libs/ajaxRequest'

export const getRouterReq = (access) => {
  return ajaxRequest('post', 'get_router', { access })
  /* return axios.request({
    url: 'get_router',
    params: {
      access
    },
    method: 'get'
  }) */
}

export const getTempToken = () => {
  return ajaxRequest('post', '/auth/crtAccessLinkForUserTmp', null, null, true)
}
