import ajaxRequest from '@/libs/ajaxRequest'

// 查询分类
export const selectClass = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld06120', data, pagination)
}
// 新增/编辑分类(大类只能新增，不能编辑)
export const editClass = (data) => {
  return ajaxRequest('post', 'gsp/gld06121', data)
}

// 删除/启用/禁用分类(大类不能删除/启用/禁用)
export const operateClass = (data) => {
  return ajaxRequest('post', 'gsp/gld06122', data)
}
