import ajaxRequest from '@/libs/ajaxRequest'

export const getSystematicNoticList = (data, pagination) => { // 通知管理系统/内部通知管理搜索
  return ajaxRequest('post', 'gsp/gld04020', data, pagination)
}
export const deleteNotice = (data, pagination) => { // 通知管理系统/内部通知管理置顶/删除/终止系统/
  return ajaxRequest('post', 'gsp/gld04022', data, pagination)
}
export const addNotice = (data, pagination) => { // 通知管理系统/内部通知管理新增/修改
  return ajaxRequest('post', 'gsp/gld04021', data, pagination)
}
export const getSearchPost = (data, pagination) => { // 模板搜索
  return ajaxRequest('post', 'gsp/gld04001', data, pagination)
}
export const getTreeData = (data, pagination) => { // 获取目录树
  return ajaxRequest('post', 'gsp/gld04008', data, pagination)
}
export const delTreeMenu = (data, pagination) => { // 删除目录树
  return ajaxRequest('post', 'gsp/gld04007', data, pagination)
}
export const editTreeMenu = (data, pagination) => { // 重命名目录树
  return ajaxRequest('post', 'gsp/gld04006', data, pagination)
}

export const delTemMultFn = (data, pagination) => { // 批量删除模板
  return ajaxRequest('post', 'gsp/gld04005', data, pagination)
}
export const getTemDetails = (data, pagination) => { // 获取模板详情
  return ajaxRequest('post', 'gsp/gld04002', data, pagination)
}
export const saveTem = (data, pagination) => { // 新增/编辑模板
  return ajaxRequest('post', 'gsp/gld04003', data, pagination)
}
export const moveTemMultFn = (data, pagination) => { // 通知模板批量编辑修改所属目录接口
  return ajaxRequest('post', 'gsp/gld04004', data, pagination)
}
export const getRecycleBinList = (data, pagination) => { // 回收站
  return ajaxRequest('post', 'gsp/gld04024', data, pagination)
}
