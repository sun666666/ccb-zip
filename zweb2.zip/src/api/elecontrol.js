import ajaxRequest from '@/libs/ajaxRequest'
// 获取关键字排序
export const getKeywordSort = (data, pagination) => {
  return ajaxRequest('post', '/gsp/gld08001', data, pagination)
}
