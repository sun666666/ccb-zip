import ajaxRequest from '@/libs/ajaxRequest'
import { dateFormat } from '@/libs/util'
// 会员管理的接口调用

// 会员查询
export const selectUcLoginAccountList = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09001', data, pagination)
}
// 会员重置密码
export const updateSysMember = (data) => {
  return ajaxRequest('post', 'gsp/gld09002', data)
}
// 会员删除
export const deleteSysMember = (data) => {
  return ajaxRequest('post', 'gsp/gld09003', data)
}
// 会员强制解除实名认证
export const updateSysMemberIsAuth = (data) => {
  return ajaxRequest('post', 'gsp/gld09004', data)
}
// 会员强制实名认证
export const updateSysMemberAutonym = (data) => {
  return ajaxRequest('post', 'gsp/gld09005', data)
}
// 行为统计
export const selectSysMemberBehavior = (data) => {
  return ajaxRequest('post', 'gsp/gld09006', data)
}
// 会员办事项统计
export const selectOsWorkStatistics = (data) => {
  return ajaxRequest('post', 'gsp/gld09007', data)
}
// 会员信息一览
export const selectUcLoginAccountOne = (data) => {
  return ajaxRequest('post', 'gsp/gld09008', data)
}

// 会员绑定认证一览
export const selectSysMemberRankApprove = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09009', data, pagination)
}
// 会员已开通认证信息查询
export const selectSysMemberRankAndSysRankApprove = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09010', data, pagination)
}
// 会员缴费账号查询
export const queryPaymentAccount = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09011', data, pagination)
}
// 缴费历史纪录查询
export const queryPaymentHistory = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09012', data, pagination)
}
// 评价监察记录查询
export const selectWorkOrg = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09013', data, pagination)
}
// 积分变动记录查询
export const selectSysMembercentStatistics = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09014', data, pagination)
}
// 诚信档案记录查询
export const queryIntegrityRecord = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09015', data, pagination)
}
// 收藏办事项信息查询
export const selectSysMemberColmatterStatistics = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09016', data, pagination)
}
// 常用邮寄地址查询
export const selectMemInfoPostStatistics = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09017', data, pagination)
}
// 会员网上办事查询
export const selectOsWorkAndOsMatterStatistics = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09018', data, pagination)
}
// 会员网上办事详情查询
export const selectOsWorkAndOsMatterOne = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09019', data, pagination)
}
// 会员日志记录查询
export const selectSysMemberLogStatistics = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09020', data, pagination)
}
// 个人与法人认证与申诉-列表查询
export const selectSysMemberTruenameList = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09021', data, pagination)
}
// 个人与法人认证与申诉-详情查询
export const selectSysMemberTruenameOne = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld09022', data, pagination).then((res) => {
    return new Promise(
      (resolve, reject) => {
        if (res.data) {
          res.data.applyTime = res.data.applyTime ? dateFormat(res.data.applyTime, 'yyyy-MM-dd HH:mm:ss') : ''
          res.data.approveTime = res.data.approveTime ? dateFormat(res.data.approveTime, 'yyyy-MM-dd HH:mm:ss') : ''
          res.data.idcardExpiresStart = res.data.idcardExpiresStart ? dateFormat(res.data.idcardExpiresStart, 'yyyy-MM-dd HH:mm:ss') : ''
          res.data.idcardExpiresEnd = res.data.idcardExpiresEnd ? dateFormat(res.data.idcardExpiresEnd, 'yyyy-MM-dd HH:mm:ss') : ''
        }
        resolve(res)
      }
    )
  })
}
// 个人与法人认证与申诉-审核
export const certificationAppealReview = (data) => {
  return ajaxRequest('post', 'gsp/gld09023', data)
}
// 会员实名制
export const realCom = (data, pagination, key) => {
  let cmnName = 'real'
  switch (key) {
    case cmnName + 'query': // 会员查询 gsp/gld09001
      return ajaxRequest('post', 'gsp/gld09001', data, pagination)
      break
    case cmnName + 'edit': // 会员查询 gsp/gld09005
      return ajaxRequest('post', 'gsp/gld09005', data, pagination)
      break
    default:
  }
}
