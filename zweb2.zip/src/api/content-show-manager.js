import ajaxRequest from '@/libs/ajaxRequest'

// 应用分类管理 获取目录详情
export const getContentListData = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld03026', data, pagination)
}
// 应用分类管理 新增/编辑接口
export const getaddListData = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld03027', data, pagination)
}
// 应用分类管理 分类清单
export const getCategoryList = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld03011', data, pagination)
}
// 应用分类管理 分类清单
export const sortCategoryListData = (data) => {
  return ajaxRequest('post', 'gsp/gld03012', data)
}
// 应用分类管理 启用/删除接口
export const getDelateListData = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld03028', data, pagination)
}
// 应用分类详情
export const getDelateDetail = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld03029', data, pagination)
}
// 验证编码是否重复
export const getCodeData = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld03030', data, pagination)
}

// 事项标签管理  详情
// export const getItemLabelData = (data, pagination) => {
//   return ajaxRequest('post', 'gsp/gld03001', data, pagination)
// }isEnable
