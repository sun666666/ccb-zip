import ajaxRequest from '@/libs/ajaxRequest'

// 监察管理的接口调用

// 公共

// 1.1.1未生效规则管理
// 查询列表
export const rule_no_release_manage_List_select = (param, page) => {
  return ajaxRequest('post', 'suv/suv00001', param, page)
}
// 新增列表
export const rule_no_release_manage_List_save = (param) => {
  return ajaxRequest('post', 'suv/suv00004', param)
}
// 修改列表
export const rule_no_release_manage_List_update = (param) => {
  return ajaxRequest('post', 'suv/suv00002', param)
}
// 列表详情
export const rule_no_release_manage_List_get = (param) => {
  return ajaxRequest('post', 'suv/suv00005', param)
}
// 删除列表
export const rule_no_release_manage_List_delete = (param) => {
  return ajaxRequest('post', 'suv/suv00003', param)
}
// 提交审核
export const rule_no_release_manage_List_submit_approve = (param) => {
  return ajaxRequest('post', 'suv/suv01005', param)
}
// 审核
export const rule_no_release_manage_deal = (param) => {
  return ajaxRequest('post', 'suv/suv05001', param)
}// ruleIdList

// 按人员统计
//

// 规则公式字典表
export const getRuleDictionaryType = (param) => {
  return ajaxRequest('post', 'suv/suv00006', param)
}
// 地区列表树
export const getAreaTree = (param) => {
  return ajaxRequest('post', 'suv/suv00007', param)
}
// 实施清单
export const getRangelist = (param) => {
  return ajaxRequest('post', 'suv/suv00009', param)
}
// 保存配置
export const saveRange = (param) => {
  return ajaxRequest('post', 'suv/suv03006', param)
}
// 指标列表
export const kpi_list = (param) => {
  return ajaxRequest('post', 'suv/suv01001', param)
}
// 变更指标状态
export const updateKPIStatusSave = (param) => {
  return ajaxRequest('post', 'suv/suv03005', param)
}
// 指标状态审核
export const kpi_access = (param) => {
  return ajaxRequest('post', 'suv/suv01002', param)
}
// 实时运行
// 列表
export const run_list_select = (param, page) => {
  return ajaxRequest('post', 'suv/suv02003', param, page)
  // return ajaxRequest('post','suv/suv03000',param);
}
// 申请详情
export const run_list_apply_get = (param) => {
  // return ajaxRequest('post','suv/suv01003',param);
  return ajaxRequest('post', 'suv/suv03000', param)
}
// 办件过程详情
export const run_list_project_get = (param) => {
  // return ajaxRequest('post','suv/suv01003',param);
  return ajaxRequest('post', 'suv/suv03001', param)
}
// 文书凭证详情
export const run_list_doc_get = (param) => {
  // return ajaxRequest('post','suv/suv01003',param);
  return ajaxRequest('post', 'suv/suv03002', param)
}

// 重点监察
export const emphasis_monitor_list = (param) => {
  return ajaxRequest('post', 'suv/suv03004', param)
}
// 预警纠错
// 预警信息查看列表
export const warn_information_get_list_select = (param) => {
  return ajaxRequest('post', 'suv/suv03003', param)
}
// 风险点审核
// 审核信息查询列表
export const information_danger_approve_list_select = (param) => {
  return ajaxRequest('post', 'suv/suv03004', param)
}

// 督察督办
// 保存
export const supervisory_monitor_save = (param) => {
  return ajaxRequest('post', 'suv/suv02002', param)
}
// 列表
export const supervisory_monitor_select = (param) => {
  return ajaxRequest('post', 'suv/suv02001', param)
}
// 修改
export const supervisory_monitor_update = (param) => {
  return ajaxRequest('post', 'suv/suv0xxx', param)
}

// 工作流
// 列表
export const mould_WFE_select = (param) => {
  return ajaxRequest('post', 'suv/suv04000', param)
}
// 保存
export const mould_WFE_save = (param) => {
  return ajaxRequest('post', 'suv/suv04001', param)
}
// 待办列表
export const mould_WFE_wait_select = (param) => {
  return ajaxRequest('post', 'suv/suv04003', param)
}
// 待办 审批 -通过
export const mould_WFE_deal = (param) => {
  return ajaxRequest('post', 'suv/suv04004', param)
}
// 待办 审批 -不通过
export const mould_WFE_deal_no = (param) => {
  return ajaxRequest('post', 'suv/suv04004', param)
}
// 待办 详情
export const mould_WFE_wait_get_rule = (param) => {
  return ajaxRequest('post', 'suv/suv05002', param)
}
export const mould_WFE_wait_get_index = (param) => {
  return ajaxRequest('post', 'suv/suv05002', param)
}
// 办理历史列表
export const mould_WFE_his_select = (param) => {
  return ajaxRequest('post', 'suv/suv04005', param)
}
// 人员列表
export const mould_WFE_user_select = (param) => {
  return ajaxRequest('post', 'suv/suv05004', param)// roleId
}
// 角色列表
export const mould_WFE_role_select = (param) => {
  return ajaxRequest('post', 'suv/suv05003', param)//
}
// 模板 详情
export const mould_WFE__get = (param) => {
  return ajaxRequest('post', 'suv/suv05005', param)
}

// 效能管理
// 信息列表
export const appraise_KPI_manage_select = (param) => {
  return ajaxRequest('post', 'suv/suv11002', param)
}
export const appraise_KPI_manage_add = (param) => {
  return ajaxRequest('post', 'suv/suv11000', param)
}
export const appraise_KPI_manage_get = (param) => {
  return ajaxRequest('post', 'suv/suv11001', param)
}
// 关系列表
export const appraise_KPI_manage_Link_select = (param) => {
  return ajaxRequest('post', 'suv/suv11004', param)
}
export const appraise_KPI_manage_Link_add = (param) => {
  return ajaxRequest('post', 'suv/suv11003', param)
}
// 效能规则列表
export const appraise_rule_select = (param) => {
  return ajaxRequest('post', 'suv/suv11006', param)
}
// 效能规则添加
export const appraise_rule_save = (param) => {
  return ajaxRequest('post', 'suv/suv11005', param)
}

/*
export const rule_no_release_manage_select_List = (param, paging) => {
  let txnBodyCom = {
  }
  return ajaxRequest('post', 'gsp/suv/suv00001', {
    txnBodyCom
  }, paging)
} */
