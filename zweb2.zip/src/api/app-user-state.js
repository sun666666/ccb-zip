import ajaxRequest from '@/libs/ajaxRequest'

// 查询应用使用情况
export const getAppState = (data, paging) => {
  return ajaxRequest('post', 'gsp/gld08005', data, paging)
}
