import ajaxRequest from '@/libs/ajaxRequest'

export const getHotwordSearchData = (data, page) => { // 搜索热词列表
  // return ajaxRequest('post','getHotwordSearchData',data,page)
  return ajaxRequest('post', 'gsp/gld08002', data, page)
}
export const editHotwordSearchData = (data) => { // 搜索热词新增/编辑
  return ajaxRequest('post', 'gsp/gld08003', data)
}
export const deleteHotwordSearchData = (data) => { // 搜索热词发布/删除
  return ajaxRequest('post', 'gsp/gld08004', data)
}
