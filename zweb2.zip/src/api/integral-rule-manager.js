import ajaxRequest from '@/libs/ajaxRequest'

// 查询/导出积分规则（查询应分页，导出不分页全量导出）
export const doSearchS11t1ScoreRule = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld02003', data, pagination)
}
// 删除/启用/禁用积分规则（删除：已生效的积分规则不能删除，未生效的积分规则可直接删除；启用：次日生效；禁用：立即生效）
export const doOperateS11t1ScoreRule = (data) => {
  return ajaxRequest('post', 'gsp/gld02002', data)
}
// 积分明细统计
export const selectScoreByUser = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld02004', data, pagination)
}
// 调整积分
export const adjustPoint = (data) => {
  return ajaxRequest('post', 'gsp/gld02006', data)
}
// 新增/修改积分规则(新增/修改积分规则次日生效)
export const doSaveS11t1ScoreRule = (data) => {
  return ajaxRequest('post', 'gsp/gld02001', data)
}
// 积分明细（分页）
export const selectScore = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld02005', data, pagination)
}
// 调整积分
export const adjustScore = (data) => {
  return ajaxRequest('post', 'gsp/gld02006', data)
}
