import ajaxRequest from '@/libs/ajaxRequest'
export const getLogList = (data, p) => { // 日志查询列表接口
  return ajaxRequest('post', 'gsp/gld10004', data, p)
}
export const getLogTabel = (data, p) => { // 通知管理系统/内部通知管理搜索
  return ajaxRequest('post', 'gsp/gld10005', data, p)
}
export const logDleAndUp = (data) => { // 通知管理系统/内部通知管理搜索
  return ajaxRequest('post', 'gsp/gld10006', data)
}
export const getCommitteeList = (data) => { // 获取居委区域列表
  return ajaxRequest('post', 'gsp/ff', data)
}
export const parameterConfigList = (data) => { // 获取页面配置列表
  return ajaxRequest('post', 'gsp/cc', data)
}

export const getDictionaryList = (data, page) => { // 获取字典管理列表
  return ajaxRequest('post', 'gsp/gld01105', data, page)
}
export const changeDictionaryInfo = (data, page) => { // 新增/修改字典
  return ajaxRequest('post', 'gsp/gld01104', data, page)
}
export const delDictionaryInfo = (data, page) => { // 删除字典
  return ajaxRequest('post', 'gsp/gld01107', data, page)
}
export const getDictionaryInfo = (data, page) => { // 删除字典
  return ajaxRequest('post', 'gsp/gld01106', data, page)
}

export const getServiceAgreementData = (data, page) => { // 服务协议管理列表获取
  // return ajaxRequest('post','getServiceAgreementData',data,page)
  return ajaxRequest('post', 'gsp/gld06107', data, page)
}
export const getServiceAgreementDetail = (data) => { // 服务协议明细
  return ajaxRequest('post', 'gsp/gld06108', data)
}
export const deleteServiceAgreement = (data) => { // 服务协议删除
  return ajaxRequest('post', 'gsp/gld06106', data)
}
export const editServiceAgreement = (data) => { // 服务协议新增/编辑
  return ajaxRequest('post', 'gsp/gld06105', data)
}

export const getMessageTemplateData = (data, page) => { // 消息模板管理列表获取
  // return ajaxRequest('post', 'getMessageTemplateData')
  return ajaxRequest('post', 'gsp/gld06126', data, page)
}
export const operateMessageTemplateData = (data) => { // 消息模板删除
  return ajaxRequest('post', 'gsp/gld06128', data)
}
export const addMessageTemplateData = (data) => { // 消息模板新增/编辑
  return ajaxRequest('post', 'gsp/gld06127', data)
}

export const findMatterCategoryList = (data, page) => { // 查询服务事项分类列表 及父类列表
  return ajaxRequest('post', 'gsp/gld03001', data, page)
}
export const doSaveMatterCategory = (data) => { // 新增/编辑服务事项分类
  return ajaxRequest('post', 'gsp/gld03002', data)
}
export const doOperateMatterCategory = (data) => { // 删除/启用/禁用服务事项分类
  return ajaxRequest('post', 'gsp/gld03003', data)
}
export const findMatterCategory = (data) => { // 查看服务事项详情
  return ajaxRequest('post', 'gsp/gld03004', data)
}
export const getAppVersionData = (data, page) => { // APP版本管理/查看APP版本列表
  return ajaxRequest('post', 'gsp/gld06103', data, page)
}
export const editAppVersionData = (data) => { // APP版本管理/编辑、新增APP版本
  return ajaxRequest('post', 'gsp/gld06101', data)
}
export const deleteAppVersionData = (data) => { // APP版本管理/删除APP版本
  return ajaxRequest('post', 'gsp/gld06102', data)
}
export const getFAQList = (data, page) => { // 常见问题查询
  return ajaxRequest('post', 'gsp/gld06123', data, page)
}
export const addFAQ = (data, page) => { // 新增/编辑常见问题
  return ajaxRequest('post', 'gsp/gld06124', data, page)
}
export const deleteFAQ = (data) => { // 删除常见问题
  return ajaxRequest('post', 'gsp/gld06125', data)
}
export const queryClassificationData = (data) => { // 查询分类
  return ajaxRequest('post', 'gsp/gld06120', data)
}
// 节假日管理
export const getErrorList = (data, page) => { // 建议纠错列表
  return ajaxRequest('post', 'gsp/fsx06022', data, page)
}
export const addErrorInfo = (data) => { // 建议纠错新增、修改
  return ajaxRequest('post', 'gsp/fsx06023', data)
}
export const deleteErrorInfo = (data) => { // 建议纠错删除
  return ajaxRequest('post', 'gsp/fsx06024', data)
}
export const errorDetails = (data) => { // 建议纠错详情
  return ajaxRequest('post', 'gsp/fsx06025', data)
}
export const downLoadErrorList = (data) => { // 导出建议纠错
  return ajaxRequest('post', 'gsp/fsx06030', data)
}

// 根据区域名称查询区域
export const searchHolidays = (year, regnCode, paging) => {
  let txnBodyCom = {
    year: year,
    regnCode: regnCode
  }
  return ajaxRequest('post', 'gsp/gld10105', {
    txnBodyCom
  }, paging)
}
// 机构查询
export const searchOrg = (orgName, paging) => {
  let txnBodyCom = {
    orgName: orgName
  }
  return ajaxRequest('post', 'gsp/gld01003', {
    txnBodyCom
  }, paging)
}

// 检验是否存储日历的年份是否存在
export const haveHolidays = (regnCode, year) => {
  let txnBodyCom = {
    regnCode: regnCode,
    year: year
  }
  let page = {
    tRecInPage: '',
    tPageJump: '',
    tStsTraceId: ''
  }
  return ajaxRequest('post', 'gsp/gld10109', {
    txnBodyCom
  }, page)
}

// 新增节假日接口
export const addHolidays = (regnCode, year, list) => {
  let txnBodyCom = {
    regnCode: regnCode,
    year: year,
    list: list
  }
  let page = {
    tRecInPage: '',
    tPageJump: '',
    tStsTraceId: ''
  }
  return ajaxRequest('post', 'gsp/gld10108', {
    txnBodyCom
  }, page)
}

// 根据年份id查询节假日列表接口
export const holidaysYear = (yearId) => {
  let txnBodyCom = {
    yearId: yearId
  }
  let page = {
    tRecInPage: '',
    tPageJump: '',
    tStsTraceId: ''
  }
  return ajaxRequest('post', 'gsp/gld10106', {
    txnBodyCom
  }, page)
}

export const holidaysYearEdit = (yearId, list) => {
  let page = {
    tRecInPage: '',
    tPageJump: '',
    tStsTraceId: ''
  }
  let txnBodyCom = {
    yearId: yearId,
    list: list
  }
  return ajaxRequest('post', 'gsp/gld10107', {
    txnBodyCom
  }, page)
}

export const venueCom = (data, page, key) => {
  let cmnName = 'venue',
    cmnName2 = 'bgdimg',
    cmnSrc = 'gsp/'
  switch (key) {
    case cmnName + 'query': // 场馆信息管理查询 gsp/gld06111
      // return ajaxRequest('post','get_live_Hot_Topic',data,page);
      return ajaxRequest('post', cmnSrc + 'gld06111', data, page)
      break
    case cmnName + 'edit': // 新增/编辑场馆信息 gsp/gld06109
      return ajaxRequest('post', cmnSrc + 'gld06109', data, page)
      break
    case cmnName + 'delete': // 删除场馆信息 gsp/gld06110
      return ajaxRequest('post', cmnSrc + 'gld06110', data, page)
      break
    case cmnName + 'details': // 查看场馆信息 gsp/gld06112
      return ajaxRequest('post', cmnSrc + 'gld06112', data, page)
      break
    case cmnName + 'city': // 查看场馆信息 gsp/gld06112
      return ajaxRequest('post', cmnSrc + 'gld01112', data, page)
      break
    case cmnName2 + 'query': // 背景图列表查询 gsp/gld06113
      return ajaxRequest('post', cmnSrc + 'gld06113', data, page)
      break
    case cmnName2 + 'delete': // 背景图片分类删除 gsp/gld06114
      return ajaxRequest('post', cmnSrc + 'gld06114', data, page)
      break
    case cmnName2 + 'edit': // 背景图片分类新增/编辑 gsp/gld06115
      return ajaxRequest('post', cmnSrc + 'gld06115', data, page)
      break
    case cmnName2 + 'details': // 背景图片分类详情 gsp/gld06116
      return ajaxRequest('post', cmnSrc + 'gld06116', data, page)
      break

    case cmnName2 + 'query2': // 背景图片列表 gsp/gld06117
      return ajaxRequest('post', cmnSrc + 'gld06117', data, page)
      break

    case cmnName2 + 'add2': // 背景图片编辑/新增 gsp/gld06118
      return ajaxRequest('post', cmnSrc + 'gld06118', data, page)
      break

    case cmnName2 + 'delete2': // 背景图片删除/发布 gsp/gld06119
      return ajaxRequest('post', cmnSrc + 'gld06119', data, page)
      break
    default:
  }
}
