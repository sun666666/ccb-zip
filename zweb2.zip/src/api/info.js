import ajaxRequest from '@/libs/ajaxRequest'

// 查询资讯栏目管理 目录/栏目列表
export const getInfoColumn = (data, page) => {
  return ajaxRequest('post', 'gsp/gld05020', data, page)
  // return ajaxRequest('post','info_column_manage', data, page)
}
// 查询资讯目录下栏目列表或单栏目列表
export const getInfoColumnList = (data, page) => {
  return ajaxRequest('post', 'gsp/gld05030', data, page)
}
// 禁用/删除
export const useInfoColumnList = (data) => {
  return ajaxRequest('post', 'gsp/gld05023', data)
}
// 目录栏目新增/修改
export const addInfoColumnList = (data) => {
  return ajaxRequest('post', 'gsp/gld05021', data)
}
// 查询栏目/目录名称或编码是否已存在
export const isExistInfoNameCode = (data) => {
  return ajaxRequest('post', 'gsp/gld05022', data)
}
// 根据栏目ID查询栏目/目录
export const infoColumnListDetail = (data) => {
  return ajaxRequest('post', 'gsp/gld05031', data)
}
// 权限管理列表搜索
export const getPermitSet = (data, page) => {
  return ajaxRequest('post', 'gsp/gld05024', data, page)
}
// 权限管理新增/修改
export const addPermitSet = (data) => {
  return ajaxRequest('post', 'gsp/gld05025', data)
}
// 权限管理删除
export const deletePermitSet = (data) => {
  return ajaxRequest('post', 'gsp/gld05026', data)
}
// 审批设置列表搜索
export const getCheckSet = (data, page) => {
  return ajaxRequest('post', 'gsp/gld05027', data, page)
}
// 审核步骤新增/修改
export const addCheckSet = (data) => {
  return ajaxRequest('post', 'gsp/gld05028', data)
}
// 审核设置删除
export const deleteCheckSet = (data) => {
  return ajaxRequest('post', 'gsp/gld05029', data)
}
// 查看资讯审核管理
// export const getInfoExam = (data, pagination) => {
//   return ajaxRequest('post', 'info_exam_manage', data, pagination)
// }

// 查看 已审核/待审核/审核 资讯管理
// export const getCheckInfoMgt = (data, page) => {
//   return ajaxRequest('post', 'gsp/gld05002', data, page)
// }

// 资讯详情查询接口
export const getInfoDetail = (data) => {
  return ajaxRequest('post', 'gsp/gld05003', data)
}

// 资讯审核管理（待审核）列表搜索接口
export const getCheckInfoMgt = (data, page) => {
  return ajaxRequest('post', 'gsp/gld05008', data, page)
}

// 已审核资讯列表搜索接口
export const getCheckedInfoMgt = (data, page) => {
  return ajaxRequest('post', 'gsp/gld05009', data, page)
}

// 资讯发布（暂存、审核中、撤回）列表搜索接口
export const releaseInfoMgt = (data, page) => {
  return ajaxRequest('post', 'gsp/gld05010', data, page)
}

// 根据栏目编码查询其下所有资讯接口
export const allInfoDetail = (data, page) => {
  return ajaxRequest('post', 'gsp/gld05011', data, page)
}

// 资讯发布撤回/置顶（取消置顶）/审核通过（不通过）接口
export const operateCheckInfoMgt = (data) => {
  return ajaxRequest('post', 'gsp/gld05005', data)
}

// 资讯发布删除接口
export const deleteCheckInfoMgt = (data) => {
  return ajaxRequest('post', 'gsp/gld05004', data)
}

// 角色列表查询（带分页)
export const getRoleList = (data, page) => {
  return ajaxRequest('post', 'gsp/gld01014', data, page)
}

// 资讯发布图片插入接口
export const uploadImg = (data) => {
  return ajaxRequest('post', 'gsp/gld05006', data)
}
// 获取发布栏目
export const getReleaseLM = (data, pagination) => {
  return ajaxRequest('post', '/gsp/gld05020', data, pagination)
}

// 获取发布区域
export const getReleaseArea = (data, pagination) => {
  return ajaxRequest('post', '/gsp/gld01000', data, pagination)
}
// 获取发布平台
export const getInformPlatform = (data, pagination) => {
  return ajaxRequest('post', '/gsp/gld03012', data, pagination)
}
// 暂存资讯
export const getTmpSave = (data, pagination) => {
  return ajaxRequest('post', '/gsp/gld05001', data, pagination)
}

// 修改资讯
export const editorInfo = (data, pagination) => {
  return ajaxRequest('post', '/gsp/gld05003', data, pagination)
}
