import ajaxRequest from '@/libs/ajaxRequest'
export const editIncFinance = (data, page) => { // 新增/编辑普惠金融
  return ajaxRequest('post', 'gsp/fsx06026', data, page)
}
export const getIncFinanceList = (data, page) => { // 普惠金融查询列表
  return ajaxRequest('post', 'gsp/fsx06027', data, page)
}
export const getIncFinanceDetail = (data, page) => { // 普惠金融查询详情
  return ajaxRequest('post', 'gsp/fsx06028', data, page)
}
export const operateIncFinance = (data, page) => { // 普惠金融操作（处理，删除）
  return ajaxRequest('post', 'gsp/fsx06029', data, page)
}
export const exportIncFinanceList = (data, page) => { // 普惠金融列表导出
  return ajaxRequest('post', 'gsp/fsx06031', data, page)
}
