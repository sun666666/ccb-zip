import ajaxRequest from '@/libs/ajaxRequest'

// 话题管理/留言管理
export const interactionPublic = (data, page, key) => {
  let cmnName = 'topic',
    cmnName2 = 'message',
    cmnSrc = 'gsp/'
  switch (key) {
    case cmnName + 'query': // 话题管理查询 gsp/gld10100
      // return ajaxRequest('post','get_live_Hot_Topic',data,page);
      return ajaxRequest('post', cmnSrc + 'gld10100', data, page)
      break
    case cmnName + 'add': // 话题管理新建 gsp/gld10101
      return ajaxRequest('post', cmnSrc + 'gld10101', data, page)
      break
    case cmnName + 'details': // 话题管理查看详情 gsp/gld10102
      return ajaxRequest('post', cmnSrc + 'gld10102', data, page)
      break
    case cmnName + 'edit': // 话题管理编辑状态 gsp/gld10103
      return ajaxRequest('post', cmnSrc + 'gld10103', data, page)
      break
    case cmnName + 'stateNewest': // 话题管理查询是否最新接口 gsp/gld10104
      return ajaxRequest('post', cmnSrc + 'gld10104', data, page)
      break
    case cmnName2 + 'query': // 留言管理查询 gsp/gld10000
      // return ajaxRequest('post','get_live_Hot_Topic',data,page);
      return ajaxRequest('post', cmnSrc + 'gld10000', data, page)
      break
    case cmnName2 + 'edit': // 留言管理编辑 gsp/gld10001
      return ajaxRequest('post', cmnSrc + 'gld10001', data, page)
      break
    case cmnName2 + 'details': // 留言管理详情口 gsp/gld10002
      return ajaxRequest('post', cmnSrc + 'gld10002', data, page)
      break
    case cmnName2 + 'examine': // 留言管理审核接口 gsp/gld10003
      return ajaxRequest('post', cmnSrc + 'gld10003', data, page)
      break
    default:
  }
}
// 随手拍根据查询条件查询列表
export const getPhotoManageData = (data, page) => {
  // return ajaxRequest('post','get_photo_manager_data',data,page);
  return ajaxRequest('post', '/gsp/gld10201', data, page)
}
// 随手拍状态编辑接口
export const editPhotoManageData = (data) => {
  // return ajaxRequest('post','edit_photo_manager_data',data);
  return ajaxRequest('post', '/gsp/gld10203', data)
}
// 随手拍查询详情接口
export const getPhotoInfo = (data) => {
  return ajaxRequest('post', '/gsp/gld10202', data)
}
// 随手拍审核接口
export const auditPhoto = (data) => {
  return ajaxRequest('post', '/gsp/gld10204', data)
}

// 敏感词管理
// 敏感词库根据查询条件查询列表接口
export const getSensitiveWordList = (data, page) => {
  return ajaxRequest('post', '/gsp/gld10300', data, page)
}
// 敏感词库新增接口
export const addSensitiveWord = (data) => {
  return ajaxRequest('post', '/gsp/gld10301', data)
}
// 敏感词库删除接口
export const delSensitiveWord = (data) => {
  return ajaxRequest('post', '/gsp/gld10302', data)
}
// 敏感词库同步接口
export const synSensitiveWord = (data) => {
  return ajaxRequest('post', '/gsp/gld10303', data)
}
// 敏感词库批量导入接口
export const batchImportSensitiveWord = (data) => {
  return ajaxRequest('post', '/gsp/gld10304', data)
}

// 非法集资管理--列表
export const getIllegalFundRaisingList = (data, page) => {
  // return ajaxRequest('post','getIllegalFundRaisingList',data);
  return ajaxRequest('post', 'gsp/gld10007', data, page)
}
// 非法集资管理--明细
export const getIllegalFundRaisingDetail = (data) => {
  // return ajaxRequest('post','getIllegalFundRaisingDetail',data);
  return ajaxRequest('post', 'gsp/gld10009', data)
}

// 非法集资管理--审核
export const checkIllegalFundRaising = (data) => {
  return ajaxRequest('post', 'gsp/gld10010', data)
}

// 非法集资管理--导出word
export const downloadIllegalFundRaising = (data) => {
  return ajaxRequest('post', 'gsp/gld10012', data)
}

// 非法集资管理--明细
export const getIllegalFundStatistics = (data) => {
  return ajaxRequest('post', 'gsp/gld10008', data)
}
