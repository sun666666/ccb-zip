import ajaxRequest from '@/libs/ajaxRequest'

// 查询区域树列表信息
export const queryRegionByTree = (regionCode, paging) => {
  let txnBodyCom = {
    regionCode
  }
  return ajaxRequest('post', 'gsp/gld01000', {
    txnBodyCom
  }, paging)
}
// 根据区域名称查询区域
export const queryRegionByRegionName = (regionCode, regionName, paging) => {
  let txnBodyCom = {
    regionCode,
    regionName
  }
  return ajaxRequest('post', 'gsp/gld01001', {
    txnBodyCom
  }, paging)
}
// 区域树和机构树关联信息查询
export const queryOrgByTree = (regionCode, orgCode, paging) => {
  let txnBodyCom = {
    regionCode,
    orgCode
  }
  return ajaxRequest('post', 'gsp/gld01002', {
    txnBodyCom
  }, paging)
}
// 根据机构名称查询机构信息
export const queryOrgByOrgName = (data) => {
  return ajaxRequest('post', 'gsp/gld01003', data)
}

// 菜单管理-新增/编辑菜单
export const addEditMenuInfo = (data) => {
  return ajaxRequest('post', 'gsp/gld01100', data)
}

// 菜单管理-查询全量菜单
export const queryAllMenus = (data) => {
  return ajaxRequest('post', 'gsp/gld01009', data)
}

// 菜单管理-删除菜单
export const delMenuInfo = (data) => {
  return ajaxRequest('post', 'gsp/gld01103', data)
}

// 机构查询接口
export const searchOrg = (orgName, regionCode, paging) => {
  let txnBodyCom = {
    orgName: orgName,
    regionCode: regionCode
  }
  return ajaxRequest('post', 'gsp/gld01003', {
    txnBodyCom
  }, paging)
}
// 用户查询接口
export const searchUserList = (regionCode, orgCode, loginNo, staffId, staffName, paging) => {
  let txnBodyCom = {
    regionCode: regionCode,
    orgCode: orgCode,
    loginNo: loginNo,
    staffId: staffId
    // staffName: staffName,
    // roleId: roleId
  }
  return ajaxRequest('post', 'gsp/gld01015', {
    txnBodyCom
  }, paging)
}

// 根据机构ID查询用户拥有的角色接口
export const getRoleListByStaffId = (staffId, paging) => {
  let txnBodyCom = {
    staffId: staffId
  }
  return ajaxRequest('post', 'gsp/gld01017', {
    txnBodyCom
  }, paging)
}

// 用户授权角色接口
export const insertStaffRoleRelation = (staffId, roleId, paging) => {
  let txnBodyCom = {
    staffId: staffId,
    roleId: roleId
  }
  return ajaxRequest('post', 'gsp/gld01008', {
    txnBodyCom
  }, paging)
}

// 新增用户接口
export const userAdd = (loginNo, orgId, staffpassword, staffName, staffMobile, certType, certNo, paging) => {
  let txnBodyCom = {
    loginNo: loginNo,
    orgId: orgId,
    staffpassword: staffpassword,
    staffName: staffName,
    staffMobile: staffMobile,
    certType: certType,
    certNo: certNo
  }
  return ajaxRequest('post', 'gsp/gld01007', {
    txnBodyCom
  }, paging)
}

// 用户重置密码接口
export const resetPassWord = (staffId, firPassword, secPassword) => {
  let txnBodyCom = {
    staffId: staffId,
    firPassword: firPassword,
    secPassword: secPassword
  }
  let page = {
    tRecInPage: '',
    tPageJump: '',
    tStsTraceId: ''
  }
  return ajaxRequest('post', 'gsp/gld01108', {
    txnBodyCom
  }, page)
}
// 用户启用禁用接口;用户删除也是这个接口，就是isEnable传空就是
export const operateUser = (staffId, isEnable) => {
  let txnBodyCom = {
    staffId: staffId,
    isEnable: isEnable
  }
  let page = {
    tRecInPage: '',
    tPageJump: '',
    tStsTraceId: ''
  }
  return ajaxRequest('post', 'gsp/gld01111', {
    txnBodyCom
  }, page)
}
// 用户编辑接口
export const userEdit = (staffId, staffName, staffMobile) => {
  let txnBodyCom = {
    staffId: staffId,
    staffName: staffName,
    staffMobile: staffMobile
  }
  let page = {
    tRecInPage: '',
    tPageJump: '',
    tStsTraceId: ''
  }
  return ajaxRequest('post', 'gsp/gld01109', {
    txnBodyCom
  }, page)
}

// 查询政务人员可关联会员列表
export const findAssociateMemberByStaffId = (staffId) => {
  let txnBodyCom = {
    staffId: staffId
  }
  let page = {
    tRecInPage: '',
    tPageJump: '',
    tStsTraceId: ''
  }
  return ajaxRequest('post', 'gsp/gld01018', {
    txnBodyCom
  }, page)
}

// 政务人员关联会员
export const doGovStaffAssociateMember = (staffId, loginAccountId) => {
  let txnBodyCom = {
    staffId: staffId,
    loginAccountId: loginAccountId
  }
  let page = {
    tRecInPage: '',
    tPageJump: '',
    tStsTraceId: ''
  }
  return ajaxRequest('post', 'gsp/gld01019', {
    txnBodyCom
  }, page)
}

export const getRoleListData = (data, page) => { // 获取角色列表
  return ajaxRequest('post', 'gsp/gld01014', data, page)
}
export const getMenuListByRole = (data, page) => { // 根据角色获取菜单列表
  return ajaxRequest('post', 'gsp/gld01016', data, page)
}
export const addRole = (data) => { // 新增角色
  return ajaxRequest('post', 'gsp/gld01005', data)
}
export const authorizeRole = (data) => { // 授权角色
  return ajaxRequest('post', 'gsp/gld01010', data)
}
export const operateRole = (data) => { // 角色启用禁用删除
  return ajaxRequest('post', 'gsp/gld01020', data)
}
export const getPermittedUser = (data, page) => { // 根据角色获取已授权用户列表
  return ajaxRequest('post', 'gsp/gld01021', data, page)
}
export const delPermittedUser = (data) => { // 移除已授权用户
  return ajaxRequest('post', 'gsp/gld01022', data)
}
export const addPermittedUser = (data) => { // 批量授权用户
  return ajaxRequest('post', 'gsp/gld01008', data)
}
// 根据角色id获取互斥角色列表
export const queryMutexByRoid = (data, page) => {
  return ajaxRequest('post', 'gsp/gld01024', data)
}
export const register = (data) => {
  return ajaxRequest('post', '/abc/qa-service/qaSrv/register', data)
}
// 导出角色
export const queryRoleListExport = (data) => {
  return ajaxRequest('post', 'gsp/gld01025', data)
}
// 用户导出
export const queryStaffByRegnAndOrgImport = (data) => {
  return ajaxRequest('post', 'gsp/gld01028', data)
}
