import ajaxRequest from '@/libs/ajaxRequest'

export const getTableData = () => {
  return ajaxRequest('get', 'get_table_data')
  /* return axios.request({
    url: 'get_table_data',
    method: 'get'
  }) */
}

export const getDragList = () => {
  return ajaxRequest('get', 'get_drag_list')
  /* return axios.request({
    url: 'get_drag_list',
    method: 'get'
  }) */
}

export const errorReq = () => {
  return ajaxRequest('post', 'error_url')
  /* return axios.request({
    url: 'error_url',
    method: 'post'
  }) */
}

export const saveErrorLogger = info => {
  return ajaxRequest('post', 'save_error_logger', info)
  /*  return axios.request({
    url: 'save_error_logger',
    data: info,
    method: 'post'
  }) */
}

export const uploadImg = formData => {
  return ajaxRequest('post', 'image/upload', formData)
  /* return axios.request({
    url: 'image/upload',
    data: formData
  }) */
}

export const getOrgData = () => {
  return ajaxRequest('get', 'get_org_data')
  /* return axios.request({
    url: 'get_org_data',
    method: 'get'
  }) */
}

export const getTreeSelectData = () => {
  return ajaxRequest('get', 'get_tree_select_data')
  /* return axios.request({
    url: 'get_tree_select_data',
    method: 'get'
  }) */
}

export const getMenuData = () => {
  return ajaxRequest('get', 'get_menu_data')
}

export const getAreaTree = () => {
  return ajaxRequest('get', 'get_area_tree')
}

export const getAreaList = parent => {
  return ajaxRequest('get', 'get_area_list', parent)
}
export const getAreaData = () => {
  return ajaxRequest('get', 'get_area_data')
}

export const getScoreData = () => {
  return ajaxRequest('get', 'get_score_data')
}

export const getLiveHotTopic = (data) => {
  return ajaxRequest('post', 'get_live_Hot_Topic', data)
}

export const getRoleListData = (data, page) => { // 获取角色列表
  // return ajaxRequest('get','/gsp/fsxs11t66668',data);
  return ajaxRequest('post', 'gsp/gld01014', data, page)
}
export const getMenuListByRole = (data, page) => { // 根据角色获取菜单列表
  return ajaxRequest('post', 'gsp/gld01016', data, page)
}
export const addRole = (data) => { // 新增角色
  return ajaxRequest('post', 'gsp/gld01005', data)
}
export const authorizeRole = (data) => { // 授权角色
  return ajaxRequest('post', 'gsp/gld01010', data)
}
export const operateRole = (data) => { // 角色启用禁用删除
  return ajaxRequest('post', 'gsp/gld01020', data)
}
export const getPermittedUser = (data, page) => { // 根据角色获取已授权用户列表
  return ajaxRequest('post', 'gsp/gld01021', data, page)
}
export const delPermittedUser = (data) => { // 移除已授权用户
  return ajaxRequest('post', 'gsp/gld01022', data)
}
export const addPermittedUser = (data) => { // 批量授权用户
  return ajaxRequest('post', 'gsp/gld01008', data)
}

export const getWorkOrderData = (data) => {
  return ajaxRequest('get', 'getWorkOrderData')
}
