import ajaxRequest from '@/libs/ajaxRequest'

// 服务事项 查看服务事项列表
export const getMatterList = (param, page) => {
  return ajaxRequest('post', 'gsp/gld03005', param, page)
}
// 服务事项 删除/启用/禁用
export const operateMatter = (param, page) => {
  return ajaxRequest('post', 'gsp/gld03009', param, page)
}

// 服务事项 待配置 详情
export const getToconfiguredList = (param, page) => {
  return ajaxRequest('post', 'gsp/gld03006', param, page)
}

// 点击带配置清单
export const getfindCatalogList = (param, page) => {
  return ajaxRequest('post', 'gsp/gld03010', param, page)
}

// 点击保存验证编码
export const getsavecode = (param) => {
  return ajaxRequest('post', 'gsp/gld03030', param)
}

// 查看服务事项分类
export const getMatterCategoryList = (param, page) => {
  return ajaxRequest('post', 'gsp/gld03001', param, page)
}

// 查看服务事项所属分类
export const getprimaryform = (param) => {
  return ajaxRequest('post', 'gsp/gld03007', param)
}
// 查看事项
export const getmatterform = (param) => {
  return ajaxRequest('post', 'gsp/gld03008', param)
}
