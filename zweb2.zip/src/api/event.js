import ajaxRequest from '@/libs/ajaxRequest'
export const getEventData = (param, page) => {
  return ajaxRequest('get', 'get_event_data', param, page)
}

export const operateEvent = (param) => {
  return ajaxRequest('post', 'oparate_event', param)
}

export const getEventConfigData = () => {
  return ajaxRequest('get', 'get_event_config_data')
}
