import ajaxRequest from '@/libs/ajaxRequest'
import axios from 'axios'
export const getFeelingShow = (data, pagination) => { // 通知管理系统/内部通知管理搜索
  return axios.post('http://128.196.221.35:8080/feeling/show', {})
// return ajaxRequest('post', 'feeling/show', data,pagination)
}
