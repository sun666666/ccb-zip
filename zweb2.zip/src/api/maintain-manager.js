import ajaxRequest from '@/libs/ajaxRequest'

// 新建工单
export const newWorkOrder = (param, page) => {
  return ajaxRequest('post', '/gmo/monW001', param, page)
}
// 工单查询
export const getWorkOrderList = (param, page) => {
  return ajaxRequest('post', '/gmo/monW002', param, page)
}
// 工单补录
export const saveWorkOrder = (param, page) => {
  return ajaxRequest('post', '/gmo/monW003', param, page)
}
// 获得租户对应的机构
export const getOrg = (param, page) => {
  return ajaxRequest('post', '/gmo/monW004', param, page)
}
// 工单查询列表
export const queryRepairOrder = (param, page) => {
  return ajaxRequest('post', '/gmo/monSafety003', param, page)
}
// 工单申报上报
export const subRepairOrder = (param, page) => {
  return ajaxRequest('post', '/gmo/monSafety004', param, page)
}
// 查询上报列表接口
export const queryReportManager = (param, page) => {
  return ajaxRequest('post', 'gmo/monSafety007', param, page)
}
// 上报安全事件接口
export const subReportManager = (param, page) => {
  return ajaxRequest('post', '/gmo/monSafety008', param, page)
}
// 获取节点编码列表
export const queryCenterCode = (param, page) => {
  return ajaxRequest('post', '/gmo/monW004', param, page)
}
