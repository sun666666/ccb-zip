import ajaxRequest from '@/libs/ajaxRequest'

// 应用管理列表/搜索
export const findAppList = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld03022', data, pagination)
}
// 新增/编辑应用
export const saveApp = (data) => {
  return ajaxRequest('post', 'gsp/gld03023', data)
}
// 启用/禁用/删除/推荐/不推荐应用
export const operateSysVivilianApp = (data) => {
  return ajaxRequest('post', 'gsp/gld03024', data)
}
// 查看应用
export const findApp = (data) => {
  return ajaxRequest('post', 'gsp/gld03025', data)
}
// 应用分类列表
export const findSysVivilianAppType = (data, pagination) => {
  return ajaxRequest('post', 'gsp/gld03026', data, pagination)
}
// 应用分类新增/编辑
export const insertciviliantype = (data) => {
  return ajaxRequest('post', 'gsp/gld03027', data)
}
// 应用分类启用/禁用/删除
export const updateCivilian = (data) => {
  return ajaxRequest('post', 'gsp/gld03028', data)
}
// 应用分类详情
export const selectcivilian = (data) => {
  return ajaxRequest('post', 'gsp/gld03029', data)
}

// 验证编码是否重复（事项code|事项详情code|应用code|应用详情code）
export const validationParameters = (data) => {
  return ajaxRequest('post', 'gsp/gld03030', data)
}
