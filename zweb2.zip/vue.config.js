const path = require('path')

const resolve = dir => {
  return path.join(__dirname, dir)
}

// 项目部署基础
// 默认情况下，我们假设你的应用将被部署在域的根目录下,
// 例如：https://www.my-app.com/
// 默认：'/'
// 如果您的应用程序部署在子路径中，则需要在这指定子路径
// 例如：https://www.foobar.com/my-app/
// 需要将它改为'/my-app/'
const BASE_URL = process.env.NODE_ENV === 'production'
  ? './'
  : './'

module.exports = {
  // Project deployment base
  // By default we assume your app will be deployed at the root of a domain,
  // e.g. https://www.my-app.com/
  // If your app is deployed at a sub-path, you will need to specify that
  // sub-path here. For example, if your app is deployed at
  // https://www.foobar.com/my-app/
  // then change this to '/my-app/'
  baseUrl: BASE_URL,
  outputDir: process.env.outputDir,
  pages: {

    index: {
      // page 的入口
      entry: 'src/main.js',
      // 模板来源
      template: (process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'testdev') ? 'public/index.dev.html' : 'public/index.html', // 这里用来区分加载那个 html
      // template: 'public/index.html', // 这里用来区分加载那个 html
      // 在 dist/index.html 的输出
      filename: 'index.html',
      // 当使用 title 选项时，
      // template 中的 title 标签需要是 <title><%= htmlWebpackPlugin.options.title %></title>
      // title: "时光机后台管理系统",
      // 在这个页面中包含的块，默认情况下会包含
      // 提取出来的通用 chunk 和 vendor chunk。
      chunks: ['chunk-vendors', 'chunk-common', 'index']
    }
  },

  // tweak internal webpack configuration.
  // see https://github.com/vuejs/vue-cli/blob/dev/docs/webpack.md
  // 如果你不需要使用eslint，把lintOnSave设为false即可
  lintOnSave: process.env.NODE_ENV === 'development',
  parallel: require('os').cpus().length > 1,
  transpileDependencies: [resolve('src/locale'), resolve('node_modules'), 'vue-router'],
  chainWebpack: config => {
    config.resolve.alias
      .set('@', resolve('src')) // key,value自行定义，比如.set('@@', resolve('src/components'))
      .set('_c', resolve('src/components'))
      .set('_bc', resolve('src/busi-components'))
  },
  configureWebpack (config) {
    if (process.env.NODE_ENV === 'production') {
      const terserWebpackPlugin = config.optimization.minimizer[0]
      const terserOptions = terserWebpackPlugin.options.terserOptions
      terserOptions.compress['drop_console'] = true
    }
    Object.assign(config, {
      externals: {
        vue: 'Vue',
        // vuex: 'Vuex',
        // 'vue-router': 'VueRouter',
        iview: 'iview',
        vuecoms: 'vuecoms'
      }
    })
  },

  // 设为false打包时不生成.map文件
  productionSourceMap: false,
  // 这里写你调用接口的基础路径，来解决跨域，如果设置了代理，那你本地开发环境的axios的baseUrl要写为 '' ，即空字符串
  devServer: {
    // proxy: 'localhost:3000'
    watchOptions: {
      poll: true
    },
    // 在浏览器上全屏显示编译的errors或warnings。
    overlay: {
      warnings: false,
      errors: true
    }
  }
}
