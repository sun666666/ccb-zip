## zweb前端开发框架

## Getting started
```
// install dependencies
yarn

// develop
npm run dev
```
## Build
```
npm run build
```

